#ifndef __LINUX_USB_H
#define __LINUX_USB_H

#include <linux/usb_ch9.h>

#define USB_MAJOR			180

#endif

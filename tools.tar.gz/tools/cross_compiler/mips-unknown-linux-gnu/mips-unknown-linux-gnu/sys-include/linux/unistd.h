#ifndef _LINUX_UNISTD_H_
#define _LINUX_UNISTD_H_

#include <errno.h>

/*
 * Include machine specific syscallX macros
 */
#include <asm/unistd.h>

#endif /* _LINUX_UNISTD_H_ */

#ifndef _LINUX_ELF_H
#define _LINUX_ELF_H

#include <elf.h>
#include <asm/elf.h>

#endif /* _LINUX_ELF_H */

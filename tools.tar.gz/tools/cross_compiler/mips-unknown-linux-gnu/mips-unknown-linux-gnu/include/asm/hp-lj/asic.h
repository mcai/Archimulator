
typedef enum { IllegalAsic, UnknownAsic, AndrosAsic, HarmonyAsic } AsicId;

AsicId GetAsicId(void);

const char* const GetAsicName(void);


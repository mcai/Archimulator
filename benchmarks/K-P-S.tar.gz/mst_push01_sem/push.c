#include "push.h"
#define K 180
#define P 250
#define SYN_COUNT 430
Vertex tmp_inserted;
void *tmp_addr;
extern volatile int flag;
HashEntry volatile tmp_ent;

void cpu_set()
{
	cpu_set_t mask;

	CPU_ZERO(&mask);
	CPU_SET(0, &mask);
	CPU_SET(4, &mask);

	if(sched_setaffinity(0, sizeof(mask), &mask) == -1)
	{
		perror("set affinity error!\n");
	}
}

void *push_thread(void *pvoid)
{
	Hash tmp_hash;
	int i, tmp_j;
	unsigned int tmp_key;
	//volatile HashEntry tmp_ent;
	Vertex *volatile tmp_p;
	Vertex volatile tmp_index;
	int syncInterval=0;
	while(flag)
	{
		sem_wait(&sem);
		tmp_p = (Vertex *)tmp_addr;
		while(!(*tmp_p))
		  asm("pause");

		syncInterval=SYN_COUNT;//init the sync interval

		tmp_index = (Vertex)(*tmp_p);
		while(flag && tmp_index)
		{
		    for(i = 0; flag && tmp_index && i < K; i++, tmp_index = tmp_index->next)
			  syncInterval--;
			for(i=0; i<P && flag && tmp_index; i++, tmp_index = tmp_index->next)
			{
				syncInterval--;
				if(flag && tmp_index && tmp_index != tmp_inserted)
				{
					tmp_hash = tmp_index->edgehash;
					tmp_key = (unsigned int)tmp_inserted;
					tmp_j = (tmp_hash->mapfunc)(tmp_key);
					assert(1, tmp_j>=0);
					assert(2, tmp_j<tmp_hash->size);
					for(tmp_ent = tmp_hash->array[tmp_j];
							tmp_ent && tmp_ent->key != tmp_key && flag;
							tmp_ent = tmp_ent->next);
				}
			}
			if(syncInterval==0)
			{
			syncInterval=SYN_COUNT;//reset the sync interval
			tmp_index = (Vertex)(*tmp_p);
			}
		}
	}
	return NULL;
}

void init_thread()
{
//	cpu_set();
	if(sem_init(&sem, 0, 0) == -1)
	{
		perror("sem init error!\n");
	}
	pthread_create(&push_handle, NULL, push_thread, NULL);
	return;
}

void push_start(void *addr, Vertex inserted)
{
	tmp_addr = addr;
	tmp_inserted = inserted;
	sem_post(&sem);
	return;
}


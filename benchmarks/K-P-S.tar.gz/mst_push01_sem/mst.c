/* For copyright information, see olden_v1.0/COPYRIGHT */

#include "mst.h"
#include "push.h"

volatile int flag = 1;

typedef struct blue_return {
  Vertex vert;
  int dist;
} BlueReturn;


typedef struct fc_br {
  BlueReturn value;
} future_cell_BlueReturn;

static BlueReturn BlueRule(Vertex inserted, Vertex vlist) 
{
  BlueReturn retval;
  Vertex tmp,prev;
  Hash hash;
  int dist,dist2;
//  int count;

  tmp = NULL;
  
  if (!vlist) {
    retval.dist = 999999;
    return retval;
  }

  prev = vlist;
  retval.vert = vlist;
  retval.dist = vlist->mindist;
  hash = vlist->edgehash;
  dist = (int) HashLookup((unsigned int) inserted, hash);
  if (dist) 
    {
      if (dist<retval.dist) 
        {
          vlist->mindist = dist;
          retval.dist = dist;
        }
    }
  else printf("Not found\n");
  
 // count = 0;
 // tmp = NULL;
  push_start(&tmp, inserted);
  for (tmp=vlist->next; tmp; prev=tmp,tmp=tmp->next) 
    {
  //    count++;
      if (tmp==inserted) 
        {
          Vertex next;

          next = tmp->next;
          prev->next = next;
        }
      else 
        {
          hash = tmp->edgehash; 
          dist2 = tmp->mindist;
          dist = (int) HashLookup((unsigned int) inserted, hash);
          if (dist) 
            {
              if (dist<dist2) 
                {
                  tmp->mindist = dist;
                  dist2 = dist;
                }
            }
          else printf("Not found\n");
          if (dist2<retval.dist) 
            {
              retval.vert = tmp;
              retval.dist = dist2;
            }
        }
    }
  return retval;
}

          

static Vertex MyVertexList = NULL;

static BlueReturn Do_all_BlueRule(Vertex inserted, int nproc, int pn) {
  future_cell_BlueReturn fcleft;
  BlueReturn retright;

  if (nproc > 1) {
     fcleft.value = Do_all_BlueRule(inserted,nproc/2,pn+nproc/2);
     retright = Do_all_BlueRule(inserted,nproc/2,pn);

     if (fcleft.value.dist < retright.dist) {
       retright.dist = fcleft.value.dist;
       retright.vert = fcleft.value.vert;
       }
     return retright;
  }
  else {
     if (inserted == MyVertexList)
       MyVertexList = MyVertexList->next;
     return BlueRule(inserted,MyVertexList);
  }
}

static int ComputeMst(Graph graph,int numproc,int numvert) 
{
  Vertex inserted,tmp;
  int cost=0,dist;
	
  printf("Compute phase 1\n");

  inserted = graph->vlist[0];
  tmp = inserted->next;
  graph->vlist[0] = tmp;
  MyVertexList = tmp;
  numvert--;
  printf("Compute phase 2\n");
  while (numvert) 
    {
      BlueReturn br;
      
      br = Do_all_BlueRule(inserted,numproc,0);
      inserted = br.vert;    
      dist = br.dist;
      numvert--;
      cost = cost+dist;
    }
  return cost;
}

int main(int argc, char *argv[]) 
{
  Graph graph;
  int dist;
  int size;
  struct timeval t_s,t_e;
  cpu_set();
  gettimeofday(&t_s,NULL);
  size = dealwithargs(argc,argv);
  printf("Making graph of size %d\n",size);
  gettimeofday(&t_start,NULL);
  graph = MakeGraph(size,NumNodes);
  gettimeofday(&t_end,NULL);
  printf("Graph completed: %.3f\n",timeused(t_start,t_end));

  printf("About to compute mst \n");
  init_thread();
  flag = 1;
  gettimeofday(&t_start,NULL);
  dist = ComputeMst(graph,NumNodes,size);
  gettimeofday(&t_end,NULL);
  flag = 0;
  printf("MST has cost %d\n",dist);
  printf("ComputeMST completed: %.3f\n",timeused(t_start,t_end));
  gettimeofday(&t_e,NULL);
  printf("MST total time: %.3f\n",timeused(t_s,t_e));

  exit(0);
}

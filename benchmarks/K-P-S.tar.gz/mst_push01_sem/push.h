
#ifndef PUSH_H
#define PUSH_H

#define _GNU_SOURCE

#include <sched.h>
#include <pthread.h> 
#include <semaphore.h>
#include <stdlib.h>

#include "mst.h"
#include "hash.h"

//#define assert(num,a) if (!(a)) {printf("Assertion failure:%d in hash\n",num); exit(-1);}

sem_t sem;
pthread_t push_handle;

void cpu_set();
void *push_thread(void *pvoid);
void init_thread();
void push_start(void *addr, Vertex inserted);

#endif

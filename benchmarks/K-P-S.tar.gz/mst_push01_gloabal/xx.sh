#!/bin/sh



STEP1=0


REPORTFILE=mst_report_O2.csv

while [ $STEP1 -le 10 ]
do
#	sed '10s/[0-9][0-9]*/'$STEP1'/g' push.c > temp.c
#	rm push.c
#	cp temp.c push.c
#	rm temp.c

	echo -e "$STEP1\c " >> $REPORTFILE

		make
		./flushCache
		./flushCache

		./mst > tmp
		
		TIME_USED=`sed -n '$p' tmp | awk -F : '{print $2}'`
	

		echo -e ",$TIME_USED\c " >> $REPORTFILE

	echo >>  $REPORTFILE
	STEP1=`expr $STEP1 + 1` 

done


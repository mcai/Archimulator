
#ifndef PUSH_H
#define PUSH_H

#define _GNU_SOURCE
#include <sched.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

struct timeval ts, te;
pthread_t push_thread_id;

void cpu_set();

void init_thread();

void destroy_thread();

void *push_thread(void *pvoid);

double timeused(const struct timeval ts, const struct timeval te);

#endif

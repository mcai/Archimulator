#!/bin/sh



STEP1=0
STEP2=0

REPORTFILE=report_O2.csv

while [ $STEP1 -le 10 ]
do

#	sed '4s/[0-9][0-9]*/'$STEP2'/g' push.c > temp.c
#	sed '5s/[0-9][0-9]*/'$STEP1'/g' temp.c > push.c
#	rm temp.c

	echo -e "$STEP1\c " >> $REPORTFILE

		make -B
		./flushCache
		./flushCache

		./em3d > tmp
		
		
		TIME_USED=`sed -n '$p' tmp | awk -F : '{print $2}'`
	

		echo -e ",$TIME_USED\c " >> $REPORTFILE

	echo >>  $REPORTFILE
	STEP1=`expr $STEP1 + 1` 

done



#!/bin/sh



STEP1=1
STEP2=10

export PATH=$PATH:/opt/intel/vtune/bin

module1=fill_from_fields
module2=
REPORTFILE=em3d_prefetch_report_O2.csv
myapp=em3d
if [ ! -f $REPORTFILE ]; then
	echo -e "STEP vaule\c " >> $REPORTFILE
	for o in 3 
	do      
        echo -e ",O$o-Total time\c " >> $REPORTFILE
        echo -e ",O$o-$module1 L2miss\c " >> $REPORTFILE
	done    
	echo >> $REPORTFILE	
fi

while [ $STEP1 -le 40 ]
do
	sed '5s/[0-9][0-9]*/'$STEP1'/g' push.c > temp.c
	cp temp.c push.c
	rm temp.c

	echo -e "$STEP1\c " >> $REPORTFILE

		reportdir=O2-PREFETCHSTEP1_${STEP1}
		mkdir $reportdir
		fn1=fill_from_fields
		fn2=push_thread
		make -B && rm *.o
		./flushCache
		./flushCache
		vtl activity -d 1000 -c sampling -o "-ec en= 'MEM_LOAD_RETIRED.L2_MISS':sa=100000 -sterm yes -cal no" -app ./$myapp," >$reportdir/result-$myapp.txt" run
		
		vtl view -es >  $reportdir/environmentsum-${myapp}.txt
		vtl view -as -cd ',' > $reportdir/activitysum-${myapp}.csv
		vtl view -sum -cd ',' > $reportdir/statsum-${myapp}.csv
		vtl view -threads -cpu -sea 11 -sum -cd ',' > $reportdir/thread-${myapp}.csv
		vtl view -hf -mn $myapp -cpu -sea 11 -sum -cd ',' > $reportdir/hotspots-${myapp}.csv
		vtl view -code -mn $myapp -fn $fn1  > $reportdir/source-$fn1.txt
		vtl view -code -mn $myapp -fn $fn2  > $reportdir/source-$fn2.txt
		
		TIME_USED=`sed -n '$p' $reportdir/result-${myapp}.txt | awk -F : '{print $2}'`
	
		MODULE1_MISS=`awk -F , '{if($1~/'$module1'/) print $3}' $reportdir/hotspots-${myapp}.csv`

		echo -e ",$TIME_USED\c " >> $REPORTFILE
		echo -e ",$MODULE1_MISS\c " >> $REPORTFILE
		vtl delete -all -f

	echo >>  $REPORTFILE
	STEP1=`expr $STEP1 + 2` 

done



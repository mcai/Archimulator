#include "push.h"
#include "em3d.h"

#define STEP_PRE  0
#define STEP_PUSH 50
#define S  50

node_t * volatile g_curr_node;
node_t * volatile g_nodelist;
volatile int g_degree;

volatile int inter_push_flag = 0;

void cpu_set()
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(0, &mask);
//	CPU_SET(1, &mask);
	CPU_SET(4, &mask);
//	CPU_SET(3, &mask);

	if(sched_setaffinity(0, sizeof(mask), &mask) == -1)
	{
		perror("cpu set error!\n");
	}

	return;
}



double timeused(const struct timeval ts, const struct timeval te)
{
	return (double)(1000000*(te.tv_sec - ts.tv_sec) + te.tv_usec - ts.tv_usec)/1000000.0;
}


void init_thread()
{
	cpu_set();
  	gettimeofday(&ts, NULL);


	pthread_create(&push_thread_id, NULL, push_thread, NULL);

	return;
}

void destroy_thread()
{
	pthread_cancel(push_thread_id);

  	gettimeofday(&te, NULL);
  	printf("total time:%.3lf\n", timeused(ts, te));
}

void *push_thread(void *pvoid)
{
	int i, j;
	int degree;
	volatile int count;
	double ** volatile otherlist;
	node_t * curr_node;
	node_t * nodelist;
	int from_count;
	double *other_value;
	node_t * other_node;
        int syncInterval=0;
	for(;;)
	{
		while(!inter_push_flag)
			asm("pause");

		switch(inter_push_flag)
		{
			case 1:
			{
				curr_node = g_curr_node;
				nodelist = curr_node;
				degree = g_degree;
				syncInterval=S;
				while(curr_node)
				{
					for(i=0; i< STEP_PRE && curr_node; i++, curr_node = curr_node->next)
						{syncInterval--; }
					for(i=0; i< STEP_PUSH && curr_node; i++, curr_node = curr_node->next)
					{	syncInterval--;
						for(j=0; j < degree; j++)
						{
							node_t * other_node;
							other_node = curr_node->to_nodes[j];
//							count = other_node->from_length;
//							otherlist = other_node->from_values;
//							asm volatile ("prefetcht1 (%0)"::"r"(&(otherlist[count])));
							asm volatile ("prefetcht1 (%0)"::"r"(&(other_node->from_length)));
							asm volatile ("prefetcht1 (%0)"::"r"(&(other_node->from_values)));
						}
					}
					 if(syncInterval==0)
                       			 {
                        			syncInterval=S;//reset the sync interval
						curr_node = g_curr_node;
                       			  }
				}
				break;
			}
/*			case 2:
			{
				nodelist = g_nodelist;
				while(nodelist)
				{
					for(i=0; i < PRE && nodelist; i++, nodelist = nodelist -> next){}
					for(i=0; i < PUSH && nodelist; i++, nodelist = nodelist -> next)
					{
						from_count = nodelist -> from_count - 1;
						for(j=0; j < from_count; j+=2)
						{
							other_value = nodelist -> from_values[j];
							if(other_value)
							{
								asm volatile ("prefetcht1 (%0)"::"r"(other_value));
							}
							other_value = nodelist -> from_values[j+1];
							if(other_value)
							{
								asm volatile ("prefetcht1 (%0)"::"r"(other_value));
							}
						}
					}
					nodelist = g_nodelist;
				}
			}*/
		}
		inter_push_flag = 0;
	}
}



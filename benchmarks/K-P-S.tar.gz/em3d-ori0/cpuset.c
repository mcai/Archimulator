#include "cpuset.h"

void cpu_set_ex(int cpu)
{
	cpu_set_t mask;

	CPU_ZERO(&mask);
	CPU_SET(cpu, &mask);
	//CPU_SET(3, &mask);

	if(sched_setaffinity(0, sizeof(mask), &mask) == -1)
	{
		perror("set affinity error!\n");
	}
}

#!/bin/sh
STEP=100000

export PATH=$PATH:/opt/intel/vtune/bin

module1=fill_from_fields
module2=compute_nodes
REPORTFILE=em3d_report.csv
myapp=em3d
if [ ! -f $REPORTFILE ]; then
	echo -e "STEP vaule\c " >> $REPORTFILE
	for o in 0 1 2 3 
	do      
        	echo -e ",O$o-Total time\c " >> $REPORTFILE
			echo -e ",O$o-main thread cycles\c " >> $REPORTFILE
        	echo -e ",O$o-$module1 CPU cycles\c " >> $REPORTFILE
        	echo -e ",O$o-$module1 L2miss\c " >> $REPORTFILE
			echo -e ",O$o-$module2 CPU cycles\c " >> $REPORTFILE
			echo -e ",O$o-$module2 L2miss\c " >> $REPORTFILE
	done    
	echo >> $REPORTFILE	
fi

while [ $STEP -lt 110000 ]
do
	#COUNTER=`expr $COUNTER + 10000`
	#sed '2,3s/[0-9][0-9]*/'$STEP'/g' push.c > temp.c
	#cp temp.c push.c
	#rm temp.c
	#reportdir=STEP_$STEP
    #    mkdir $reportdir

	echo -e "$STEP\c " >> $REPORTFILE
	for op in 0 1 2 3
	do	

		sed '2,3s/[0-9][0-9]*/'$op'/g' Makefile > temp
		cp temp Makefile
		rm temp
		reportdir=O${op}-STEP_${STEP}
		mkdir $reportdir
		#myapp=lds_push${id}
		fn1=fill_from_fields	
		#fn2=push_thread_func
		fn3=compute_nodes
		make -B && rm *.o	
		vtl activity -d 1000 -c sampling -o "-ec en= 'MEM_LOAD_RETIRED.L2_MISS':sa=100000 en='CPU_CLK_UNHALTED.CORE' :sa=1600000 -sterm yes -cal no" -app ./$myapp," 1000000 32 >$reportdir/result-$myapp.txt" run
		
		vtl view -es >  $reportdir/environmentsum-${myapp}.txt
		vtl view -as -cd ',' > $reportdir/activitysum-${myapp}.csv
		vtl view -sum -cd ',' > $reportdir/statsum-${myapp}.csv
		vtl view -threads -cpu -sea 11 -sum -cd ',' > $reportdir/thread-${myapp}.csv
		vtl view -hf -mn $myapp -cpu -sea 11 -sum -cd ',' > $reportdir/hotspots-${myapp}.csv
		vtl view -code -mn $myapp -fn $fn1  > $reportdir/source-$fn1.txt
		#vtl view -code -mn $myapp -fn $fn2  > $reportdir/source-$fn2.txt
		vtl view -code -mn $myapp -fn $fn3  > $reportdir/source-$fn2.txt
		
		TIME_USED=`sed -n '$p' $reportdir/result-$myapp.txt | awk -F : '{print $2}'`
		
		MAIN_CYCLES=0

		for i in `awk -F , '{if($2~/em3d/) print $8}' $reportdir/thread-${myapp}.csv`
		do  
    		if [ $MAIN_CYCLES -lt $i ]; then
            	MAIN_CYCLES=$i
    		fi  
		done
		
		MODULE1_CYCLE=`awk -F , '{if($1~/'$module1'/) print $8}' $reportdir/hotspots-${myapp}.csv`
		MODULE1_MISS=`awk -F , '{if($1~/'$module1'/) print $3}' $reportdir/hotspots-${myapp}.csv`
		MODULE2_CYCLE=`awk -F , '{if($1~/'$module2'/) print $8}' $reportdir/hotspots-${myapp}.csv`
		MODULE2_MISS=`awk -F , '{if($1~/'$module2'/) print $3}' $reportdir/hotspots-${myapp}.csv`
		#PUSHTHREAD_MISS=`awk -F , '{if($1~/push/) print $3}' $reportdir/hotspots-${myapp}.csv`
		echo -e ",$TIME_USED\c " >> $REPORTFILE
		echo -e ",$MAIN_CYCLES\c " >> $REPORTFILE
		echo -e ",$MODULE1_CYCLE\c " >> $REPORTFILE
		echo -e ",$MODULE1_MISS\c " >> $REPORTFILE
		echo -e ",$MODULE2_CYCLE\c " >> $REPORTFILE
		echo -e ",$MODULE2_MISS\c " >> $REPORTFILE
		vtl delete -all -f
	done
	echo >>  $REPORTFILE
	STEP=`expr $STEP + 100000` 
done

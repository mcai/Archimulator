/* For copyright information, see olden_v1.0/COPYRIGHT */

#include "em3d.h"
#include "make_graph.h"
#include "cpuset.h"
extern int NumNodes;

int DebugFlag;

void print_graph(graph_t *graph, int id) 
{
  node_t *cur_node;
  cur_node=graph->e_nodes[id];

  for(; cur_node; cur_node=cur_node->next)
    {
      chatting("E: value %f, from_count %d\n", *cur_node->value,
	       cur_node->from_count);
    }
  cur_node=graph->h_nodes[id];
  for(; cur_node; cur_node=cur_node->next)
    {
      chatting("H: value %f, from_count %d\n", *cur_node->value,
	       cur_node->from_count);
    }
}

extern int nonlocals;

struct timeval t_start,t_end,t_c1,t_c2;

int main(int argc, char *argv[])
{
  int i;
  graph_t *graph;
    
  cpu_set_ex(0);
  gettimeofday(&t_start,NULL);
  dealwithargs(argc,argv);

  chatting("Hello world--Doing em3d with args %d %d %d %d\n",
           n_nodes,d_nodes,local_p,NumNodes);
  graph=initialize_graph();
  if (DebugFlag) 
    for(i=0; i<NumNodes;i++)
      print_graph(graph,i);

  gettimeofday(&t_c1,NULL);
  compute_nodes(graph->e_nodes[0]);
  compute_nodes(graph->h_nodes[0]);
  gettimeofday(&t_c2,NULL);
  chatting("compute nodes: %.3f\n",timeused(t_c1,t_c2));

  chatting("nonlocals = %d\n",nonlocals);

  printstats();
  gettimeofday(&t_end,NULL);
  chatting("em3d total time used:%.3f\n",timeused(t_start,t_end));
  return 0;

}

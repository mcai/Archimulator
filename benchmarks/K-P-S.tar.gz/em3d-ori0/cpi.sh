#!/bin/sh
export PATH=$PATH:/opt/intel/vtune/bin
event1="CPU_CLK_UNHALTED.CORE"
#event2="INST_RETIRED.ANY"
myapp=em3d
reportname=${myapp}
reportpath=report_${reportname}-cycles
mkdir $reportpath

vtl activity -d 1000 -c sampling -o "-ec en= '$event1':sa=1600000 -sterm yes -cal no" -app ./$myapp,"1000000 32 >$reportpath/result.txt" run




vtl view -es >  $reportpath/environmentsum-${reportname}.txt
vtl view -as -cd ',' > $reportpath/activitysum-${reportname}.csv
vtl view -sum -cd ',' > $reportpath/resultsum-${reportname}.csv
vtl view -threads -cpu -sea 11 -sum -cd ',' > $reportpath/thread-${reportname}.csv
vtl view -hf -mn $myapp -cpu -sea 11 -sum -cd ',' > $reportpath/hotspots-${reportname}.csv
vtl view -code -mn $myapp -fn fill_from_fields > $reportpath/source-fill_from_fields.txt
vtl view -code -mn $myapp -fn compute_nodes > $reportpath/source-compute_nodes.txt

vtl delete -all -f



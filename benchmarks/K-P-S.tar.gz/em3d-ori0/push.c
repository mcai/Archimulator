#include "push.h"
#include "em3d.h"

volatile node_t * volatile node_index;
volatile void * volatile tmp_addr;
volatile node_p * volatile tmp_curr_node;

extern int d_nodes;
extern volatile int flag;

void cpu_set()
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(2, &mask);
	CPU_SET(3, &mask);

	if(sched_setaffinity(0, sizeof(mask), &mask) == -1)
	{
		perror("cpu set error!\n");
	}

	return;
}

void init_thread()
{
	cpu_set();
	if(sem_init(&sem, 0, 0) == -1)
	{
		perror("sem init error!\n");
	}
	pthread_create(&push_thread_id, NULL, push_thread, NULL);

	return;
}

void destroy_thread()
{
	pthread_cancel(push_thread_id);
}

void *push_thread(void *pvoid)
{
	volatile int tmp_i, tmp_j, tmp_count;
	volatile node_t * volatile tmp_other_node;
	double ** volatile tmp_otherlist;
	double * volatile tmp_value;
	volatile double tmp;
	volatile int tmp_degree;
	while(flag)
	{
		tmp_degree = d_nodes;
		sem_wait(&sem);
		tmp_curr_node = (node_p *)tmp_addr;
		node_index = (node_t *)(*tmp_curr_node);
		while(node_index && flag)
		{
			for(tmp_i=0; tmp_i<15 && node_index && flag; tmp_i++, node_index = node_index->next) ;
			for(tmp_i = 0; node_index && tmp_i <10 && flag; tmp_i++, node_index = node_index->next)
			{
				for(tmp_j=0; tmp_j < tmp_degree && flag; tmp_j++)
				{
					tmp_count = 0;
					tmp_other_node = node_index->to_nodes[tmp_j];
					tmp_value = node_index->value;
					tmp_count = tmp_other_node->from_length;
					tmp_otherlist = tmp_other_node->from_values;
					if(!tmp_otherlist)
					{
						tmp_otherlist = tmp_other_node->from_values;
					}
					tmp_value = tmp_otherlist[tmp_count];
					tmp = tmp_other_node->coeffs[tmp_count];
				}
			}
			node_index = (node_t *)(*tmp_curr_node);
		}
	}
}

void push_start(void *addr)
{
	tmp_addr = addr;
	sem_post(&sem);
}

double timeused(const struct timeval ts, const struct timeval te)
{
	return (double)(1000000*(te.tv_sec - ts.tv_sec) + te.tv_usec - ts.tv_usec)/1000000.0;
}




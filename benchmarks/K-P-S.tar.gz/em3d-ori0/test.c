#include "em3d.h"
#include "timer.h"
#define __USE_GNU
#include <sched.h>
#include <pthread.h>
#include <semaphore.h>

pthread_t tid;
void* thread_func(void*);

float timeused(const struct timeval ts,const struct timeval te){
	    return (float)(1000000*(te.tv_sec-ts.tv_sec)+te.tv_usec-ts.tv_usec)/1000000.0;
}

int main(){
	int i;
	/*pthread_create(&tid, NULL, thread_func, NULL);
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(0,&mask);

	if(sched_setaffinity( 0, sizeof(mask), &mask )==-1)
		printf("failed to set cpu affinity\n");
	*/
	gettimeofday(&t_start,NULL);
	for(i=0;i<1000000;i++){
		node_t** curr_node = (node_t**)malloc(32*sizeof(node_t*));
	}

	gettimeofday(&t_end,NULL);
	printf("node_t size:%d\n",sizeof(node_t));
	printf("time used:%.3f\n",timeused(t_start,t_end));
		//printf("main:%d\n",(int)lrand48());
	return 0;
}

void* thread_func(void *arg){
	int i;
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(1,&mask);
    if(sched_setaffinity( 0, sizeof(mask), &mask )==-1)
	     printf("failed to set cpu affinity\n");
	for(i=0;i<10;i++)
		printf("sub:%d\n",(int)lrand48());
	return NULL;
}

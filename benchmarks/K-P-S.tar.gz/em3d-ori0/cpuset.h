
#ifndef PUSH_H
#define PUSH_H

#define _GNU_SOURCE

#include <sched.h>
#include <pthread.h> 

//#define assert(num,a) if (!(a)) {printf("Assertion failure:%d in hash\n",num); exit(-1);}
void cpu_set_ex(int);
#endif

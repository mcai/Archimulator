#include <sys/time.h>
struct timeval t_start,t_end;

float timeused(const struct timeval ts,const struct timeval te);

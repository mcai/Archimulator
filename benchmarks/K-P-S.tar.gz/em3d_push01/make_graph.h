/* For copyright information, see olden_v1.0/COPYRIGHT */

/* make_graph.h
 *
 * By:  Martin C. Carlisle
 * Date: Feb 23, 1994
 *
 */

/* initialize graph returns a structure with pointers to lists of e and h
 * nodes.
 */
#include "push.h"
graph_t *initialize_graph();

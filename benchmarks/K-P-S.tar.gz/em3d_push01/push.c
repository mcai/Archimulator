#include "push.h"

#define CASE1_K 0
#define CASE2_K 0

#define CASE_F_P 10
#define CASE_S_P 250

#define CASE_F_SYN_COUNT 10
#define CASE_S_SYN_COUNT 250

#define PUSHDATA(addr) asm volatile ("prefetcht1 (%0)"::"r"(addr))


#define SEM_POST(s) s++
#define SEM_WAIT(s) while(s<=0);s--

int volatile i_sem = 0;


node_t** volatile curr_pointer_addr;
node_t *curr_pointer;
pushargs_t parg;
pthread_t push_thread_id;
sem_t sem_push;

int volatile push_flag = -1;

node_t** node_array;


inline void i_sem_wait();

void cpu_set(){
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0,&mask);
    CPU_SET(2,&mask);
    if(sched_setaffinity( 0, sizeof(mask), &mask )==-1)
        printf("failed to set cpu affinity\n");
}

void init_pushthread(void* (*push_thread_func)(void *),void *args){
	cpu_set();
	if(sem_init(&sem_push,0,0)== -1)
        printf("sem create failed\n");
	pthread_create(&push_thread_id, NULL, push_thread_func, args);
}

void destroy_pushthread(){
	pthread_cancel(push_thread_id);
}

void* push_thread_func(void* arg){
	pushargs_t* args;
    volatile int i=0,degree,syn_count=0;
	node_t* volatile curr_p;
	node_t** volatile  to_curr_p;

	int syncInterval=0;

	args = (pushargs_t*)arg;
	degree = args->degree;
   
	while(1){
		SEM_WAIT(i_sem);
		switch(push_flag){
		case 1:
			to_curr_p = (node_t**)curr_pointer_addr;	
			curr_p = (node_t*)(*to_curr_p);
			int j;

			syncInterval=CASE_F_SYN_COUNT; //init the sync interval

			while(curr_p && push_flag)
			{

				for(j=0; j<CASE1_K && curr_p && push_flag; curr_p=curr_p->next); //run ahead distance

				while(curr_p && i++< CASE_F_P && push_flag)
				{
					syncInterval--;
					for(j = 0;j<degree && push_flag;j++)
					{
						volatile int count;
						void* volatile pushaddr;
						if(curr_p == NULL)
							printf("curr_p is NULL ...\n");
						node_t * volatile temp_other = curr_p->to_nodes[j];
						double ** volatile otherlist;
						volatile double *value = curr_p->value;
						if(temp_other){
							count = temp_other->from_length;
							otherlist = temp_other->from_values;
						}
						pushaddr = &(otherlist[count]);
						PUSHDATA(pushaddr);
					}
					curr_p = curr_p->next;
				}
				i = 0;
                                //sync the current pointer
				if(syncInterval==0)
				{
					syncInterval=CASE_F_SYN_COUNT;
					curr_p = (node_t*)(*to_curr_p);
					if(curr_p)
						curr_p = curr_p->next;
				}
			}
		case 2:
			to_curr_p = (node_t**)curr_pointer_addr;
                	curr_p = (node_t*)(*to_curr_p);
			
			syncInterval=CASE_S_SYN_COUNT; //init the sync interval

			while(curr_p && push_flag)
			{
				for(j=0; j<CASE2_K && curr_p && push_flag; curr_p=curr_p->next); //run ahead distance

				while(curr_p && i++< CASE_S_P && push_flag)
				{
					syncInterval--;
					volatile double tmp_cur_value;
                    			volatile int tmp_from_count;
                    			double volatile *tmp_other_value;
                    			volatile double tmp_coeff;
                    			volatile double tmp_value;
                    			volatile int tmp_i;
					tmp_cur_value = *(curr_p->value);
					tmp_from_count = curr_p->from_count-1;
					for(tmp_i = 0 ; tmp_i<tmp_from_count; tmp_i+=2)
					{
						tmp_other_value = curr_p->from_values[tmp_i];
						PUSHDATA(&(curr_p->coeffs[tmp_i]));
						if(tmp_other_value)
							PUSHDATA(tmp_other_value);
						tmp_other_value = curr_p->from_values[tmp_i+1];
						if(tmp_other_value)
							PUSHDATA(tmp_other_value);
						PUSHDATA(&(curr_p->from_values[tmp_i+1]));
					}
					curr_p = curr_p->next;
				}
				i = 0;
				if(syncInterval==0)
				{
				syncInterval=CASE_S_SYN_COUNT; //reset the sync count
                                curr_p = (node_t*)(*to_curr_p);
                                if(curr_p)
                                        curr_p = curr_p->next;
				}
			}
		default: continue;
		}
			
	}
	return NULL;
}

inline void push_start(void* curr_addr,int p_flag){
	curr_pointer_addr  = (node_t**)curr_addr;
	push_flag = p_flag;
	SEM_POST(i_sem);
}

inline void push_end(){
	push_flag = 0;
}

inline void i_sem_wait(){
	while(i_sem<=0);
	i_sem--;
}


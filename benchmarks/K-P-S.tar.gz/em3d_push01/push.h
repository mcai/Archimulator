#include "em3d.h"
#define __USE_GNU
#include <sched.h>
#include <pthread.h>
#include <semaphore.h>
/* pushfunc args struct*/
typedef struct pushargs_t {
    //struct node_t **curr_node;
    int degree;
} pushargs_t;

/*
int curr_pointer_addr;
pushargs_t parg;
pthread_t push_thread_id;
sem_t sem_push;
int push_flag = 1;
*/

/* bound process to shared L2 cache Cores */
void cpuset();

void init_pushthread(void* (*push_thread_func)(void *),void *args);
void destroy_pushthread();

void* push_thread_func(void* arg);

void push_start(void * ,int);

void push_end();









#!/bin/sh

bin=mcf
echo -e "objs =\c " >Makefile
for cfile in `ls | grep '\.c$'`
	do
		obj=`echo $cfile | sed 's/\.c$//'`
		echo -e "$obj.o \c ">>Makefile
	done
echo >> Makefile	
echo "CFLAGS = -g" >> Makefile
echo "$bin:\${objs}" >> Makefile
echo "	gcc \${CFLAGS} \${objs} -o $bin -lpthread -lm" >> Makefile



for cfile in `ls | grep '\.c$'`
	do	
		echo `gcc -MM $cfile` >>Makefile
		echo "	gcc \${CFLAGS} -c $cfile" >> Makefile
	done

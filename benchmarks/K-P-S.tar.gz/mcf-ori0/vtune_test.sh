#!/bin/sh
export PATH=$PATH:/opt/intel/vtune/bin
event1="MEM_LOAD_RETIRED.L2_MISS"
#event2="INST_RETIRED.ANY"
myapp=mcf
read app_path
reportname=ref
reportpath=report1_${reportname}_O1
mkdir $reportpath

vtl activity -d 1000 -c sampling -o "-ec en= '$event1' :sa=100000  -sterm yes -cal no" -app ./${app_path}/$myapp," ../data/$reportname/input/inp.in >$reportpath/result.txt" run




vtl view -es >  $reportpath/environmentsum-${reportname}.txt
vtl view -as -cd ',' > $reportpath/activitysum-${reportname}.csv
vtl view -sum -cd ',' > $reportpath/resultsum-${reportname}.csv
vtl view -threads -cpu -sea 11 -sum -cd ',' > $reportpath/thread-${reportname}.csv
vtl view -hf -mn $myapp -cpu -sea 11 -sum -cd ',' > $reportpath/hotspots-${reportname}.csv
#vtl view -code -mn $myapp -fn main > $reportpath/source-${reportname}.txt
for hotspots in ` sed -n '5,$p' $reportpath/hotspots-${reportname}.csv | awk -F , '{print $1}'`
	do
		vtl view -code -mn $myapp -fn $hotspots > $reportpath/source-$hotspots.txt
	done 

vtl delete -all -f



#include <sys/time.h>
struct timeval t_start,t_end;

float timeused(const struct timeval ts,const struct timeval te){
	return (float)(1000000*(te.tv_sec-ts.tv_sec)+te.tv_usec-ts.tv_usec)/1000000.0;
}

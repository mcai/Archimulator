#define _GNU_SOURCE
#include <sched.h>
#include <sys/time.h>
#include <pthread.h>
#include "defines.h"
#include "push.h"

#define RP_K  50
#define RP_P  50
#define ARCS_K 15
#define ARCS_P  290

#define SYN_COUNT 12800

volatile int inter_push_flag;
arc_t* volatile g_arc;
arc_t* volatile g_stop_arcs;
long volatile g_nr_group;
node_t* volatile g_root;
node_t* volatile g_node;
node_t* volatile g_tmp;


#define PUSHDATA(ADDR) asm volatile  ("prefetcht1 (%0)"::"r"(ADDR)) 


struct timeval t_start, t_end;
pthread_t push_thread_id;


float timeused(const struct timeval ts,const struct timeval te)
{
	return (float)(1000000*(te.tv_sec-ts.tv_sec)+te.tv_usec-ts.tv_usec)/1000000.0f;
}


void cpu_set()
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0,&mask);
    CPU_SET(4,&mask);
    if(sched_setaffinity( 0, sizeof(mask), &mask )==-1)
        printf("failed to set cpu affinity\n");
}


void* push_thread_func(void* arg)
{
	int i = 0, counter = 0;

	node_t* p_root;
	node_t* p_push;
	node_t* p_tmp;
	arc_t* p_arc;
	arc_t* p_stop_arcs;
	long p_nr_group;

	while(1)
	{
		while(!inter_push_flag)
			asm("pause");
		switch(inter_push_flag)
		{
			case 1:
			{
				int syncInterval=SYN_COUNT;			
				p_root = g_root;
				p_tmp = p_push = p_root->child;
				while( p_push != p_root )
				{
				//	for( ; syncInterval>0; syncInterval=syncInterval-(STEP_PRE+STEP_PUSH))
					{	
						for(i=0; i< RP_K && (p_push != p_root); i++)
						{
					//		syncInterval--;
							while(p_push)
							{
								p_tmp = p_push;
								p_push = p_push->child;
							}
							p_push = p_tmp;
							while(p_push->pred)
							{
								p_tmp = p_push->sibling;
								if(p_tmp)
								{
									p_push = p_tmp;
									break;
								}
								else
								{
									p_push = p_push->pred;
		            					}
							}
						}	
						for(i=0; i< RP_P && (p_push != p_root); i++)
						{
					//		syncInterval--;

							while(p_push)
							{
								PUSHDATA(&(p_push->basic_arc->cost));
								p_tmp = p_push;
								p_push = p_push->child;
							}
							p_push = p_tmp;
							while(p_push->pred)
							{
								p_tmp = p_push->sibling;
								if(p_tmp)
								{
									p_push = p_tmp;
									break;
								}
								else
								{
									p_push = p_push->pred;
		        					}
							}
						}	
				            }	//end for sync
				/*	if(syncInterval ==0)// synchronization Loop count
					 {
					 // syncInterval= -1;// only sync once	
					  syncInterval=SYN_COUNT;			
					  p_push = g_node;
					  p_tmp = g_tmp;
					 }*/
				}
				break;
			}
			case 2:
			{
				p_arc = g_arc;
				p_stop_arcs = g_stop_arcs;
				p_nr_group = g_nr_group;

				while(p_arc < p_stop_arcs)
				{
					for(i = 0 ; i < ARCS_K && p_arc < p_stop_arcs; i++ , p_arc += p_nr_group);
			//		for(i = 0 ; i < ARCS_P && p_arc < p_stop_arcs; i++ , p_arc += p_nr_group)
					for(; p_arc < p_stop_arcs; p_arc += p_nr_group)
					{
						PUSHDATA(p_arc->head);
						PUSHDATA(p_arc->tail);
					}
				}
				break;
			}
		}
		inter_push_flag = 0;
	}
	return NULL;
}


void init_pushthread()
{
	cpu_set();
	gettimeofday(&t_start, NULL);
	pthread_create(&push_thread_id, NULL, push_thread_func, NULL);
}


void destroy_pushthread()
{
	pthread_cancel(push_thread_id);
	gettimeofday(&t_end, NULL);
	printf("total time: %.3f\n", timeused(t_start, t_end));
}


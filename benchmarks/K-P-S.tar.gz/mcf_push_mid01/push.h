
#ifndef __PUSH_H
#define __PUSH_H


void init_pushthread();

void destroy_pushthread();

#endif

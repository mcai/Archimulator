#!/bin/sh



#STEP1=1000
#STEP2=300

export PATH=$PATH:/opt/intel/vtune/bin

module1=refresh_potential
module2=primal_bea_mpp
REPORTFILE=mcf_prefetch_report_O2.csv
myapp=mcf
if [ ! -f $REPORTFILE ]; then
#	echo -e "STEP1 vaule\c " >> $REPORTFILE
#	for o in 3 
#	do      
        	echo -e ",O2-Total time\c " >> $REPORTFILE
        	echo -e ",O2-$module1 L2miss\c " >> $REPORTFILE
		echo -e ",O2-$module2 L2miss\c " >> $REPORTFILE
#	done    
	echo >> $REPORTFILE	
fi

#while [ $STEP1 -le 10000 ]
#do
#	sed '13s/[0-9][0-9]*/'$STEP1'/g' push.c > temp.c
#	sed '11s/[0-9][0-9]*/'$STEP2'/g' temp.c > push.c
#	cp temp.c push.c
#	rm temp.c

#	echo -e "$STEP1\c " >> $REPORTFILE

		reportdir=O2-K30-P50-B6400
		mkdir $reportdir
		fn1=refresh_potential	
		fn2=push_thread_func
		fn3=primal_bea_mpp
		make -B && rm *.o
		./flushCache
		./flushCache
		vtl activity -d 1000 -c sampling -o "-ec en= 'MEM_LOAD_RETIRED.L2_MISS':sa=100000 -sterm yes -cal no" -app ./$myapp," ./inputl > $reportdir/result-$myapp.txt" run
		
		vtl view -es >  $reportdir/environmentsum-${myapp}.txt
		vtl view -as -cd ',' > $reportdir/activitysum-${myapp}.csv
		vtl view -sum -cd ',' > $reportdir/statsum-${myapp}.csv
		vtl view -threads -cpu -sea 11 -sum -cd ',' > $reportdir/thread-${myapp}.csv
		vtl view -hf -mn $myapp -cpu -sea 11 -sum -cd ',' > $reportdir/hotspots-${myapp}.csv
		vtl view -code -mn $myapp -fn $fn1  > $reportdir/source-$fn1.txt
		vtl view -code -mn $myapp -fn $fn2  > $reportdir/source-$fn2.txt
		vtl view -code -mn $myapp -fn $fn3  > $reportdir/source-$fn2.txt
		
		TIME_USED=`sed -n '$p' $reportdir/result-${myapp}.txt | awk -F : '{print $2}'`
	
		MODULE1_MISS=`awk -F , '{if($1~/'$module1'/) print $3}' $reportdir/hotspots-${myapp}.csv`
		MODULE2_MISS=`awk -F , '{if($1~/'$module2'/) print $3}' $reportdir/hotspots-${myapp}.csv`

		echo -e ",$TIME_USED\c " >> $REPORTFILE
		echo -e ",$MODULE1_MISS\c " >> $REPORTFILE
		echo -e ",$MODULE2_MISS\c " >> $REPORTFILE
		vtl delete -all -f

	echo >>  $REPORTFILE
#	STEP1=`expr $STEP1 + 1000` 
#	STEP2=`expr $STEP2 - 10` 
#done


#ifndef PUSH_PARAMS_H_
#define PUSH_PARAMS_H_

#define LOOKAHEAD 10
#define STRIDE 10

#endif

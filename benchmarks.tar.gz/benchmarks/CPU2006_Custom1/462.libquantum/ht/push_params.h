#ifndef PUSH_PARAMS_H_
#define PUSH_PARAMS_H_

#define LOOKAHEAD 8800
#define STRIDE 5800

#endif

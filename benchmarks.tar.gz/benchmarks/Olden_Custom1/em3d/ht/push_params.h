#ifndef PUSH_PARAMS_H_
#define PUSH_PARAMS_H_

#define LOOKAHEAD 0
#define STRIDE 10

#endif

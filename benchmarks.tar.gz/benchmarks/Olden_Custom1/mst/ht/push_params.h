#ifndef PUSH_PARAMS_H_
#define PUSH_PARAMS_H_
    
#define LOOKAHEAD 20
#define STRIDE 10

#endif

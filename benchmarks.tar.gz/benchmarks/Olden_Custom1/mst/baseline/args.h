
#ifndef ARGS_H
#define ARGS_H

int dealwithargs(int argc, char *argv[]);

#endif

/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <string.h>
#include "ptrace.h"
#include "kernel/machine.h"
#include "kernel/options.h"

#define PTRACE_MAX_THREADS	8

static FILE *ptrace_outfd;
static FILE *ptrace_pcfd[PTRACE_MAX_THREADS];
static char *ptrace_pc;
static char *ptrace_file;


/* start ptrace */
void ptrace_open() {
	ptrace_outfd = open_write(ptrace_file);
	if (!ptrace_outfd && ptrace_file[0])
		fatal("%s: cannot open trace file", ptrace_file);
}


/* stop ptrace */
void ptrace_close() {
	int i;
	close_file(ptrace_outfd);
	for (i = 0; i < PTRACE_MAX_THREADS; i++)
		close_file(ptrace_pcfd[i]);
}


void ptrace_reg_options()
{
	opt_reg_string("-ptrace:file", "ptrace output file (stdout|stderr|<fname>)",
		&ptrace_file, "");
	opt_reg_string("-ptrace:pc", "trace file for pc sequence of ctx 0",
		&ptrace_pc, "");
}


void ptrace_newpc(int ctx, word pc, int specmode)
{
	char name[MAX_STRING_SIZE];
	static dword committed = 0;
	if (!ptrace_pc[0])
		return;
	if (ctx >= PTRACE_MAX_THREADS)
		fatal("increase PTRACE_MAX_THREADS");
	if (!ptrace_pcfd[ctx]) {
		sprintf(name, "%s%02d.log", ptrace_pc, ctx);
		ptrace_pcfd[ctx] = open_write(name);
	}
	fprintf(ptrace_pcfd[ctx], "%s0x%x%s\t",
		specmode ? "(" : "", pc, specmode ? ")" : "");
	if (!specmode)
		fprintf(ptrace_pcfd[ctx], "%llu", ++committed);
	fprintf(ptrace_pcfd[ctx], "\n");
}


void ptrace_newinst(dword seq, int ctx, word inst,
	word pc, word addr)
{
	if (!ptrace_outfd)
		return;
	
	fprintf(ptrace_outfd, "+ %llu %d 0x%08x 0x%08x ", seq, ctx, pc, addr);
	md_print_inst(ptrace_outfd, inst, pc);
	fprintf(ptrace_outfd, "\n");

	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newuop(dword seq, int ctx, char *desc, word pc, word addr)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "+ %llu %d 0x%08x 0x%08x %s",
		seq, ctx, pc, addr, desc);
	fprintf(ptrace_outfd, "\n");

	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_endinst(dword seq)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "- %llu\n", seq);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newcycle(sdword cycle)
{
	if (!ptrace_outfd)
		return;
		
	fprintf(ptrace_outfd, "@ %lld\n", cycle);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newstage(dword seq, char *pstage, word pevents)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "* %llu %s 0x%08x\n", seq, pstage, pevents);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}

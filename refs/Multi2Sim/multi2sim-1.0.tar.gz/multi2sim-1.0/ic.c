/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <list.h>
#include <repos.h>
#include <assert.h>
#include <esim.h>
#include <string.h>
#include <mhandle.h>
#include "ic.h"
#include "mt.h"
#include "cache.h"

enum	ic_topo_enum ic_topo;
word	ic_bus_width;
char	*ic_bus_traffic;
word	ic_bus_interval;


/* Interconnect node */
struct ic_node_t {
	int id;		/* node identifier */
	void *data;	/* user data linked to the node */
};


/* Interconnect */
struct ic_t {
	char *name;
	struct list_t *nodes;	/* elements of type 'struct ic_node_t *' */
	
	union {
		struct {
			FILE *f;		/* file to dump traffic stats */
			dword traffic;		/* # bytes transferred */
			sdword ready;		/* cycle when bus will be free */
			sdword busy;		/* # cycles bus has been busy */
			sdword contention;	/* acc # cycles each transfer must wait */
			dword transfers;	/* # of transfer requests */
		} bus;
	} topo;
};


/* ESIM */

struct repos_t *esim_ic_transfer_repos;
int IC_EV_TRANSFER_START;
int IC_EV_TRANSFER_END;

static int IC_EV_INITIALIZE;
static int IC_EV_UPDATE_STATS;

#define N	(*ndata)
#define C	(*cdata)


/* Forwarded topologie handlers */
static void esim_ic_bus_handler(int event, void *data);




/* Private Functions */

static void ic_reg_stats(struct ic_t *ic)
{
	char name[100], form[100];
	
	switch (ic_topo) {
	
	case ic_topo_bus:
		sprintf(name, "%s.busy", ic->name);
		stat_reg_sdword(name, "number of cycles the bus was busy",
			&ic->topo.bus.busy, 0, NULL);
			
		sprintf(name, "%s.occupancy", ic->name);
		sprintf(form, "%s.busy / sim.cycles", ic->name);
		stat_reg_formula(name, "bus occupancy",
			form, "%.4f");
		
		sprintf(name, "%s.transfers", ic->name);
		stat_reg_dword(name, "number of transfers requested",
			&ic->topo.bus.transfers, 0, NULL);
		
		sprintf(name, "%s.contention", ic->name);
		stat_reg_sdword(name, "acc number of cycles each transfer must wait",
			&ic->topo.bus.contention, 0, NULL);
		break;
	}
}


static struct ic_node_t *ic_node_create(void *data)
{
	struct ic_node_t *node;
	node = calloc(1, sizeof(struct ic_node_t));
	assert(node);
	node->data = data;
	return node;
}


static void ic_node_free(struct ic_node_t *node)
{
	free(node);
}


static struct ic_t *ic_create(char *name)
{
	struct ic_t *ic;
	ic = calloc(1, sizeof(struct ic_t));
	assert(ic);
	ic->nodes = list_create(10);
	ic->name = strdup(name);
	
	/* register stats and return */
	ic_reg_stats(ic);
	esim_schedule_event(IC_EV_INITIALIZE, ic, 0);
	return ic;
}


static void ic_free(struct ic_t *ic)
{
	struct ic_node_t *node;
	
	/* free nodes */
	while (list_count(ic->nodes)) {
		node = list_pop(ic->nodes);
		ic_node_free(node);
	}
	list_free(ic->nodes);
	free(ic->name);
	
	free(ic);
}


static int ic_add_node(struct ic_t *ic, void *data)
{
	struct ic_node_t *node;
	node = ic_node_create(data);
	node->id = list_count(ic->nodes);
	list_add(ic->nodes, node);
	return node->id;
}




/* Public Functions */

void ic_reg_options()
{
	static char *ic_topo_map[] = { "bus" };
	opt_reg_enum("-ic:topo", "interconnect topology {bus}",
		(int *) &ic_topo, ic_topo_map, 1, "bus");
	opt_reg_word("-ic:bus:width", "for bus topology: bus width",
		&ic_bus_width, 72);
	opt_reg_string("-ic:bus:traffic", "file to dump traffic stats",
		&ic_bus_traffic, "");
	opt_reg_word("-ic:bus:interval", "interval to dump traffic stats, in cycles",
		&ic_bus_interval, 1000);
}


struct ic_t *ic_get(struct mt_t *mt, int core, int thread, enum ic_kind_enum kind)
{
	if (kind == ic_kind_l1_l2) {
		switch (cache_opt[dl2].sharing) {
		case cache_perthread: return THREAD.ic[0];
		case cache_percore: return CORE.ic[0];
		case cache_shared: return mt->ic[0];
		}
		return NULL;
	} else {
		return mt->ic[1];
	}
}


/* cache_init must have been called before than ic_init */
void ic_init(struct mt_t *mt)
{
	int core, thread, id;
	char name[100];
	struct ic_t *ic;
	esim_event_handler_t esim_ic_handler = NULL;
	
	/* ESIM events */
	switch (ic_topo) {
	case ic_topo_bus:
		esim_ic_handler = esim_ic_bus_handler;
		break;
		
	default:
		fatal("unknown interconnect topology");
	}
	
	esim_ic_transfer_repos = repos_create(sizeof(struct esim_ic_transfer_t), "esim_ic_transfer_repos");
	IC_EV_TRANSFER_START = esim_register_event(esim_ic_handler);
	IC_EV_TRANSFER_END = esim_register_event(esim_ic_handler);
	
	IC_EV_INITIALIZE = esim_register_event(esim_ic_handler);
	IC_EV_UPDATE_STATS = esim_register_event(esim_ic_handler);
	
	/* create l1-l2 (ic[0]) interconnects; for each interconnect,
	 * add a node (id=0 and data=NULL) corresponding to the L2 memory;
	 * also for each interconnect, add an initialization event */
	switch (cache_opt[dl2].sharing) {
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			sprintf(name, "c%dt%d.ic_l1_l2", core, thread);
			THREAD.ic[0] = ic_create(name);
			ic_add_node(THREAD.ic[0], NULL);
		}
		break;
		
	case cache_percore:
		FOREACH_CORE {
			sprintf(name, "c%d.ic_l1_l2", core);
			CORE.ic[0] = ic_create(name);
			ic_add_node(CORE.ic[0], NULL);
		}
		break;
		
	case cache_shared:
		mt->ic[0] = ic_create("ic.l1_l2");
		ic_add_node(mt->ic[0], NULL);
		break;
	}
	
	/* create l2-mm (ic[1]) interconnect (always only 1 l2_mm interconnect);
	 * insert node with NULL data and id=0, corresonding to 'main memory' */
	mt->ic[1] = ic_create("ic.l2_mm");
	ic_add_node(mt->ic[1], NULL);
	
	/* insert l1-l2 nodes */
	switch (cache_opt[dl1].sharing) {
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			ic = ic_get(mt, core, thread, ic_kind_l1_l2);
			THREAD.node[0] = ic_add_node(ic, THREAD.cache[dl1]);
			debug("interconnect l1-l2: added node %d (c%dt%d)",
				THREAD.node[0], core, thread);
		}
		break;
		
	case cache_percore:
		FOREACH_CORE {
			ic = ic_get(mt, core, 0, ic_kind_l1_l2);
			id = ic_add_node(ic, CORE.cache[dl1]);
			debug("interconnect l1-l2: added node %d (c%d)",
				id, core);
			FOREACH_THREAD
				THREAD.node[0] = id;
		}
		break;
		
	case cache_shared:
		ic = ic_get(mt, 0, 0, ic_kind_l1_l2);
		id = ic_add_node(ic, mt->cache[dl1]);
		debug("interconnect l1-l2: added node %d (full cmp)", id);
		FOREACH_CORE FOREACH_THREAD
			THREAD.node[0] = id;
		break;
	}
	
	/* insert l2-mm nodes */
	switch (cache_opt[dl2].sharing) {
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			ic = ic_get(mt, core, thread, ic_kind_l2_mm);
			THREAD.node[1] = ic_add_node(ic, THREAD.cache[dl2]);
			debug("interconnect l2-mm: added node %d (c%dt%d)",
				THREAD.node[1], core, thread);
		}
		break;
		
	case cache_percore:
		FOREACH_CORE {
			ic = ic_get(mt, core, 0, ic_kind_l2_mm);
			id = ic_add_node(ic, CORE.cache[dl2]);
			debug("interconnect l2-mm: added node %d (c%d)",
				id, core);
			FOREACH_THREAD
				THREAD.node[1] = id;
		}
		break;
		
	case cache_shared:
		ic = ic_get(mt, 0, 0, ic_kind_l2_mm);
		id = ic_add_node(ic, mt->cache[dl2]);
		debug("interconnect l2-mm: added node %d (full cmp)", id);
		FOREACH_CORE FOREACH_THREAD
			THREAD.node[1] = id;
		break;
	}
}


void ic_done(struct mt_t *mt)
{
	int core, thread;
	
	/* free l1-l2 (ic[0]) interconnects */
	switch (cache_opt[dl2].sharing) {
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD
			ic_free(THREAD.ic[0]);
		break;
		
	case cache_percore:
		FOREACH_CORE
			ic_free(CORE.ic[0]);
		break;
		
	case cache_shared:
		ic_free(mt->ic[0]);
		break;
	}
	
	/* free l2-mm (ic[1]) interconnect (always only 1) */
	ic_free(mt->ic[1]);
	
	/* free object repositories */
	repos_free(esim_ic_transfer_repos);
}


int ic_node_count(struct ic_t *ic)
{
	return list_count(ic->nodes);
}


void *ic_node_data(struct ic_t *ic, int id)
{
	struct ic_node_t *node;
	node = list_get(ic->nodes, id);
	assert(!list_error(ic->nodes));
	return node->data;
}




/* Bus Topology */

static void esim_ic_bus_handler(int event, void *data)
{
	if (event == IC_EV_INITIALIZE) {
		
		struct ic_t *ic = data;
		char name[100];
		if (*ic_bus_traffic) {
			sprintf(name, "%s.%s", ic_bus_traffic, ic->name);
			ic->topo.bus.f = fopen(name, "wt");
			if (!ic->topo.bus.f)
				fatal("%s: cannot open file", name);
			esim_schedule_event(IC_EV_UPDATE_STATS, ic, ic_bus_interval);
		}
		
	} else if (event == IC_EV_UPDATE_STATS) {
	
		struct ic_t *ic = data;
		double traffic;
		
		traffic = (double) ic->topo.bus.traffic / (ic_bus_interval * ic_bus_width);
		fprintf(ic->topo.bus.f, "%lld\t%.2e\n", esim_cycle, traffic);
		fflush(ic->topo.bus.f);
		ic->topo.bus.traffic = 0;
		esim_schedule_event(IC_EV_UPDATE_STATS, ic, ic_bus_interval);
		
	} if (event == IC_EV_TRANSFER_START) {
		
		int i, cycles;
		struct esim_ic_transfer_t *cdata = data;
		struct esim_ic_transfer_t *ndata;
		
		/* integrity */
		assert(cdata->repos_id == repos_get_id(esim_ic_transfer_repos));
		assert(C.source >= 0 && C.source < list_count(C.ic->nodes));
		
		/* calculate number of bus cycles needed */
		if (C.ic->topo.bus.ready < esim_cycle)
			C.ic->topo.bus.ready = esim_cycle;
		cycles = (C.size + ic_bus_width - 1) / ic_bus_width;
		C.ic->topo.bus.traffic += C.size;
		C.ic->topo.bus.transfers++;
		C.ic->topo.bus.contention += C.ic->topo.bus.ready - esim_cycle;
		C.ic->topo.bus.ready += cycles;
		
		/* for bcast, schedule n 'recv_event' events */
		if (C.dest == -1 && C.recv_event != ESIM_EV_NONE) {
			for (i = 0; i < list_count(C.ic->nodes); i++) {
				if (i == C.source)
					continue;
				ndata = repos_create_object(esim_ic_transfer_repos);
				assert(ndata);
				memcpy(ndata, cdata, sizeof(struct esim_ic_transfer_t));
				N.dest = i;
				esim_schedule_event(N.recv_event, ndata,
					N.ic->topo.bus.ready - esim_cycle);
			}
		}
		
		/* P2P sends */
		if (C.dest >= 0 && C.recv_event != ESIM_EV_NONE) {
			ndata = repos_create_object(esim_ic_transfer_repos);
			assert(ndata);
			memcpy(ndata, cdata, sizeof(struct esim_ic_transfer_t));
			esim_schedule_event(N.recv_event, ndata,
				N.ic->topo.bus.ready - esim_cycle);
		}
		
		/* schedule end of transfer */
		C.ic->topo.bus.busy += C.ic->topo.bus.ready - esim_cycle;
		esim_schedule_event(IC_EV_TRANSFER_END, cdata,
			C.ic->topo.bus.ready - esim_cycle);
		
	} else if (event == IC_EV_TRANSFER_END) {
		
		/* return to calling function */
		struct esim_ic_transfer_t *cdata = data;
		int oevent = C.return_event;
		void *odata = C.return_data;
		repos_free_object(esim_ic_transfer_repos, cdata);
		esim_schedule_event(oevent, odata, 0);
		
	}
}

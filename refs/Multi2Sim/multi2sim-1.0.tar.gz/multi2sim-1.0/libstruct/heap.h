/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef HEAP_H
#define HEAP_H

/* error constants */
#define HEAP_ENOMEM	1
#define HEAP_EEMPTY	2


struct heap_t;

/* heap extraction policy for elements with same value:
 * fifo: oldest inserted value is extracted first
 * lifo: youngest value first */
enum heap_time_policy_enum {
	heap_time_policy_fifo = 0,	/* default */
	heap_time_policy_lifo
};

/* creation and destruction */
struct heap_t *heap_create(int size);
void heap_free(struct heap_t *heap);

/* return error occurred in last heap operation;
 * 0 means success */
int heap_error(struct heap_t *heap);
char *heap_error_msg(struct heap_t *heap);

/* heap operations */
int heap_count(struct heap_t *heap);
void heap_insert(struct heap_t *heap, long long value, void *data);
long long heap_extract(struct heap_t *heap, void **data);
long long heap_peek(struct heap_t *heap, void **data);
void heap_time_policy(struct heap_t *heap, enum heap_time_policy_enum policy);


#endif

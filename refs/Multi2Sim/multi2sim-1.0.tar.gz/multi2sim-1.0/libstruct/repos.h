/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef REPOS_H
#define REPOS_H

/* Object repository */
struct repos_t;

/* Creation/destruction */
struct repos_t *repos_create(int objsize, char *name);
void repos_free(struct repos_t *repos);

/* Functions to create and free repository objects.
 * The first time an object is created, its memory is allocated
 * with malloc(). When it is freed, no call to free() is made;
 * the object is instead inserted into the repository to be
 * fast returned in a subsequent call to repos_create_object.
 * All objects are free()d when a call to repos_free is made */
void *repos_create_object(struct repos_t *repos);
void repos_free_object(struct repos_t *repos, void *obj);

/* return a unique integer identifier of this 'repos' object;
 * use this to make assertions over objects created by the
 * repository, as a way to make type cast checking */
int repos_get_id(struct repos_t *repos);

#endif

/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "repos.h"

struct repos_obj_t {
	struct repos_obj_t *next;
};


static int repos_current_id = 1000;

struct repos_t {
	char *name;
	int id;
	int objcount;
	int objsize;
	struct repos_obj_t *head;
};


struct repos_t *repos_create(int objsize, char *name)
{
	struct repos_t *repos;
	repos = calloc(1, sizeof(struct repos_t));
	repos->id = repos_current_id++;
	repos->name = name;
	if (!repos || objsize < sizeof(void *))
		return NULL;
	repos->objsize = objsize;
	return repos;
}


void repos_free(struct repos_t *repos)
{
	struct repos_obj_t *next;
	while (repos->head) {
		next = repos->head->next;
		free(repos->head);
		repos->head = next;
		repos->objcount--;
	}
	if (repos->objcount) {
		fprintf(stderr, "warning: %s.repos_free: %d objects from "
			"this repository were not freed\n",
			repos->name, repos->objcount);
	}
	free(repos);
}


void *repos_create_object(struct repos_t *repos)
{
	struct repos_obj_t *obj;
	
	if (!repos->head) {
		repos->head = calloc(1, repos->objsize);
		if (!repos->head)
			return NULL;
		repos->objcount++;
	}
	obj = repos->head;
	repos->head = repos->head->next;
	bzero(obj, repos->objsize);
	return obj;
}


void repos_free_object(struct repos_t *repos, void *obj)
{
	struct repos_obj_t *robj = obj;
	
	if (!robj)
		return;
	robj->next = repos->head;
	repos->head = robj;
}


int repos_get_id(struct repos_t *repos)
{
	return repos->id;
}


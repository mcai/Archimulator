/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef LIST_H
#define LIST_H

/* error constants */
#define LIST_ENOMEM	1
#define LIST_EBOUNDS	2
#define LIST_EELEM	3
#define LIST_EEMPTY	4


struct list_t;

/* creation and destruction */
struct list_t *list_create(int size);
void list_free(struct list_t *list);

/* return error occurred in last list operation;
 * 0 means success */
int list_error(struct list_t *list);
char *list_error_msg(struct list_t *list);

/* list operations */
int list_count(struct list_t *list);
void list_add(struct list_t *list, void *elem);
void *list_get(struct list_t *list, int index);
void list_set(struct list_t *list, int index, void *elem);
void list_insert(struct list_t *list, int index, void *elem);
int list_index_of(struct list_t *list, void *elem);
void *list_remove_at(struct list_t *list, int index);
void *list_remove(struct list_t *list, void *elem);
void list_clear(struct list_t *list);
void list_sort(struct list_t *list);

/* stack operations */
void list_push(struct list_t *list, void *elem);
void *list_pop(struct list_t *list);
void *list_top(struct list_t *list);
void *list_bottom(struct list_t *list);

/* queue operations */
void list_enqueue(struct list_t *list, void *elem);
void *list_dequeue(struct list_t *list);
void *list_tail(struct list_t *list);
void *list_head(struct list_t *list);

/* element comparison function;
 * used for comparisons in 'index_of', 'remove', 'sort' */
typedef int (*list_compare_fn_t)(void *, void *);
void list_compare_fn(struct list_t *list, list_compare_fn_t fn);


#endif

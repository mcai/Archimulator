/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/* bpred.h - branch predictor interfaces */

/* SimpleScalar(TM) Tool Suite
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 * All Rights Reserved. 
 * 
 * THIS IS A LEGAL DOCUMENT, BY USING SIMPLESCALAR,
 * YOU ARE AGREEING TO THESE TERMS AND CONDITIONS.
 * 
 * No portion of this work may be used by any commercial entity, or for any
 * commercial purpose, without the prior, written permission of SimpleScalar,
 * LLC (info@simplescalar.com). Nonprofit and noncommercial use is permitted
 * as described below.
 * 
 * 1. SimpleScalar is provided AS IS, with no warranty of any kind, express
 * or implied. The user of the program accepts full responsibility for the
 * application of the program and the use of any results.
 * 
 * 2. Nonprofit and noncommercial use is encouraged. SimpleScalar may be
 * downloaded, compiled, executed, copied, and modified solely for nonprofit,
 * educational, noncommercial research, and noncommercial scholarship
 * purposes provided that this notice in its entirety accompanies all copies.
 * Copies of the modified software can be delivered to persons who use it
 * solely for nonprofit, educational, noncommercial research, and
 * noncommercial scholarship purposes provided that this notice in its
 * entirety accompanies all copies.
 * 
 * 3. ALL COMMERCIAL USE, AND ALL USE BY FOR PROFIT ENTITIES, IS EXPRESSLY
 * PROHIBITED WITHOUT A LICENSE FROM SIMPLESCALAR, LLC (info@simplescalar.com).
 * 
 * 4. No nonprofit user may place any restrictions on the use of this software,
 * including as modified by the user, by any other authorized user.
 * 
 * 5. Noncommercial and nonprofit users may distribute copies of SimpleScalar
 * in compiled or executable form as set forth in Section 2, provided that
 * either: (A) it is accompanied by the corresponding machine-readable source
 * code, or (B) it is accompanied by a written offer, with no time limit, to
 * give anyone a machine-readable copy of the corresponding source code in
 * return for reimbursement of the cost of distribution. This written offer
 * must permit verbatim duplication by anyone, or (C) it is distributed by
 * someone who received only the executable form, and is accompanied by a
 * copy of the written offer of source code.
 * 
 * 6. SimpleScalar was developed by Todd M. Austin, Ph.D. The tool suite is
 * currently maintained by SimpleScalar LLC (info@simplescalar.com). US Mail:
 * 2395 Timbercrest Court, Ann Arbor, MI 48105.
 * 
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 */


#ifndef BPRED_H
#define BPRED_H

#include <stdio.h>

#include "kernel/misc.h"
#include "kernel/machine.h"

enum bpred_class {
	BPredComb,
	BPred2Level,
	BPred2bit,
	BPredTaken,
	BPredNotTaken,
	BPred_NUM
};

struct bpred_btb_ent_t {
	word	addr;
	enum	md_opcode op;
	word	target;
	struct	bpred_btb_ent_t *prev, *next;
};

struct bpred_dir_t {
	enum	bpred_class class;
	union {
		struct {
			word	size;
			byte	*table;
		} bimod;
		struct {
			int	l1size;
			int	l2size;
			int	shift_width;
			int	xor;
			int	*shiftregs;
			byte	*l2table;
		} two;
	} config;
};

struct bpred_t {
	enum	bpred_class class;
	struct {
		struct	bpred_dir_t *bimod;
		struct	bpred_dir_t *twolev;
		struct	bpred_dir_t *meta;
	} dirpred;

	struct {
		int	sets;
		int	assoc;
		struct	bpred_btb_ent_t *btb_data;
	} btb;

	struct {
		int	size;
		int	tos;
		struct	bpred_btb_ent_t *stack;
	} retstack;

	dword addr_hits;			/* num correct addr-predictions */
	dword dir_hits;				/* num correct dir-predictions (incl addr) */
	dword used_ras;				/* num RAS predictions used */
	dword used_bimod;			/* num bimodal predictions used (BPredComb) */
	dword used_2lev;			/* num 2-level predictions used (BPredComb) */
	dword jr_hits;				/* num correct addr-predictions for JR's */
	dword jr_seen;				/* num JR's seen */
	dword jr_non_ras_hits;			/* num correct addr-preds for non-RAS JR's */
	dword jr_non_ras_seen;			/* num non-RAS JR's seen */
	dword misses;				/* num incorrect predictions */

	dword lookups;				/* num lookups */
	dword retstack_pops;			/* number of times a value was popped */
	dword retstack_pushes;			/* number of times a value was pushed */
	dword ras_hits;				/* num correct return-address predictions */
};


struct bpred_update_t {
	char	*pdir1;				/* direction-1 predictor counter */
	char	*pdir2;				/* direction-2 predictor counter */
	char	*pmeta;				/* meta predictor counter */
	struct {				/* predicted directions */
		word	ras    : 1;		/* RAS used */
		word	bimod  : 1;		/* bimodal predictor */
		word	twolev : 1;		/* 2-level predictor */
		word	meta   : 1;		/* meta predictor (0..bimod / 1..2lev) */
	} dir;
};


/* options */
void bpred_reg_options();

/* creation & destruction */
struct bpred_t *bpred_create();	
void bpred_free(struct bpred_t *bpred);

/* bpred access functions */
word bpred_lookup(struct bpred_t *pred, word baddr, word btarget,
	struct md_instfld_t *instfld, int is_call, int is_return,
	struct bpred_update_t *dir_update_ptr, int *stack_recover_idx);

void bpred_recover(struct bpred_t *pred, word baddr,
	int stack_recover_idx);

void bpred_update(struct bpred_t *pred, word baddr, word btarget,
	int taken, int pred_taken, int correct, struct md_instfld_t *instfld,
	struct bpred_update_t *dir_update_ptr);

#endif /* BPRED_H */

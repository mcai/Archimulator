/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef MT_H
#define MT_H

#include <signal.h>
#include <bfd.h>
#include <list.h>

#include "kernel/public.h"
#include "cache.h"
#include "bpred.h"
#include "ic.h"
#include "mm.h"


/* Extern Definitions */

extern char **environ;

struct mt_t;
struct cache_t;
struct bpred_t;

/* processor parameters */
extern word mt_cores;
extern word mt_threads;
extern word mt_quantum;
extern word mt_switch_penalty;

/* mt_fetch_kind
	timeslice:	each cycle, fetch_width instr are fetched from one different
			thread (round-robin)
	switchonevent:	a thread switch is produced in the fetch stage only by a long latency instr
			or a thread quantum expiration (mt_quantum is used);
			in a switch thread a penalty of 'mt_switch_penalty' cycles is incurred
	multiple:	fetch_width is given out fairly among all non-stalled threads
*/
extern enum mt_fetch_kind_enum {
	mt_fetch_kind_timeslice = 0,
	mt_fetch_kind_switchonevent,
	mt_fetch_kind_multiple
} mt_fetch_kind;

/* mt_fetch_priority (for smt fetch_kind)
	equal:		all threads have the same priority
	icount:		each thread wins priority the less instruction it has in the RUU
*/
extern enum mt_fetch_priority_enum {
	mt_fetch_priority_equal = 0,
	mt_fetch_priority_icount
} mt_fetch_priority;
extern word mt_fetch_width;

/* mt_decode_kind
	shared:		one IFQ; 'decode_width' instr are taken in one cycle
	timeslice:	various IFQs: 'decode_width' instr are taken from one IFQ each cycle
	replicated:	various IFQs: 'decode_width' instr are taken from each IFQ each cycle
*/
extern enum mt_decode_kind_enum {
	mt_decode_kind_shared = 0,
	mt_decode_kind_timeslice,
	mt_decode_kind_replicated
} mt_decode_kind;
extern word mt_decode_width;

/* mt_issue_kind
	shared:		mt->readyq is used to store ready instr from all threads;
			each cycle, mt_issue_width instr are taken
	timeslice:	CTX.readyq is used for each context
			each cycle, mt_issue_width instr are taken in round-robin fashion;
	replicated:	CTX.readyq is used for each context
			each cycle, mt_issue_width instr are taken from all threads
*/
extern enum mt_issue_kind_enum {
	mt_issue_kind_shared = 0,
	mt_issue_kind_timeslice,
	mt_issue_kind_replicated
} mt_issue_kind;
extern word mt_issue_width;

extern enum mt_commit_kind_enum {
	mt_commit_kind_timeslice = 0,
	mt_commit_kind_replicated
} mt_commit_kind;
extern word mt_commit_width;

extern word ifq_size;
extern word ruu_size;
extern word lsq_size;


/* register options */
void mt_reg_options();




/* Register Update Unit Element */
 
struct ruu_elem_t {
	
	/* calculated in mt_fetch() */
	struct	md_instfld_t instfld;
	int	ctx, core, thread;
	dword	seq;
	word	regs_PC, phys_PC;
	word	regs_NPC, regs_NNPC;
	word	pred_NPC, pred_NNPC;
	int	halt;
	int	specmode;
	int	recover_inst;
	int	stack_recover_idx;
	struct	bpred_update_t dir_update;
	word	effaddr;
	
	/* ids of cache access for 'loads' */
	dword	dl1_access_id;
	dword	dtlb_access_id;
	
	/* calculated in mt_decode() */
	int	eacomp;
	int	inlsq;

	/* instruction status */
	int	queued;
	int	issued;
	int	completed;

	/* pysical register file mapping */
	int	ph_in[3];		/* physical input regs */
	int	ph_out[2];		/* physical output regs */
	int	ph_oout[2];		/* old output mappings */
	struct	ruu_link_t *olist;	/* odep list filled by phregs_rename */
	
	/* for free list */
	struct	ruu_elem_t *next;
};

struct ruu_elem_t *ruu_elem_create();
void ruu_elem_free(struct ruu_elem_t *ruu_elem);
void ruu_elem_free_all();
void ruu_elem_dump(struct ruu_elem_t *ruu_elem, FILE *f);

/* functions for ruu_elem lists */
void ruu_list_squash(struct list_t *ruu);
void ruu_list_squash_thread(struct list_t *ruu, int core, int thread);
void ruu_list_dump(struct list_t *ruu, FILE *f);




/* Register Update Unit Element Link */

struct ruu_link_t {
	dword	seq;
	sdword	when;
	struct	ruu_elem_t *ruu_elem;
	struct	ruu_link_t *next;
	int	alloc;
};

#define ruu_link_valid(X) ((X)->seq == (X)->ruu_elem->seq)

struct ruu_link_t *ruu_link_create(struct ruu_elem_t *ruu_elem);
void ruu_link_free(struct ruu_link_t *ruu_link);
void ruu_link_free_all();
void ruu_link_list_free(struct ruu_link_t *ruu_link);
void ruu_link_list_dump(struct ruu_link_t *ruu_link, FILE *f);




/* Functional Units */
 
struct fu_t;

struct fu_t *fu_create();
void fu_free(struct fu_t *fu);

int fu_reserve(struct fu_t *fu, int class);
void fu_release(struct fu_t *fu);
void fu_release_all(struct fu_t *fu);



/* Fetch-Dispatch Queue */

void ifq_reg_options();
void ifq_init(struct mt_t *mt);
void ifq_done(struct mt_t *mt);
struct list_t *ifq_get(struct mt_t *mt, int core, int thread);




/* Ready Queue */

struct readyq_t;

void readyq_init(struct mt_t *mt);
void readyq_done(struct mt_t *mt);
struct readyq_t *readyq_get(struct mt_t *mt, int core, int thread);

struct readyq_t *readyq_create();
void readyq_free(struct readyq_t *readyq);
void readyq_enqueue(struct readyq_t *readyq, struct ruu_elem_t *ruu_elem);
struct ruu_link_t *readyq_clear();
int readyq_count(struct readyq_t *readyq);




/* Event Queue */

struct eventq_t;

struct eventq_t *eventq_create();
void eventq_free(struct eventq_t *eventq);
struct ruu_elem_t *eventq_next(struct eventq_t *eventq, sdword now);
void eventq_enqueue(struct eventq_t *eventq, sdword when, struct ruu_elem_t *ruu_elem);




/* Physical Register File */

struct phregs_t;

void phregs_reg_options();
void phregs_init(struct mt_t *mt);
void phregs_done(struct mt_t *mt);
void phregs_check(struct mt_t *mt, int core);
struct phregs_t *phregs_get(struct mt_t *mt, int core, int thread);

struct phregs_t *phregs_create(int size);
void phregs_free(struct phregs_t *phregs);
int phregs_avail(struct phregs_t *phregs);
void phregs_rename(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem);
void phregs_release(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem);
void phregs_recover(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem);
void phregs_resolve(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem);
int phregs_idep_ready(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem, int idep);
int phregs_ready(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem);




/* Kernel Contexts with Core-Thread Mapping */

struct ctxmap_t;

void ctxmap_init(struct mt_t *mt);
void ctxmap_done(struct mt_t *mt);
int ctxmap_count(struct mt_t *mt);
void ctxmap_ctx(struct mt_t *mt, int ctx, int *core, int *thread);
void ctxmap_unmap(struct mt_t *mt, int core, int thread);
void ctxmap_update(struct mt_t *mt);




/* Multi-Core Multi-Thread Processor */

/* fast access macros */
#define CORE			(mt->core[core])
#define THREAD			(mt->core[core].thread[thread])
#define COREI(I)		(mt->core[(I)])
#define THREADI(I)		(mt->core[core].thread[(I)])
#define FOREACH_CORE		for (core = 0; core < mt_cores; core++)
#define FOREACH_THREAD		for (thread = 0; thread < mt_threads; thread++)

#define MAX_CORES		16
#define MAX_THREADS		16


struct mt_t {

	struct	kernel_t *ke;		/* simulator kernel */
	dword	seq;			/* seq num assigned to last instr (with pre-incr) */
	char	*stage;			/* name of currently simulated stage */
	
	/* structures */
	struct	mm_t *mm;		/* memory management unit */
	struct	ctxmap_t *map;		/* kernel context with core-thread mappings */
	struct	cache_t *cache[6];	/* dl1, dl2, il1, il2, dtlb, itlb */
	struct	ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
	
	/* stats */
	dword	fastfwd_inst;
	dword	fastfwd_cycles;
	dword	fetched;
	dword	decoded;
	dword	issued;
	dword	committed;
	dword	branches;		/* num branches committed */
	dword	misspred;		/* num branches misspredicted */
	dword	cycles;
	double	time;
	
	/* cores */
	struct	{
	
		struct	list_t *ifq;
		struct	readyq_t *readyq;
		struct	eventq_t *eventq;
		struct	phregs_t *phregs;
		struct	fu_t *fu;
		struct	cache_t *cache[6];	/* per core caches */
		struct	ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
	
		/* stages */
		int	fetch_current;		/* for thread switch policy */
		sdword	fetch_switch;		/* for switchonevent */
		int	decode_current;
		int	issue_current;
		int	commit_current;
		
		/* threads */
		struct {
		
			int	ctx;			/* mapped kernel context */
			int	specmode;
			
			/* per thread caches */
			struct	cache_t *cache[6];
		
			/* architected status */
			struct	bpred_t *bpred;		/* branch predictor */
			struct	phregs_t *phregs;	/* physical register file */
			struct	list_t *ifq;		/* fetch-decode queue */
			struct	readyq_t *readyq;	/* ready queue */
			struct	list_t *ruu;		/* register update unit */
			struct	list_t *lsq;		/* load-store queue */
			struct	ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
			
			/* node identifier for each interconnect;
			 * node[0]: id for l1-l2
			 * node[1]: id for l2-mm */
			int	node[2];		/* node identifier in each interconnect */
			
			/* fetch */
			word	fetch_PC, fetch_NPC, fetch_NNPC;
			dword	fetch_il1_access_id;
			dword	fetch_itlb_access_id;
			int	fetch_blk_pending;	/* waiting for resolved miss */
			int	fetch_stall;
			
			/* issue */
			sdword	issue_ready;
			
			/* number of pending main memory accesses; this counter is
			 * updated by cache.c and is useful to apply switch on event fetch */
			int current_mm_accesses;
			
			/* stats */
			dword	fetched;
			dword	decoded;
			dword	issued;
			dword	committed;
			dword	fpcommitted;
			
		} thread[MAX_THREADS];

	} core[MAX_CORES];
};


/* mt functions */
struct mt_t *mt_create();
void mt_free(struct mt_t *mt);
void mt_load_progs(struct mt_t *mt, int argc, char **argv, char *ctxfile);
void mt_start(struct mt_t *mt);
void mt_finish(struct mt_t *mt);
void mt_dump(struct mt_t *mt, FILE *f);

int mt_execute_inst(struct mt_t *mt, int ctx, struct md_instfld_t *instfld);
void mt_fast_forward(struct mt_t *mt, sdword n, int delay);

void mt_fetch(struct mt_t *mt);
void mt_decode(struct mt_t *mt);
void mt_issue(struct mt_t *mt);
void mt_writeback(struct mt_t *mt);
void mt_commit(struct mt_t *mt);

#endif

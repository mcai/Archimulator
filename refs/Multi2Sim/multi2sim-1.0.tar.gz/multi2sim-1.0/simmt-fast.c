/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <signal.h>
#include <mhandle.h>
#include "kernel/public.h"

struct kernel_t *ke;

void handler(int signum)
{
	if (signum == SIGUSR1)
		ke_dump_stats(ke, 1);
	else if (signum == SIGUSR2)
		ke_dump_stats(ke, 2);
}

int main(int argc, char **argv, char **envp)
{
	int ctx, idx;
	
	/* command line */
	if (argc < 2) {
		fprintf(stderr,
			"syntax: %s [-debug <file>] [-ctxconfig <file>] [<exe> [<args>]]\n",
			*argv);
		exit(1);
	}
	
	/* create kernel */
	ke = ke_create();
	
	/* command line */
	for (idx = 1; idx < argc; idx++) {
		if (!strcmp(argv[idx], "-debug")) {
		
			/* debug file */
			if (idx >= argc - 1)
				fatal("'-debug' requires an argument");
			debug_open(argv[++idx]);
			
		} else if (!strcmp(argv[idx], "-ctxconfig")) {
			
			/* load programs from ctx configuration file */
			if (idx >= argc - 1)
				fatal("'-ctxconfig' requires an argument");
			ld_load_progs(ke, argv[++idx]);
			
		} else {
		
			/* option parameters finished;
			 * load a program from command line args */
			ctx = ke_new_ctx(ke);
			ld_add_args(ke, ctx, argc - idx, argv + idx);
			ld_load_prog(ke, ctx, argv[idx]);
			break;
		}
	}
	
	/* we should have some context loaded now */
	if (!ke_active_count(ke))
		fatal("no context loaded");
	
	/* signal handlers */
	signal(SIGUSR1, handler);
	signal(SIGUSR2, handler);
	
	/* run */
	while (ke_active_count(ke)) {
		FOREACH_RUNNING_CTX(ke)
			ke_execute_inst(ke, ctx);
		ke_new_cycle(ke);
	}
	
	/* finalization */
	debug_close();
	ke_free(ke);
	mhandle_done();
	return 0;
}


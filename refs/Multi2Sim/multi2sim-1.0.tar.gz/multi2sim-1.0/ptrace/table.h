/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef TABLE_H
#define TABLE_H

#include <stdio.h>


struct table_t {
	char	name[128];		// Nombre de la tabla
	int	width;
	int	height;
	
	char	***data;		// Matriz de cadenas
	int	data_width;		// Ancho de celda
	
	char	**xlabel;		// Etiquetas de columnas
	char	**ylabel;		// Etiquetas de filas
	char	ylbl_width;		// Ancho de etiqueta de filas
	
	int	xfirst;			// Primer elemento de la tabla en columna
	int	yfirst;			// Primer elemento de la tabla en fila
	int	xhead;			// Primer elemento del vector en columna
	int	yhead;			// Primer elemento del vector en fila
	
	int	total_width;	// Ancho total
	int	total_height;	// Altura total
};


struct table_t *table_create(
	char	*name,
	int	width,
	int	height,
	int	data_width,
	int	ylbl_width);

void table_setcell(
	struct	table_t *t,
	int	x,
	int	y,
	char	*str);

void table_setxlbl(
	struct	table_t *t,
	int	x,
	char	*str);

void table_setylbl(
	struct	table_t *t,
	int	y,
	char	*str);

/* devuelve TRUE si una celda está en rango visible */
int table_visible(
	struct	table_t *t,
	int	x,
	int	y);

/* devuelve la cadena de la etiqueta si está visible (si no, NULL) */
char *table_ylbl(
	struct	table_t *t,
	int	y);
	
void table_print(
	struct	table_t *t,
	FILE	*f);

#endif

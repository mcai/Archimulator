/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef PTRACE_H
#define PTRACE_H

#include <stdio.h>
#include "kernel/misc.h"

/* pipeline stages */
#define PST_IFETCH		"IF"
#define PST_DISPATCH		"DI"
#define PST_EXECUTE		"EX"
#define PST_WRITEBACK		"WB"
#define PST_COMMIT		"C"

/* events */
#define PEV_CACHEMISS		0x00000001
#define PEV_TLBMISS		0x00000002
#define PEV_MPOCCURED		0x00000004
#define PEV_MPDETECT		0x00000008
#define PEV_AGEN		0x00000010


/* open/close trace files */
void ptrace_open();
void ptrace_close();

/* options */
void ptrace_reg_options();

void ptrace_newpc(int ctx, word pc, int specmode);

/* new instr: "+ <seq> <thr> <inst> <pc> <addr>" */
void ptrace_newinst(dword seq, int ctx, word inst,
	word pc, word addr);

/* new micro-instruction: "+ <seq> <thr> <desc> <pc> <addr> */
void ptrace_newuop(dword seq, int ctx, char *desc,
	word pc, word addr);

/* instr ending: "- <seq>" */
void ptrace_endinst(dword iseq);

/* beginning of a new cycle: "@ <cycle>" */
void ptrace_newcycle(sdword cycle);

/* transition to a new stage: "* <seq> <stg> <events>" */
void ptrace_newstage(dword seq, char *pstage, word pevents);


#endif

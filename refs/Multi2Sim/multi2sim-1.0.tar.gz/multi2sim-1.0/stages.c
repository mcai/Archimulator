/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <assert.h>
#include "kernel/public.h"
#include "mt.h"
#include "mm.h"
#include "cache.h"
#include "ptrace.h"
#include "cache.h"



/* Memory Access */

#define DATA_CACHE	0x01
#define INSTR_CACHE	0x02



/* Fetch Stage */

static int mt_can_fetch(struct mt_t *mt, int core, int thread)
{
	/* following conditions must be enforced to fetch:
	 *  1) the kernel context is in state 'running'
	 *  2) the fetch stage is not stalled
	 *  3) the pending cache misses are resolved */
	return THREAD.ctx >= 0 &&
		ke_running(mt->ke, THREAD.ctx) &&
		!THREAD.fetch_stall &&
		cache_completed(THREAD.fetch_il1_access_id) &&
		cache_completed(THREAD.fetch_itlb_access_id);
}


/* return an address that combines the context and the virtual address page;
 * this address will be univocal for all generated
 * addresses and is a kind of hash function to index tlbs */
static word mt_tlb_address(struct mt_t *mt, int ctx, word vaddr)
{
	assert(ctx >= 0 && ctx < mt_cores * mt_threads);
	return (vaddr >> MEM_LOGPAGESIZE) * mt_cores * mt_threads + ctx;
}


static void mt_fetch_inst(struct mt_t *mt, int core, int thread)
{
	word paddr;
	
	/* access instruction cache and tlb */
	mm_translate(mt->mm, ke_memid(mt->ke, THREAD.ctx), THREAD.fetch_NPC, &paddr);
	THREAD.fetch_il1_access_id = cache_access(mt, core, thread,
		il1, paddr, CACHE_READ);
	THREAD.fetch_itlb_access_id = cache_access(mt, core, thread,
		itlb, mt_tlb_address(mt, THREAD.ctx, THREAD.fetch_NPC),
		CACHE_READ);
}


static void mt_fetch_thread(struct mt_t *mt, int core, int thread, int quant)
{
	word inst, phys_PC, dest;
	int ctx, result, done = 0;
	struct regs_t *regs;
	struct mem_t *mem;
	struct md_instfld_t instfld;
	struct ruu_elem_t *ruu_elem;
	struct list_t *ifq = ifq_get(mt, core, thread);
	
	/* can we fetch? */
	if (!mt_can_fetch(mt, core, thread)
		|| !quant
		|| list_count(ifq) == ifq_size)
		return;
	
	/* get thread context */
	ctx = THREAD.ctx;
	assert(ctx >= 0);
	
	/* Read a block from il1 if there was not a previous pending
	 * read. If it was so, we already got the block */
	if (!THREAD.fetch_blk_pending)
		mt_fetch_inst(mt, core, thread);
	THREAD.fetch_blk_pending = 0;
	
	/* If there was a miss (check with mt_can_fetch), we must
	 * wait for the new block */
	if (!mt_can_fetch(mt, core, thread)) {
		THREAD.fetch_blk_pending = 1;
		return;
	}
	
	/* fetch instructions */
	while (quant && !done) {
		
		/* check if context is still running by a call to
		 * mt_can_fetch */
		if (!mt_can_fetch(mt, core, thread))
			break;
		
		/* do we have place in ifq? */
		if (list_count(ifq) == ifq_size)
			break;
	
		/* notify the kernel the next inst it must fetch;
		 * if ke_set_npc return true, specmode execution is starting */
		result = ke_set_npc(mt->ke, ctx, THREAD.fetch_NPC);
		if (result)
			THREAD.specmode = TRUE;
	
		/* fetch instruction from memory */
		THREAD.fetch_PC = THREAD.fetch_NPC;
		THREAD.fetch_NPC = THREAD.fetch_NNPC;
		if (!THREAD.specmode && THREAD.fetch_PC & 3)
			fatal("ctx%d: 0x%x: not aligned pc", ctx, THREAD.fetch_PC);
		mem = ke_mem(mt->ke, ctx);
		mem_read_word(mem, THREAD.fetch_PC & ~3, &inst);
		
		/* functional simulation */
		result = ke_execute_inst(mt->ke, ctx);
		if (!result && !THREAD.specmode)
			fatal("0x%x: not implemented instruction", THREAD.fetch_PC);
		ke_instfld(mt->ke, ctx, &instfld);
		
		/* do we have a new context? */
		if (ke_alive_count(mt->ke) > ctxmap_count(mt))
			ctxmap_update(mt);
		
		/* if npc differs from pc+4 (taken branch in previous inst),
		 * cannot fetch more inst; they are in another cache block */
		if (THREAD.fetch_NPC != THREAD.fetch_PC + 4)
			done = TRUE;
		
		/* if this is the last instruction of a cache block,
		 * stop fetch; we can fetch only instr from a single block */
		if ((THREAD.fetch_PC + 4) % cache_opt[il1].bsize == 0)
			done = TRUE;
		
		/* create element to place in ifq */
		ruu_elem = ruu_elem_create();
			
		/* calculate fetch nnpc */
		regs = ke_regs(mt->ke, ctx);
		mm_translate(mt->mm, ke_memid(mt->ke, ctx), THREAD.fetch_PC, &phys_PC);
		dest = THREAD.bpred ? bpred_lookup(THREAD.bpred, phys_PC,
			0, &instfld, instfld.flags & F_CALL,
			instfld.flags & F_RET, &ruu_elem->dir_update,
			&ruu_elem->stack_recover_idx) : regs->regs_NNPC;
		THREAD.fetch_NNPC = dest <= 1 ? THREAD.fetch_NPC + 4 : dest;
		
		/* insert instruction in fetch-dispatch queue */
		ruu_elem->instfld = instfld;
		ruu_elem->ctx = ctx;
		ruu_elem->core = core;
		ruu_elem->thread = thread;
		ruu_elem->seq = ++mt->seq;
		ruu_elem->phys_PC = phys_PC;
		ruu_elem->regs_PC = THREAD.fetch_PC;
		ruu_elem->regs_NPC = regs->regs_NPC;
		ruu_elem->regs_NNPC = regs->regs_NNPC;
		ruu_elem->pred_NPC = THREAD.fetch_NPC;
		ruu_elem->pred_NNPC = THREAD.fetch_NNPC;
		ruu_elem->halt = ke_finished(mt->ke, ctx);
		ruu_elem->recover_inst = regs->regs_NPC != THREAD.fetch_NPC;
		ruu_elem->specmode = THREAD.specmode;
		ruu_elem->effaddr = ke_effaddr(mt->ke, ctx);
		list_enqueue(ifq, ruu_elem);
		
		/* another instruction fetched */
		mt->fetched++;
		THREAD.fetched++;
		quant--;
		
		/* pipeline */
		ptrace_newinst(mt->seq, ctx, inst, THREAD.fetch_PC, 0);
		ptrace_newstage(mt->seq, PST_IFETCH, 0);
	}
}

static void mt_fetch_core(struct mt_t *mt, int core)
{
	int thread, must_switch, new, count;
	int canfetch[MAX_THREADS], quant[MAX_THREADS];
	sdword cycle;
	
	/* calculate number of running threads in this core */
	count = 0;
	FOREACH_THREAD {
	
		/* decrement fetch locks */
		if (THREAD.fetch_stall)
			THREAD.fetch_stall--;
			
		/* can fetch from this context */
		quant[thread] = 0;
		canfetch[thread] = mt_can_fetch(mt, core, thread);
		if (canfetch[thread])
			count++;
	}
	
	/* cannot fetch from any thread */
	if (!count)
		return;
	
	/* assign quantum to each thread */
	switch (mt_fetch_kind) {
	
	case mt_fetch_kind_multiple:
	
		if (mt_fetch_priority == mt_fetch_priority_icount) {
			
			/* set 3 levels of thread priority:
			 *   level 0: threads with more than 3/4 RUU occupancy
			 *   level 1: threads with 2/4 to 3/4 RUU occupancy
			 *   level 2: threads with 0 to 2/4 RUU occupancy
			 * Fetch 'level' inst from each thread until 'fetch_width'
			 * completes */
			 
			int total = mt_fetch_width;
			int level[MAX_THREADS];
			
			/* assign priority level */
			FOREACH_THREAD {
				level[thread] = 0;
				if (!canfetch[thread])
					continue;
				if (list_count(THREAD.ruu) > ruu_size * 3 / 4) {
					canfetch[thread] = 0;
					count--;
				} else if (list_count(THREAD.ruu) > ruu_size * 2 / 4) {
					level[thread] = 1;
				} else
					level[thread] = 2;
			}
			
			/* we could have no thread to fetch now */
			if (!count)
				return;
			
			/* assign quantums */
			while (total) {
				CORE.fetch_current = thread = (CORE.fetch_current + 1) % mt_threads;
				if (!level[thread])
					continue;
				level[thread] = MIN(level[thread], total);
				quant[thread] += level[thread];
				total -= level[thread];
			}
			
		} else {
		
			/* fetch_priority = mt_fetch_priority_equal */
			int total = mt_fetch_width;
			while (total) {
				CORE.fetch_current = (CORE.fetch_current + 1) % mt_threads;
				if (!canfetch[CORE.fetch_current])
					continue;
				quant[CORE.fetch_current]++;
				total--;
			}
		}
		break;
	
	case mt_fetch_kind_switchonevent:
		
		/* make context switch if:
			a) thread quantum expired
			b) some issued instruction latency exceeds thread switch penalty */
		cycle = ke_cycle(mt->ke);
		thread = CORE.fetch_current;
		must_switch = !ke_running(mt->ke, THREAD.ctx);
		if (cycle - CORE.fetch_switch > mt_quantum ||
			THREAD.issue_ready - cycle > mt_switch_penalty ||
			THREAD.current_mm_accesses ||
			must_switch)
		{
			/* find a new thread to switch to */
			for (new = (thread + 1) % mt_threads; new != thread;
				new = (new + 1) % mt_threads)
			{
				if (canfetch[new]) {
					if (must_switch)
						break;
					if (THREADI(new).issue_ready - cycle < mt_switch_penalty &&
						!THREADI(new).current_mm_accesses)
						break;
				}
			}
				
			/* if thread switch successful */
			if (new != thread) {
				CORE.fetch_current = new;
				CORE.fetch_switch = cycle;
				THREADI(new).fetch_stall = mt_switch_penalty;
			}
		}
			
		/* assign quantum to selected thread */
		quant[CORE.fetch_current] = mt_fetch_width;
		break;
		
	case mt_fetch_kind_timeslice:
		
		do {
			CORE.fetch_current = (CORE.fetch_current + 1) % mt_threads;
		} while (!canfetch[CORE.fetch_current]);
		quant[CORE.fetch_current] = mt_fetch_width;
		break;
	
	}
	
	/* fetch from each thread */
	FOREACH_THREAD
		mt_fetch_thread(mt, core, thread, quant[thread]);
}

void mt_fetch(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_fetch";
	FOREACH_CORE
		mt_fetch_core(mt, core);
}




/* Decode Stage */

static void mt_decode_ifq(struct mt_t *mt, struct list_t *ifq, int quant)
{
	int ctx, core, thread;
	struct ruu_elem_t *ruu_elem, *lsq_elem;
	struct phregs_t *phregs;
	struct readyq_t *readyq;
	
	for ( ; quant; quant--) {
	
		/* are there still elements in the ifq? */
		if (!list_count(ifq))
			break;
		
		/* get entry from ifq */
		ruu_elem = list_head(ifq);
		ctx = ruu_elem->ctx;
		core = ruu_elem->core;
		thread = ruu_elem->thread;
		phregs = phregs_get(mt, core, thread);
		readyq = readyq_get(mt, core, thread);
		
		/* if ruu/lsq full, done */
		if (list_count(THREAD.ruu) == ruu_size ||
			list_count(THREAD.lsq) == lsq_size)
			break;
		
		/* there must be at least 4 physical registers available */
		if (phregs_avail(phregs) < 4)
			break;
		
		/* decode and dispatch instruction */
		list_dequeue(ifq);
		if (ruu_elem->instfld.flags & F_MEM) {
	
			/* create uop to make load/store operation */
			lsq_elem = ruu_elem_create();
			*lsq_elem = *ruu_elem;
			lsq_elem->seq = ++mt->seq;
			lsq_elem->inlsq = TRUE;
			lsq_elem->instfld.in[0] = DTMP;
		
			/* convert ruu_elem to uop that computes effective address */
			ruu_elem->instfld.op = OP_ADD;
			ruu_elem->eacomp = TRUE;
			ruu_elem->instfld.in[1] = DNA;
			ruu_elem->instfld.in[2] = DNA;
			ruu_elem->instfld.out[0] = DTMP;
			ruu_elem->instfld.out[1] = DNA;
		
			/* pipeline trace */
			ptrace_newuop(lsq_elem->seq, lsq_elem->ctx, "ld/st uop",
				lsq_elem->regs_PC, lsq_elem->effaddr);
			ptrace_newstage(lsq_elem->seq, PST_DISPATCH, 0);
		
			/* dispatch */
			phregs_rename(phregs, ruu_elem);
			phregs_rename(phregs, lsq_elem);
			list_enqueue(THREAD.ruu, ruu_elem);
			list_enqueue(THREAD.lsq, lsq_elem);
			assert(!phregs_ready(phregs, lsq_elem));
			if (phregs_ready(phregs, ruu_elem))
				readyq_enqueue(readyq, ruu_elem);
				
		} else {
			phregs_rename(phregs, ruu_elem);
			list_enqueue(THREAD.ruu, ruu_elem);
			if (phregs_ready(phregs, ruu_elem))
				readyq_enqueue(readyq, ruu_elem);
		}
		
		/* another instruction decoded */
		mt->decoded++;
		THREAD.decoded++;
		
		/* new stage */
		ptrace_newstage(ruu_elem->seq, PST_DISPATCH, 0);
	}
}

static void mt_decode_core(struct mt_t *mt, int core)
{
	int new, thread;
	int total, avail[MAX_THREADS], quant[MAX_THREADS];
	
	switch (mt_decode_kind) {

	case mt_decode_kind_shared:
		
		/* for shared decode, take 'decode_width' inst from 'CORE.ifq' */
		mt_decode_ifq(mt, CORE.ifq, mt_decode_width);
		break;
		
	case mt_decode_kind_timeslice:
	
		/* for timeslice decode, take 'decode_width' instr from one 'THREAD.ifq' */
		new = (CORE.decode_current + 1) % mt_threads;
		while (!list_count(THREADI(new).ifq) && new != CORE.decode_current)
			new = (new + 1) % mt_threads;
		CORE.decode_current = new;
		mt_decode_ifq(mt, THREADI(CORE.decode_current).ifq, mt_decode_width);
		break;
	
	case mt_decode_kind_replicated:
		
		/* for replicated decode, take 'decode_width' instr from all 'THREAD.ifq's */
		total = 0;
		FOREACH_THREAD {
			avail[thread] = list_count(THREAD.ifq);
			quant[thread] = 0;
			total += avail[thread];
		}
		
		/* assign quantums */
		total = MIN(total, mt_decode_width);
		while (total) {
			CORE.decode_current = (CORE.decode_current + 1) % mt_threads;
			if (avail[CORE.decode_current]) {
				avail[CORE.decode_current]--;
				quant[CORE.decode_current]++;
				total--;
			}
		};
		
		/* decode */
		FOREACH_THREAD
			mt_decode_ifq(mt, THREAD.ifq, quant[thread]);
		break;
	}
}

void mt_decode(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_decode";
	FOREACH_CORE
		mt_decode_core(mt, core);
}




/* Issue Stage */

#define MAX_STD_UNKNOWNS	64
#define STORE_OP_READY(ELEM)	(phregs_idep_ready(phregs, (ELEM), 0))
#define STORE_ADDR_READY(ELEM)	(phregs_idep_ready(phregs, (ELEM), 1))


static void mt_mem_access(struct mt_t *mt, int core, int thread,
	word addr, int cmd,
	dword *pdl1_access_id,
	dword *pdtlb_access_id)
{
	word paddr;
	dword dl1_access_id, dtlb_access_id;
	
	/* access dl1 and dtlb */
	mm_translate(mt->mm, ke_memid(mt->ke, THREAD.ctx), addr, &paddr);
	dl1_access_id = cache_access(mt, core, thread, dl1, paddr, cmd);
	dtlb_access_id = cache_access(mt, core, thread, dtlb,
		mt_tlb_address(mt, THREAD.ctx, addr), CACHE_READ);
	
	/* return access ids */
	if (pdl1_access_id)
		*pdl1_access_id = dl1_access_id;
	if (pdtlb_access_id)
		*pdtlb_access_id = dtlb_access_id;
}


static void mt_lsq_refresh_thread(struct mt_t *mt, int core, int thread)
{
	int i, j, n_std_unknowns = 0;
	word std_unknowns[MAX_STD_UNKNOWNS];
	struct ruu_elem_t *lsq_elem;
	struct phregs_t *phregs = phregs_get(mt, core, thread);
	struct readyq_t *readyq = readyq_get(mt, core, thread);

	/* search in lsq for ready load's until an unresolved store is found */
	for (i = 0; i < list_count(THREAD.lsq); i++) {
	
		/* get lsq element */
		lsq_elem = list_get(THREAD.lsq, i);
	
		/* if it is a store */
		if (lsq_elem->instfld.flags & F_STORE) {
			if (!STORE_ADDR_READY(lsq_elem))
				break;
			if (!STORE_OP_READY(lsq_elem)) {
				if (n_std_unknowns == MAX_STD_UNKNOWNS)
					panic("increase MAX_STD_UNKNOWNS");
				std_unknowns[n_std_unknowns++] =
					DWORD_ALIGN(lsq_elem->effaddr);
			} else {
				/* we know addr & data; a resolved store shadows
				 * a previous unresolved one */
				for (j = 0; j < n_std_unknowns; j++)
					if (std_unknowns[j] == DWORD_ALIGN(lsq_elem->effaddr))
						std_unknowns[j] = 0;
			}
		}

		/* if it is a load */
		if (lsq_elem->instfld.flags & F_LOAD &&
			!lsq_elem->queued && !lsq_elem->issued &&
			!lsq_elem->completed && phregs_ready(phregs, lsq_elem))
		{
			/* no addr conflict here; check data conflict */
			for (j = 0; j < n_std_unknowns; j++)
				if (std_unknowns[j] == DWORD_ALIGN(lsq_elem->effaddr))
					break;
					
			/* if no conflict, send to readyq */
			if (j == n_std_unknowns)
				readyq_enqueue(readyq, lsq_elem);
		}
	}
}


static void mt_lsq_refresh_core(struct mt_t *mt, int core)
{
	int thread;
	FOREACH_THREAD
		mt_lsq_refresh_thread(mt, core, thread);
}


/* try to schedule a ready instruction;
 * return operation latency
 * or -1 if it cannot be yet scheduled */
static int mt_schedule_inst(struct mt_t *mt, struct ruu_elem_t *ruu_elem)
{
	int core = ruu_elem->core;
	int thread = ruu_elem->thread;
	int lat;
	
	/* load: access memory hierarchy */
	if (ruu_elem->inlsq && (ruu_elem->instfld.flags & F_LOAD)) {
		if (!fu_reserve(CORE.fu, RdPort))
			return 0;
		mt_mem_access(mt, core, thread, ruu_elem->effaddr, CACHE_READ,
			&ruu_elem->dl1_access_id, &ruu_elem->dtlb_access_id);
		return 1;
	}
	
	/* if inst does not require fu, one cycle latency */
	if (!ruu_elem->instfld.fu_class)
		return 1;
	
	/* instr requires a fu: is there a free one? */
	lat = fu_reserve(CORE.fu, ruu_elem->instfld.fu_class);
	if (!lat)
		return 0;
	
	/* fu acquired; return lat */
	return lat;
}


static void mt_issue_readyq(struct mt_t *mt, struct readyq_t *readyq, int quant)
{
	struct ruu_elem_t *ruu_elem;
	struct ruu_link_t *node, *next;
	struct phregs_t *phregs;
	sdword now = ke_cycle(mt->ke);
	int core, thread, lat;
	
	/* if no quantum assigned, exit */
	assert(quant >= 0);
	if (!quant)
		return;
	
	/* clear readyq and issue elements */
	node = readyq_clear(readyq);
	while (quant && node) {
		
		/* is ruu_link valid? */
		next = node->next;
		if (!ruu_link_valid(node)) {
			ruu_link_free(node);
			node = next;
			continue;
		}
			
		/* get readyq element info */
		ruu_elem = node->ruu_elem;
		core = ruu_elem->core;
		thread = ruu_elem->thread;
		phregs = phregs_get(mt, core, thread);
		assert(phregs_ready(phregs, ruu_elem));
		assert(ruu_elem->queued);
		assert(!ruu_elem->issued);
		assert(!ruu_elem->completed);
		ruu_elem->queued = FALSE;
		
		/* try to schedule */
		lat = mt_schedule_inst(mt, ruu_elem);
		if (!lat) {
			ruu_link_free(node);
			node = next;
			readyq_enqueue(readyq, ruu_elem);
			continue;
		}
		
		/* ok, instruction issued */
		ruu_elem->issued = TRUE;
		ptrace_newstage(ruu_elem->seq, PST_EXECUTE, 0);
		eventq_enqueue(CORE.eventq, now + lat, ruu_elem);
		THREAD.issue_ready = MAX(THREAD.issue_ready, now + lat);
		
		/* a new instruction issued */
		mt->issued++;
		THREAD.issued++;
		quant--;
		
		/* free node */
		ruu_link_free(node);
		node = next;
	}
	
	/* re-enqueue not issued elements */
	while (node) {
		node->ruu_elem->queued = FALSE;
		if (ruu_link_valid(node))
			readyq_enqueue(readyq, node->ruu_elem);
		next = node->next;
		ruu_link_free(node);
		node = next;
	}
}


static void mt_issue_core(struct mt_t *mt, int core)
{
	int new, total, thread;
	int avail[MAX_THREADS], quant[MAX_THREADS];
	
	/* decrement fu busy counters */
	fu_release(CORE.fu);
	
	switch (mt_issue_kind) {

	/* for shared issue, take 'issue_width' instr from 'CORE.readyq' */
	case mt_issue_kind_shared:
		
		mt_issue_readyq(mt, CORE.readyq, mt_issue_width);
		break;
		
	/* for timeshared issue, take 'issue_width' instr from one 'THREAD.readyq' */
	case mt_issue_kind_timeslice:
	
		/* find new thread where ready inst exist */
		new = (CORE.issue_current + 1) % mt_threads;
		while (new != CORE.issue_current && !readyq_count(THREADI(new).readyq))
			new = (new + 1) % mt_threads;
		
		/* issue new thread */
		CORE.issue_current = new;
		mt_issue_readyq(mt, THREADI(new).readyq, mt_issue_width);
		break;
	
	/* for replicated issue, take 'issue_width' instr from all 'THREAD.readyq's */
	case mt_issue_kind_replicated:
	
		
		/* number of available inst */
		total = 0;
		FOREACH_THREAD {
			avail[thread] = readyq_count(THREAD.readyq);
			quant[thread] = 0;
			total += avail[thread];
		}
		
		/* assign quantums */
		total = MIN(total, mt_issue_width);
		while (total) {
			CORE.issue_current = (CORE.issue_current + 1) % mt_threads;
			if (avail[CORE.issue_current]) {
				avail[CORE.issue_current]--;
				quant[CORE.issue_current]++;
				total--;
			}
		};
		
		/* issue */
		FOREACH_THREAD
			mt_issue_readyq(mt, THREAD.readyq, quant[thread]);
	}
}


void mt_issue(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_issue";
	FOREACH_CORE {
		mt_issue_core(mt, core);
		mt_lsq_refresh_core(mt, core);
	}
}




/* Writeback Stage */

static void mt_resolve_deps(struct mt_t *mt, struct ruu_elem_t *ruu_elem)
{
	struct ruu_link_t *ruu_link;
	struct ruu_elem_t *odep;
	struct phregs_t *phregs;
	struct readyq_t *readyq;
	
	for (ruu_link = ruu_elem->olist; ruu_link; ruu_link = ruu_link->next) {
	
		/* does it contain a valid ruu_elem reference? */
		if (!ruu_link_valid(ruu_link))
			continue;
		
		/* if odep is a load, do not enqueue it;
		 * this is only done in lsq_refresh */
		odep = ruu_link->ruu_elem;
		if (odep->inlsq && odep->instfld.flags & F_LOAD)
			continue;
		
		/* enqueue instruction; the instruction could be already queued
		 * if it appeared twice in ruu_elem->olist; this case occurs when
		 * an input operand is duplicated for an instruction */
		phregs = phregs_get(mt, odep->core, odep->thread);
		readyq = readyq_get(mt, odep->core, odep->thread);
		if (!odep->queued) {
			assert(!odep->issued);
			if (phregs_ready(phregs, odep))
				readyq_enqueue(readyq, odep);
		}
	}
}


static void mt_writeback_core(struct mt_t *mt, int core)
{
	struct ruu_elem_t *ruu_elem;
	struct phregs_t *phregs;
	sdword now = ke_cycle(mt->ke);
	int thread;

	for (;;) {
	
		/* extract element from event queue */
		ruu_elem = eventq_next(CORE.eventq, now);
		if (!ruu_elem)
			break;
	
		/* check element integrity */
		thread = ruu_elem->thread;
		assert(ruu_elem->core == core);
		phregs = phregs_get(mt, core, thread);
		assert(phregs_ready(phregs, ruu_elem));
		assert(!ruu_elem->queued);
		assert(ruu_elem->issued);
		assert(!ruu_elem->completed);
		
		/* for lsq_elem's: check if element is really completed;
		 * we have to check that pending cache misses are resolved */
		if (ruu_elem->inlsq && (ruu_elem->instfld.flags & F_LOAD)) {
			if (!cache_completed(ruu_elem->dl1_access_id) ||
				!cache_completed(ruu_elem->dtlb_access_id))
			{
				eventq_enqueue(CORE.eventq, now + 1, ruu_elem);
				continue;
			}
		}

		/* writeback */
		ruu_elem->completed = TRUE;
		phregs_resolve(phregs, ruu_elem);
		mt_resolve_deps(mt, ruu_elem);
		
		/* pipeline */
		ptrace_newstage(ruu_elem->seq, PST_WRITEBACK, 0);
	}
}

void mt_writeback(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_writeback";
	FOREACH_CORE
		mt_writeback_core(mt, core);
}




/* Commit Stage */

/* squash ruu & lsq */
static void ruu_squash(struct mt_t *mt, int core, int thread)
{
	struct list_t *ifq;
	struct phregs_t *phregs;
	struct ruu_elem_t *ruu_elem, *lsq_elem;
	int ruu_idx, lsq_idx;
	
	/* squash elements in ifq */
	ifq = ifq_get(mt, core, thread);
	ruu_list_squash_thread(ifq, core, thread);
	THREAD.fetch_stall = 2;
	
	/* physical register file recover */
	phregs = phregs_get(mt, core, thread);
	ruu_idx = list_count(THREAD.ruu);
	lsq_idx = list_count(THREAD.lsq);
	while (ruu_idx) {
		ruu_elem = list_get(THREAD.ruu, --ruu_idx);
		if (ruu_elem->eacomp) {
			lsq_elem = list_get(THREAD.lsq, --lsq_idx);
			phregs_recover(phregs, lsq_elem);
		}
		phregs_recover(phregs, ruu_elem);
	}
	assert(!ruu_idx && !lsq_idx);
	
	/* empty ruu and lsq */
	while (list_count(THREAD.ruu))
		ruu_elem_free(list_dequeue(THREAD.ruu));
	while (list_count(THREAD.lsq))
		ruu_elem_free(list_dequeue(THREAD.lsq));
}

static void mt_commit_thread(struct mt_t *mt, int core, int thread, int quant)
{
	struct regs_t *regs;
	struct ruu_elem_t *ruu_elem, *lsq_elem;
	struct phregs_t *phregs;
	int ctx;
	
	/* if no context mapped, exit */
	ctx = THREAD.ctx;
	if (ctx < 0)
		return;
	
	/* commit */
	phregs = phregs_get(mt, core, thread);
	while (quant) {
	
		/* if no more entries in ruu, cannot commit */
		if (!list_count(THREAD.ruu))
			break;
		
		/* head of line blocking if inst not completed */
		ruu_elem = list_head(THREAD.ruu);
		if (!ruu_elem->completed)
			break;
		
		/* if this is the first instruction in spec mode,
		 * empty reorder buffer */
		if (ruu_elem->specmode) {
		
			assert(THREAD.bpred);
			assert(THREAD.specmode);
			mt->misspred++;
			
			/* Release functional units.
			 * Restore bpred ras pointer with the one stored in the fetch stage
			 * in this ruu_elem (this instruction won't be a jump if assembler
			 * code follows MIPS32 specifications)
			 * Restore simulated memory and register file */
			fu_release_all(CORE.fu);
			bpred_recover(THREAD.bpred, ruu_elem->phys_PC,
				ruu_elem->stack_recover_idx);
			ke_recover(mt->ke, ruu_elem->ctx);
			
			/* regenerate fetch stage status */
			regs = ke_regs(mt->ke, ctx);
			THREAD.specmode = FALSE;
			THREAD.fetch_NPC = regs->regs_NPC;
			THREAD.fetch_NNPC = regs->regs_NNPC;
			
			/* squash pipeline and stop commit */
			ruu_squash(mt, core, thread);
			break;
		}

		/* for memory inst, extract element from lsq */
		if (ruu_elem->eacomp) {
		
			/* if not completed, cannot commit */
			assert(list_count(THREAD.lsq));
			lsq_elem = list_head(THREAD.lsq);
			if (!lsq_elem->completed)
				break;
			
			/* stores access memory here */
			if (lsq_elem->instfld.flags & F_STORE) {
				if (!fu_reserve(CORE.fu, WrPort))
					break;
				mt_mem_access(mt, core, thread, lsq_elem->effaddr,
					CACHE_WRITE, NULL, NULL);
			}

			/* commit lsq entry */
			ptrace_newstage(lsq_elem->seq, PST_COMMIT, 0);
			ptrace_endinst(lsq_elem->seq);
			list_dequeue(THREAD.lsq);
			phregs_release(phregs, lsq_elem);
			ruu_elem_free(lsq_elem);
		}

		/* if it is the last inst of a kernel context */
		if (ruu_elem->halt) {
			ke_kill_ctx(mt->ke, ruu_elem->ctx);
			ctxmap_unmap(mt, core, thread);
			assert(list_count(THREAD.ruu) == 1);
		}
		
		/* update branch predictor */
		if (THREAD.bpred && ruu_elem->instfld.flags & F_CTRL)
			bpred_update(THREAD.bpred,
				ruu_elem->phys_PC,
				ruu_elem->regs_NNPC,
				ruu_elem->regs_NNPC != ruu_elem->regs_NPC + 4,
				ruu_elem->pred_NNPC != ruu_elem->regs_NPC + 4,
				ruu_elem->pred_NNPC == ruu_elem->regs_NNPC,
				&ruu_elem->instfld,
				&ruu_elem->dir_update);

		/* another instruction committed */
		mt->committed++;
		THREAD.committed++;
		if (ruu_elem->instfld.flags & F_FCOMP)
			THREAD.fpcommitted++;
		if (ruu_elem->instfld.flags & F_CTRL)
			mt->branches++;
		
		/* pipeline */
		ptrace_newstage(ruu_elem->seq, PST_COMMIT, 0);
		
		/* retire ruu entry */
		list_dequeue(THREAD.ruu);
		phregs_release(phregs, ruu_elem);
		ruu_elem_free(ruu_elem);
		quant--;
	}
}


static void mt_commit_core(struct mt_t *mt, int core)
{
	int thread, new;
	
	switch (mt_commit_kind) {

	case mt_commit_kind_timeslice:
	
		/* look for a not empty ROB */
		new = (CORE.commit_current + 1) % mt_threads;
		while (new != CORE.commit_current && !list_count(THREADI(new).ruu))
			new = (new + 1) % mt_threads;
		
		/* commit new thread */
		CORE.commit_current = new;
		mt_commit_thread(mt, core, new, mt_commit_width);
		break;
	
	/* for replicated commit, commit 'commit_width' instructions from each ROB */
	case mt_commit_kind_replicated:
	
		FOREACH_THREAD
			mt_commit_thread(mt, core, thread, mt_commit_width);
		break;
	}
}


void mt_commit(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_commit";
	FOREACH_CORE
		mt_commit_core(mt, core);
}

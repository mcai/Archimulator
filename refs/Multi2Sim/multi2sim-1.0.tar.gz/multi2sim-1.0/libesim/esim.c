/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <list.h>
#include <heap.h>
#include <repos.h>
#include <mhandle.h>
#include "esim.h"

static int curr_event = 0;
static int ESIM_EV_INVALID;
static int esim_lock_schedule = 0;

long long int esim_cycle = 0;
int ESIM_EV_NONE;

static struct list_t *event_procs;
static struct heap_t *event_heap;
static struct repos_t *event_repos;


struct event_t {
	int kind;
	void *data;
};


void esim_init()
{
	event_procs = list_create(10);
	event_heap = heap_create(20);
	event_repos = repos_create(sizeof(struct event_t), "event_repos");
	ESIM_EV_INVALID = esim_register_event(NULL);
	ESIM_EV_NONE = esim_register_event(NULL);
}


void esim_done()
{
	list_free(event_procs);
	heap_free(event_heap);
	repos_free(event_repos);
}


int esim_register_event(esim_event_handler_t handler)
{
	list_add(event_procs, handler);
	return curr_event++;
}


void esim_schedule_event(int kind, void *data, int after)
{
	struct event_t *event;
	long long int when = esim_cycle + after;
	
	/* schedule locked? */
	if (esim_lock_schedule)
		return;
	
	/* integrity */
	if (kind < 0 || kind >= list_count(event_procs)) {
		fprintf(stderr, "esim: unknown scheduled event\n");
		abort();
	}
	if (when < esim_cycle) {
		fprintf(stderr, "esim: cycle %lld: event scheduled in the past\n",
			esim_cycle);
		abort();
	}
	if (!kind) {
		fprintf(stderr, "esim: scheduled event of kind 0; esim_register_event forgotten?\n");
		abort();
	}
	
	/* if this is an empty event, ignore it */
	if (kind == ESIM_EV_NONE)
		return;
	
	/* create and insert event */
	event = repos_create_object(event_repos);
	assert(event);
	event->kind = kind;
	event->data = data;
	heap_insert(event_heap, when, event);
}


void esim_execute_event(int kind, void *data)
{
	esim_event_handler_t handler;
	
	/* schedule locked? */
	if (esim_lock_schedule)
		return;
		
	/* integrity */
	if (kind < 0 || kind >= list_count(event_procs)) {
		fprintf(stderr, "esim: unknown scheduled event\n");
		abort();
	}
	if (!kind) {
		fprintf(stderr, "esim: scheduled event of kind 0; esim_register_event forgotten?\n");
		abort();
	}
	if (kind == ESIM_EV_NONE)
		return;
	
	/* execute event handler */
	handler = list_get(event_procs, kind);
	assert(!list_error(event_procs));
	assert(handler);
	handler(kind, data);
}


/* new cycle; process activated events */
void esim_process_events()
{
	long long int when;
	struct event_t *event;
	esim_event_handler_t handler;
	
	/* process events scheduled for this cycle */
	while (1) {
		/* extract event from heap */
		when = heap_peek(event_heap, (void **) &event);
		if (heap_error(event_heap))
			break;
		
		/* must we process it? */
		assert(when >= esim_cycle);
		if (when != esim_cycle)
			break;
		
		/* ok, process it */
		heap_extract(event_heap, NULL);
		handler = list_get(event_procs, event->kind);
		assert(!list_error(event_procs));
		assert(handler);
		handler(event->kind, event->data);
		repos_free_object(event_repos, event);
	}
	
	/* advance cycle counter */
	esim_cycle++;
}


void esim_empty()
{
	struct event_t *event;
	esim_event_handler_t handler;
	
	/* lock event scheduling, so no event will be
	 * inserted into the heap */
	esim_lock_schedule = 1;
	
	/* extract all elements from heap */
	while (1) {
		
		/* extract event */
		heap_extract(event_heap, (void **) &event);
		if (heap_error(event_heap))
			break;
		
		/* process it */
		handler = list_get(event_procs, event->kind);
		assert(!list_error(event_procs));
		assert(handler);
		handler(event->kind, event->data);
		repos_free_object(event_repos, event);
	}
	
	/* unlock event scheduling */
	esim_lock_schedule = 0;
}


long long int esim_extract_event(int *pkind, void **pdata)
{
	struct event_t *event;
	long long int when;
	
	/* extract head of the heap */
	assert(pkind && pdata);
	when = heap_extract(event_heap, (void **) &event);
	if (heap_error(event_heap)) {
		*pkind = 0;
		*pdata = NULL;
		return 0;
	}
	
	/* return event fields */
	*pkind = event->kind;
	*pdata = event->data;
	
	/* free event and return success */
	repos_free_object(event_repos, event);
	return when;
}


int esim_pending()
{
	return heap_count(event_heap);
}

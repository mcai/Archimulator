/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef ESIM_H
#define ESIM_H

/* variable to indicate esim cycle */
extern long long int esim_cycle;

/* empty event; when this event is scheduled,
 * it will be ignored */
extern int ESIM_EV_NONE;

/* procedure to handle an event */
typedef void (*esim_event_handler_t)(int kind, void *data);

/* initialization and finalization */
void esim_init();
void esim_done();

int esim_register_event(esim_event_handler_t handler);
void esim_schedule_event(int kind, void *data, int after);

/* execute *now* an event handler synchronously; this is not the same as
 * calling esim_schedule_event with after=1, where the event will be processed
 * after all pending events for current cycle completed */
void esim_execute_event(int kind, void *data);

/* advance esim cycle and process events of the new cycle */
void esim_process_events();

/* force event extraction; useful to empty event heap before
 * finalization; return false only when heap is empty and
 * extraction failed */
long long int esim_extract_event(int *kind, void **data);

/* return number of events in the heap */
int esim_pending();

/* process esim events, without enabling the schedule of a new event;
 * when all events are processed, esim heap will be empty;
 * esim_cycle is not incremented */
void esim_empty();

#endif

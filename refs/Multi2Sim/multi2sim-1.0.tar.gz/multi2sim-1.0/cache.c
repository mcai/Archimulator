/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <string.h>
#include <assert.h>
#include <esim.h>
#include <repos.h>
#include <mhandle.h>
#include "cache.h"
#include "ic.h"
#include "mt.h"

#define MOESI_REQUEST_SIZE	8


/* MOESI stats */

static dword moesi_block_transfers;
static dword moesi_read_requests;
static dword moesi_write_requests;


/* Cache Parameters */

word	tlb_miss_lat;
word	mem_lat;
word	max_concurrent;
struct	cache_opt_t cache_opt[6];

struct access_info_t {
	struct access_info_t *next;
	int core;
	int thread;
	enum cache_kind_enum kind;
	word addr;
	int cmd;
	sdword esim_cycle_start;
	dword access_id;
};
static struct repos_t *access_info_repos;
static struct access_info_t *access_info_db = NULL;
static dword access_current_id = 1000;


/* Constants */

char	*cache_name[7] = { "dl1", "dl2", "il1", "il2", "dtlb", "itlb", "mm" };
int	cache_level[6] = { 1, 2, 1, 2, 1, 1 };
enum	cache_kind_enum cache_next[6] = { dl2, mainmemory, il2,
		mainmemory, mainmemory, mainmemory };
static char *cache_sopt[6];


/* For ESIM */

#define N	(*ndata)
#define C	(*cdata)

static int CACHE_EV_INITIALIZE;
static int CACHE_EV_UPDATE_STATS;

static struct repos_t *esim_cache_wrapper_repos;
static int CACHE_EV_WRAPPER_START;
static int CACHE_EV_WRAPPER_END;
struct esim_cache_wrapper_t {

	/* debug */
	int repos_id;
	
	/* locals */
	dword access_id;
	
	/* params */
	struct mt_t *mt;
	int core;
	int thread;
	enum cache_kind_enum kind;
	struct cache_t *cache;
	word addr;
	int cmd;
};

static struct repos_t *esim_cache_access_repos;
static int CACHE_EV_ACCESS_WAIT_READY;
static int CACHE_EV_ACCESS_START;
static int CACHE_EV_ACCESS_HIT;
static int CACHE_EV_ACCESS_MISS;
static int CACHE_EV_ACCESS_MISS2;
static int CACHE_EV_ACCESS_MISS3;
static int CACHE_EV_ACCESS_END;
struct esim_cache_access_t {

	/* debug */
	int repos_id;
	
	/* params */
	struct mt_t *mt;
	int core;
	int thread;
	enum cache_kind_enum kind;
	struct cache_t *cache;
	struct cache_opt_t *opt;
	struct cache_blk_t *blk, *repl;
	word addr, tag, set;
	int cmd;
	
	/* return */
	int return_event;
	void *return_data;
};


static struct repos_t *esim_moesi_action_repos;
static int CACHE_EV_MOESI_ACTION_START;
static int CACHE_EV_MOESI_ACTION_INVALIDREAD_START;
static int CACHE_EV_MOESI_ACTION_INVALIDREAD_ACCESS;
static int CACHE_EV_MOESI_ACTION_INVALIDREAD_TRANSFER;
static int CACHE_EV_MOESI_ACTION_INVALIDREAD_END;
static int CACHE_EV_MOESI_ACTION_END;
struct esim_moesi_action_t {

	/* debug */
	int repos_id;
	
	/* params */
	struct mt_t *mt;
	int core;
	int thread;
	struct cache_t *cache;
	struct cache_blk_t *blk;
	int cmd;
	
	/* locals */
	int count;
	struct ic_t *ic;
	int node;
	
	/* return */
	int return_event;
	void *return_data;
};


static struct repos_t *esim_moesi_request_repos;
static int CACHE_EV_MOESI_REQUEST_START;
static int CACHE_EV_MOESI_REQUEST_RECV;
static int CACHE_EV_MOESI_REQUEST_CONFIRM;
static int CACHE_EV_MOESI_REQUEST_END;
struct esim_moesi_request_t {

	/* debug */
	int repos_id;
	
	/* params */
	struct mt_t *mt;
	int core;
	int thread;
	struct cache_t *cache;
	struct cache_blk_t *blk;
	int cmd;
	int *pcount;		/* return here num of caches containing the blk */
	
	/* locals */
	struct ic_t *ic;
	int node;
	int recv_pending;	/* pending number of nodes to receive request */
	
	/* return */
	int return_event;
	void *return_data;
};


/* options */
void cache_reg_options()
{
	/* cache hierarchy */
	opt_reg_string("-dl1", "level 1 data cache",
		       &cache_sopt[dl1], "512:64:2:l:c:1");
	opt_reg_string("-dl2", "level 2 data cache",
		       &cache_sopt[dl2], "2048:64:4:l:s:10");
	opt_reg_string("-il1", "level 1 instructions cache",
		       &cache_sopt[il1], "512:64:2:l:c:1");
	opt_reg_string("-il2", "level 2 instructions cache",
		       &cache_sopt[il2], "dl2");
	opt_reg_string("-dtlb", "data tlb config",
		       &cache_sopt[dtlb], "1024:4:4:l:c:1");
	opt_reg_string("-itlb", "instructions tlb config",
		       &cache_sopt[itlb], "1024:4:4:l:c:1");
	
	/* latencies */
	opt_reg_word("-tlb_miss_lat", "tlb miss latency",
		&tlb_miss_lat, 30);
	opt_reg_word("-mem_latency", "latency of an access to main memory",
		&mem_lat, 200);
	opt_reg_word("-max_concurrent", "maximum concurrent accesses to a cache",
		&max_concurrent, 1);
	
}


static void extract_opt(enum cache_kind_enum kind, char *sopt)
{
	int error = FALSE;
	char policy, sharing;
	char *name = cache_name[kind];
	struct cache_opt_t *opt = &cache_opt[kind];
	
	/* unified level 1 cache */
	if (kind == il1 && !strcmp(sopt, "dl1")) {
		cache_opt[dl1].unified = TRUE;
		cache_opt[il1] = cache_opt[dl1];
		return;
	}
	
	/* unified level 2 cache */
	if (kind == il2 && !strcmp(sopt, "dl2")) {
		cache_opt[dl2].unified = TRUE;
		cache_opt[il2] = cache_opt[dl2];
		return;
	}
	
	/* unified tlb */
	if (kind == itlb && !strcmp(sopt, "dtlb")) {
		cache_opt[dtlb].unified = TRUE;
		cache_opt[itlb] = cache_opt[dtlb];
		return;
	}
	
	/* normal case */
	opt->unified = FALSE;
	if (sscanf(sopt, "%u:%u:%u:%c:%c:%u",
		&opt->nsets,
		&opt->bsize,
		&opt->assoc,
		&policy,
		&sharing,
		&opt->lat) != 6)
		error = TRUE;
	opt->logbsize = log_base2(opt->bsize);
	opt->logassoc = log_base2(opt->assoc);
	opt->lognsets = log_base2(opt->nsets);
	opt->bmask = (1 << opt->logbsize) - 1;

	if (!error) {
		switch (policy) {
		case 'l': opt->policy = cache_policy_lru; break;
		case 'r': opt->policy = cache_policy_random; break;
		case 'f': opt->policy = cache_policy_fifo; break;
		default: error = TRUE;
		}
	}
	
	if (!error) {
		switch (sharing) {
		case 't': opt->sharing = cache_perthread; break;
		case 'c': opt->sharing = cache_percore; break;
		case 's': opt->sharing = cache_shared; break;
		default: error = TRUE;
		}
	}
	
	/* constraints */
	if (opt->nsets <= 0)
		fatal("%s: nsets must be > 0", name);
	if ((opt->nsets & (opt->nsets - 1)))
		fatal("%s: nsets must be power of 2", name);
	if (opt->bsize < 1)
		fatal("%s: bsize must be >= 1", name);
	if ((opt->bsize & (opt->bsize - 1)))
		fatal("%s: bsize must be power of 2", name);
	if (opt->assoc <= 0)
		fatal("%s: assoc must be > 0", name);
	if ((opt->assoc & (opt->assoc - 1)))
		fatal("%s: assoc must be power of 2", name);
	
	/* error message */
	if (!error)
		return;
	fatal("%s configuration not valid\n\n"
	"cache format: <nsets>:<bsize>:<assoc>:<repl>:<shar>:<lat> | dl1 | dl2\n"
	"\tdl1    for il1 means that cache dl1 & il1 are unified\n"
	"\tdl2    for il2 means that cache dl2 & il2 are unified\n\n"
	"tlb format: <nsets>:<bsize>:<assoc>:<repl>:<shar>:<lat> | dtlb\n"
	"\tdtlb   for itlb means that dtlb & itlb are unified\n\n"
	"parameters:\n"
	"\t<nsets>  number of sets\n"
	"\t<bsize>  block size\n"
	"\t<assoc>  associativity\n"
	"\t<repl>   replacement policy (l=lru, f=fifo, r=random)\n"
	"\t<shar>   cache sharing among cores (p=private, s=shared)\n"
	"\t<lat>    hit latency\n", cache_name[kind]);
}


static dword access_info_start(int core, int thread,
	enum cache_kind_enum kind, word addr, int cmd)
{
	struct access_info_t *access_info;
	access_info = repos_create_object(access_info_repos);
	access_info->next = access_info_db;
	access_info->access_id = access_current_id;
	access_info->core = core;
	access_info->thread = thread;
	access_info->kind = kind;
	access_info->addr = addr;
	access_info->cmd = cmd;
	access_info->esim_cycle_start = esim_cycle;
	access_info_db = access_info;
	return access_current_id++;
}


static void access_info_end(dword access_id)
{
	struct access_info_t *access_info, *prev;
	
	prev = NULL;
	access_info = access_info_db;
	while (access_info && access_info->access_id != access_id) {
		prev = access_info;
		access_info = access_info->next;
	}
	assert(access_info);
	if (prev)
		prev->next = access_info->next;
	else
		access_info_db = access_info->next;
	repos_free_object(access_info_repos, access_info);
}


/* way list management */
enum list_loc_t {
	Head,
	Tail
};

static void update_way_list(
	struct	cache_set_t *set,
	struct	cache_blk_t *blk,
	enum	list_loc_t where)
{
	if (!blk->way_prev && !blk->way_next) {
		assert(set->way_head == blk && set->way_tail == blk);
		return;
		
	} else if (!blk->way_prev) {
		assert(set->way_head == blk && set->way_tail != blk);
		if (where == Head)
			return;
		set->way_head = blk->way_next;
		blk->way_next->way_prev = NULL;
		
	} else if (!blk->way_next) {
		assert(set->way_head != blk && set->way_tail == blk);
		if (where == Tail)
			return;
		set->way_tail = blk->way_prev;
		blk->way_prev->way_next = NULL;
		
	} else {
		assert(set->way_head != blk && set->way_tail != blk);
		blk->way_prev->way_next = blk->way_next;
		blk->way_next->way_prev = blk->way_prev;
	}

	if (where == Head) {
		blk->way_next = set->way_head;
		blk->way_prev = NULL;
		set->way_head->way_prev = blk;
		set->way_head = blk;
	} else if (where == Tail) {
		blk->way_prev = set->way_tail;
		blk->way_next = NULL;
		set->way_tail->way_next = blk;
		set->way_tail = blk;
	} else
		panic("cache.c: bogus list location");
}


static struct cache_t *cache_get(struct mt_t *mt, int core,
	int thread, enum cache_kind_enum kind)
{
	assert(kind != mainmemory);
	switch (cache_opt[kind].sharing) {
	
	case cache_perthread:
		return THREAD.cache[kind];
	case cache_percore:
		return CORE.cache[kind];
	default:
		return mt->cache[kind];
	
	}
}


static void cache_reg_stats(struct cache_t *cache, int core, int thread)
{
	char buf[128], frm[128];
	char name[128];
	
	/* compute cache name */
	switch (cache_opt[cache->kind].sharing) {
	case cache_perthread:
		sprintf(name, "c%dt%d.%s", core, thread, cache_name[cache->kind]);
		break;
	case cache_percore:
		sprintf(name, "c%d.%s", core, cache_name[cache->kind]);
		break;
	default:
		strcpy(name, cache_name[cache->kind]);
	}

	sprintf(buf, "%s.accesses", name);
	sprintf(frm, "%s.hits + %s.misses", name, name);
	stat_reg_formula(buf, "total number accesses", frm, "%.0f");
	
	sprintf(buf, "%s.hits", name);
	stat_reg_dword(buf, "total number of hits",
		&cache->hits, 0, NULL);
	
	sprintf(buf, "%s.misses", name);
	stat_reg_dword(buf, "total number of misses",
		&cache->misses, 0, NULL);
		
	sprintf(buf, "%s.hitrate", name);
	sprintf(frm, "%s.hits / %s.accesses",
		name, name);
	stat_reg_formula(buf, "hit rate", frm, "%.4f");
	
	sprintf(buf, "%s.reads", name);
	stat_reg_dword(buf, "total number of reads",
		&cache->reads, 0, NULL);
	
	sprintf(buf, "%s.writes", name);
	stat_reg_dword(buf, "total number of writes",
		&cache->writes, 0, NULL);
	
	sprintf(buf, "%s.evicts", name);
	stat_reg_dword(buf, "total number of block evicts",
		&cache->evicts, 0, NULL);
	
	sprintf(buf, "%s.readreq", name);
	stat_reg_dword(buf, "read requests sent to the interconnect",
		&cache->readreq, 0, NULL);
	
	sprintf(buf, "%s.writereq", name);
	stat_reg_dword(buf, "write requests sent to the interconnect",
		&cache->writereq, 0, NULL);
	
	sprintf(buf, "%s.moesi.modified", name);
	stat_reg_double(buf, "average fraction of blocks with modified status",
		&cache->moesi_rate[0], 0, NULL);
		
	sprintf(buf, "%s.moesi.owned", name);
	stat_reg_double(buf, "average fraction of blocks with owned status",
		&cache->moesi_rate[1], 0, NULL);
	
	sprintf(buf, "%s.moesi.exclusive", name);
	stat_reg_double(buf, "average fraction of blocks with exclusive status",
		&cache->moesi_rate[2], 0, NULL);
		
	sprintf(buf, "%s.moesi.shared", name);
	stat_reg_double(buf, "average fraction of blocks with shared status",
		&cache->moesi_rate[3], 0, NULL);
	
	sprintf(buf, "%s.moesi.invalid", name);
	stat_reg_double(buf, "average fraction of blocks with invalid status",
		&cache->moesi_rate[4], 0, NULL);
}


static struct cache_t *cache_create(enum cache_kind_enum kind, int core, int thread)
{
	struct cache_t *cache;
	struct cache_opt_t *opt = &cache_opt[kind];
	struct cache_blk_t *blk;
	int i, j;
	
	/* create cache and blocks */
	cache = calloc(1, sizeof(struct cache_t));
	cache->kind = kind;
	cache->sets = calloc(opt->nsets, sizeof(struct cache_set_t));
	for (i = 0; i < opt->nsets; i++) {
		cache->sets[i].blks = calloc(opt->assoc, sizeof(struct cache_blk_t));
		cache->sets[i].way_head = &cache->sets[i].blks[0];
		cache->sets[i].way_tail = &cache->sets[i].blks[opt->assoc - 1];
		for (j = 0; j < opt->assoc; j++) {
			blk = &cache->sets[i].blks[j];
			blk->way_prev = j ? &cache->sets[i].blks[j - 1] : NULL;
			blk->way_next = j < opt->assoc - 1 ? &cache->sets[i].blks[j + 1] : NULL;
			blk->status = CACHE_BLK_INVALID;
			cache->moesi_count[CACHE_BLK_INVALID]++;
		}
	}
	
	/* stats */
	cache_reg_stats(cache, core, thread);
	esim_schedule_event(CACHE_EV_INITIALIZE, cache, 0);
	return cache;
}


static void cache_free(struct cache_t *cache)
{
	int i;
	struct cache_opt_t *opt = &cache_opt[cache->kind];
	for (i = 0; i < opt->nsets; i++)
		free(cache->sets[i].blks);
	free(cache->sets);
	free(cache);
}


static struct cache_blk_t *cache_find_blk(struct cache_t *cache, word tag)
{
	struct cache_blk_t *blk;
	struct cache_opt_t *opt = &cache_opt[cache->kind];
	word set = (tag >> opt->logbsize) % opt->nsets;
	
	/* search block */
	for (blk = cache->sets[set].way_head; blk; blk = blk->way_next)
		if (blk->tag == tag && blk->status != CACHE_BLK_INVALID)
			break;
	return blk;
}


static void cache_blk_set_status(struct cache_t *cache, struct cache_blk_t *blk, int status)
{
	cache->moesi_count[blk->status]--;
	assert(cache->moesi_count[blk->status] >= 0);
	cache->moesi_count[status]++;
	blk->status = status;
}


/* ESIM moesi_request */

static void esim_moesi_request(int event, void *data)
{
	if (event == CACHE_EV_MOESI_REQUEST_START) {
	
		struct esim_moesi_request_t *cdata = data;
		struct esim_ic_transfer_t *ndata;
		assert(cdata->repos_id == repos_get_id(esim_moesi_request_repos));
		
		/* command must be read/write */
		assert(C.cmd == CACHE_READ || C.cmd == CACHE_WRITE);
		assert(cache_level[C.cache->kind] == 1 || cache_level[C.cache->kind] == 2);
		
		/* get corresponding interconnect & source id */
		C.ic = cache_level[C.cache->kind] == 1 ?
			ic_get(C.mt, C.core, C.thread, ic_kind_l1_l2) :
			ic_get(C.mt, C.core, C.thread, ic_kind_l2_mm);
		C.node = cache_level[C.cache->kind] == 1 ?
			C.mt->core[C.core].thread[C.thread].node[0] :
			C.mt->core[C.core].thread[C.thread].node[1];
		C.recv_pending = ic_node_count(C.ic) - 2;
		
		/* is there some node to broadcast? */
		assert(C.recv_pending >= 0);
		if (!C.recv_pending) {
			if (C.pcount)
				*(C.pcount) = 0;
			esim_schedule_event(CACHE_EV_MOESI_REQUEST_END, cdata, 0);
			return;
		}
		
		/* stats */
		switch (C.cmd) {
		case CACHE_READ:
			moesi_read_requests++;
			C.cache->readreq++;
			break;
		case CACHE_WRITE:
			moesi_write_requests++;
			moesi_block_transfers++;
			C.cache->writereq++;
			break;
		}
	
		/* start a new interconnect broadcast */
		ndata = repos_create_object(esim_ic_transfer_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_ic_transfer_repos);
		N.ic = C.ic;
		N.source = C.node;
		N.dest = -1;
		N.size = MOESI_REQUEST_SIZE + (C.cmd == CACHE_WRITE ?
			cache_opt[C.cache->kind].bsize : 0);
		N.recv_event = CACHE_EV_MOESI_REQUEST_RECV;
		N.recv_data = cdata;		/* type: struct esim_moesi_request_t */
		N.return_event = ESIM_EV_NONE;
		N.return_data = NULL;
		esim_schedule_event(IC_EV_TRANSFER_START, ndata, 0);
		
	} else if (event == CACHE_EV_MOESI_REQUEST_RECV) {
	
		struct esim_ic_transfer_t *tdata = data, *ndata;
		struct esim_moesi_request_t *cdata = tdata->recv_data;
		struct cache_t *cache;
		struct cache_blk_t *blk;
		int source, dest, send = FALSE;
		
		assert(cdata->repos_id == repos_get_id(esim_moesi_request_repos));
		assert(tdata->repos_id == repos_get_id(esim_ic_transfer_repos));
		
		/* free transfer data; we only need the 'dest' and 'source' fields,
		 * so we get them in a local variable */
		source = tdata->source;
		dest = tdata->dest;
		repos_free_object(esim_ic_transfer_repos, tdata);
		
		/* an interconnect node received the request sent by the previous
		 * broadcast; get the field 'data' from this node, which corresponds
		 * to the cache */
		cache = ic_node_data(C.ic, dest);
		
		/* if the node data is NULL, the node is actually the next level cache
		 * or the main memory back end, so it must ignore the MOESI request */
		if (!cache)
			return;
		
		/* find block in the current cache;
		 * if block does not exist, send an empty confirmation */
		blk = cache_find_blk(cache, C.blk->tag);
		if (!blk) {
			ndata = repos_create_object(esim_ic_transfer_repos);
			assert(ndata);
			N.repos_id = repos_get_id(esim_ic_transfer_repos);
			N.ic = C.ic;
			N.source = dest;
			N.dest = source;
			N.size = MOESI_REQUEST_SIZE;
			N.recv_event = ESIM_EV_NONE;
			N.recv_data = NULL;
			N.return_event = CACHE_EV_MOESI_REQUEST_CONFIRM;
			N.return_data = cdata;
			esim_schedule_event(IC_EV_TRANSFER_START, ndata, 0);
			return;
		}
		
		/* block exists; update value pointed by 'pcount' */
		if (C.pcount)
			*(C.pcount)++;
		
		/* process moesi request */
		switch (blk->status) {
		
		case CACHE_BLK_MODIFIED:
		
			/* Read req: send data, status=owned */
			if (C.cmd == CACHE_READ) {
				send = TRUE;
				cache_blk_set_status(cache, blk, CACHE_BLK_OWNED);
			}
			
			/* Write req: send data, status=invalid */
			if (C.cmd == CACHE_WRITE) {
				send = TRUE;
				cache_blk_set_status(cache, blk, CACHE_BLK_INVALID);
			}
			break;
		
		case CACHE_BLK_EXCLUSIVE:
			
			/* Read req: send data, status=shared */
			if (C.cmd == CACHE_READ) {
				send = TRUE;
				cache_blk_set_status(cache, blk, CACHE_BLK_SHARED);
			}
			
			/* Write req: send data, status=invalid */
			if (C.cmd == CACHE_WRITE) {
				send = TRUE;
				cache_blk_set_status(cache, blk, CACHE_BLK_INVALID);
			}
			break;
		
		case CACHE_BLK_OWNED:
			
			/* Read req: send data */
			if (C.cmd == CACHE_READ)
				send = TRUE;
			
			/* Write req: send data, status=invalid */
			if (C.cmd == CACHE_WRITE) {
				send = TRUE;
				cache_blk_set_status(cache, blk, CACHE_BLK_INVALID);
			}
			break;
		
		case CACHE_BLK_SHARED:
			
			/* Read req: none */
			/* Write req: status=invalid */
			if (C.cmd == CACHE_WRITE)
				cache_blk_set_status(cache, blk, CACHE_BLK_INVALID);
			break;
		
		case CACHE_BLK_INVALID:
		
			/* Read req: none */
			/* Write req: none */
			break;
		
		}
		
		/* moesi stats */
		if (send)
			moesi_block_transfers++;
		
		/* send confirmation to broadcaster node; we must also
		 * send the block if 'send' == 1 */
		ndata = repos_create_object(esim_ic_transfer_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_ic_transfer_repos);
		N.ic = C.ic;
		N.source = dest;
		N.dest = source;
		N.size = MOESI_REQUEST_SIZE + (send ?
			cache_opt[cache->kind].bsize : 0);
		N.recv_event = ESIM_EV_NONE;
		N.recv_data = NULL;
		N.return_event = CACHE_EV_MOESI_REQUEST_CONFIRM;
		N.return_data = cdata;
		esim_schedule_event(IC_EV_TRANSFER_START, ndata, 0);
	
	} else if (event == CACHE_EV_MOESI_REQUEST_CONFIRM) {
	
		struct esim_moesi_request_t *cdata = data;
		assert(cdata->repos_id == repos_get_id(esim_moesi_request_repos));
		
		/* a confirmation was received; we decrement the counter of
		 * pending receptions; if we reach 0, we are done */
		assert(C.recv_pending > 0);
		C.recv_pending--;
		if (!C.recv_pending)
			esim_schedule_event(CACHE_EV_MOESI_REQUEST_END, cdata, 0);
		
	} else if (event == CACHE_EV_MOESI_REQUEST_END) {
	
		struct esim_moesi_request_t *cdata = data;
		assert(cdata->repos_id == repos_get_id(esim_moesi_request_repos));
		
		/* return to calling function */
		int oevent = C.return_event;
		void *odata = C.return_data;
		repos_free_object(esim_moesi_request_repos, cdata);
		esim_schedule_event(oevent, odata, 0);
		
	} else
		panic("moesi_request: unknown esim event");
}


/* ESIM moesi_action */

static void esim_moesi_action(int event, void *data)
{
	struct esim_moesi_action_t *cdata = data;
	
	if (event == CACHE_EV_MOESI_ACTION_START) {
	
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));
		
		/* stats */
		switch (C.cmd) {
			case CACHE_READ:
				C.cache->reads++;
				break;
			case CACHE_WRITE:
				C.cache->writes++;
				break;
			case CACHE_EVICT:
				C.cache->evicts++;
				break;
			default: panic("unknown cmd");
		}
	
	
		/* MOESI protocol depending on block status and cmd */	
		switch (C.blk->status) {
	
		case CACHE_BLK_MODIFIED:
		
			/* Read: hit. */
			if (C.cmd == CACHE_READ) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Write: hit */
			else if (C.cmd == CACHE_WRITE) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Evict: writeback, state=invalid */
			else if (C.cmd == CACHE_EVICT) {
				struct esim_cache_access_t *ndata;
			
				/* asynchronous writeback; need no callback event */
				ndata = repos_create_object(esim_cache_access_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_cache_access_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.kind = cache_next[C.cache->kind];
				N.addr = C.blk->tag;
				N.cmd = CACHE_WRITE;
				N.return_event = ESIM_EV_NONE;
				N.return_data = NULL;
				esim_schedule_event(CACHE_EV_ACCESS_START, ndata, 0);
				
				/* cache block is now invalid */
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_INVALID);
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			} else
				panic("unknown cmd");
			break;
	
		case CACHE_BLK_EXCLUSIVE:
	
			/* Read: hit */
			if (C.cmd == CACHE_READ) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Write: hit, state=modified */
			else if (C.cmd == CACHE_WRITE) {
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_MODIFIED);
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Evict: silent evict, state=invalid */
			else if (C.cmd == CACHE_EVICT) {
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_INVALID);
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			
			} else
				panic("unknown cmd");
			break;
	
		case CACHE_BLK_OWNED:
			
			/* Read: hit */
			if (C.cmd == CACHE_READ) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Write: write request, state=modified */
			else if (C.cmd == CACHE_WRITE) {
				struct esim_moesi_request_t *ndata;
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_MODIFIED);
				
				ndata = repos_create_object(esim_moesi_request_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_moesi_request_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.cache = C.cache;
				N.blk = C.blk;
				N.cmd = CACHE_WRITE;
				N.pcount = NULL;
				N.return_event = CACHE_EV_MOESI_ACTION_END;
				N.return_data = cdata;
				esim_schedule_event(CACHE_EV_MOESI_REQUEST_START, ndata, 0);
			}
		
			/* Evict: writeback, state=invalid */
			else if (C.cmd == CACHE_EVICT) {
				struct esim_cache_access_t *ndata;
			
				/* asynchronous writeback; need no callback event */
				ndata = repos_create_object(esim_cache_access_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_cache_access_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.kind = cache_next[C.cache->kind];
				N.addr = C.blk->tag;
				N.cmd = CACHE_WRITE;
				N.return_event = ESIM_EV_NONE;
				N.return_data = NULL;
				esim_schedule_event(CACHE_EV_ACCESS_START, ndata, 0);
				
				/* cache block is now invalid */
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_INVALID);
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			else
				panic("unknown cmd");
			break;
	
		case CACHE_BLK_SHARED:
			
			/* Read: hit */
			if (C.cmd == CACHE_READ) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			/* Write: write request, state=modified */
			else if (C.cmd == CACHE_WRITE) {
				struct esim_moesi_request_t *ndata;
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_MODIFIED);
				
				ndata = repos_create_object(esim_moesi_request_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_moesi_request_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.cache = C.cache;
				N.blk = C.blk;
				N.cmd = CACHE_WRITE;
				N.pcount = NULL;
				N.return_event = CACHE_EV_MOESI_ACTION_END;
				N.return_data = cdata;
				esim_schedule_event(CACHE_EV_MOESI_REQUEST_START, ndata, 0);
			}
			
			/* Evict: silent evict, state=invalid */
			else if (C.cmd == CACHE_EVICT) {
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_INVALID);
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			else
				panic("unknown cmd");
			break;
	
		case CACHE_BLK_INVALID:
			
			/* Read: read request (response=shared) state=shared
			 * or:   read request (response=clean) state=exclusive */
			if (C.cmd == CACHE_READ) {
				struct esim_moesi_request_t *ndata;
				ndata = repos_create_object(esim_moesi_request_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_moesi_request_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.cache = C.cache;
				N.blk = C.blk;
				N.cmd = CACHE_READ;
				N.pcount = &C.count;
				N.return_event = CACHE_EV_MOESI_ACTION_INVALIDREAD_START;
				N.return_data = cdata;
				esim_schedule_event(CACHE_EV_MOESI_REQUEST_START, ndata, 0);
			}
			
			/* Write: write request, state=modified */
			else if (C.cmd == CACHE_WRITE) {
				struct esim_moesi_request_t *ndata;
				cache_blk_set_status(C.cache, C.blk, CACHE_BLK_MODIFIED);
				
				ndata = repos_create_object(esim_moesi_request_repos);
				assert(ndata);
				N.repos_id = repos_get_id(esim_moesi_request_repos);
				N.mt = C.mt;
				N.core = C.core;
				N.thread = C.thread;
				N.cache = C.cache;
				N.blk = C.blk;
				N.cmd = CACHE_WRITE;
				N.pcount = NULL;
				N.return_event = CACHE_EV_MOESI_ACTION_END;
				N.return_data = cdata;
				esim_schedule_event(CACHE_EV_MOESI_REQUEST_START, ndata, 0);
			}
			
			/* Evict: none */
			else if (C.cmd == CACHE_EVICT) {
				esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
			}
			
			else
				panic("unknown cmd");
			break;
		
		}
		
	} else if (event == CACHE_EV_MOESI_ACTION_INVALIDREAD_START) {
		
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));
		
		/* we return from a completed read request;
		 * if some other cache has the block, set the own block status
		 * to 'shared'; otherwise, we must read the block data from
		 * the next level of the memory hierarchy */
		if (!C.count) {
			
			struct esim_ic_transfer_t *ndata;
			
			cache_blk_set_status(C.cache, C.blk, CACHE_BLK_EXCLUSIVE);
			
			/* calculate 'ic' and node id */
			C.ic = cache_level[C.cache->kind] == 1 ?
				ic_get(C.mt, C.core, C.thread, ic_kind_l1_l2) :
				ic_get(C.mt, C.core, C.thread, ic_kind_l2_mm);
			C.node = cache_level[C.cache->kind] == 1 ?
				C.mt->core[C.core].thread[C.thread].node[0] :
				C.mt->core[C.core].thread[C.thread].node[1];
			
			/* send a request through the interconnect to the next
			 * level of memory (node 0) */
			ndata = repos_create_object(esim_ic_transfer_repos);
			assert(ndata);
			N.repos_id = repos_get_id(esim_ic_transfer_repos);
			N.ic = C.ic;
			N.source = C.node;
			N.dest = 0;
			N.size = MOESI_REQUEST_SIZE;
			N.recv_event = CACHE_EV_MOESI_ACTION_INVALIDREAD_ACCESS;
			N.recv_data = cdata;
			N.return_event = ESIM_EV_NONE;
			N.return_data = NULL;
			esim_schedule_event(IC_EV_TRANSFER_START, ndata, 0);
			
		} else {
		
			cache_blk_set_status(C.cache, C.blk, CACHE_BLK_SHARED);
			esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
		}
	
	} else if (event == CACHE_EV_MOESI_ACTION_INVALIDREAD_ACCESS) {
		
		struct esim_cache_access_t *ndata;
		struct esim_ic_transfer_t *tdata;
		
		/* free transfer event and get moesi action event */
		tdata = data;
		cdata = tdata->recv_data;
		assert(tdata->repos_id == repos_get_id(esim_ic_transfer_repos));
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));
		repos_free_object(esim_ic_transfer_repos, tdata);
		
		/* we request a block that is not located in any cache
		 * of this level; request it in next cache level */
		ndata = repos_create_object(esim_cache_access_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_cache_access_repos);
		N.mt = C.mt;
		N.core = C.core;
		N.thread = C.thread;
		N.kind = cache_next[C.cache->kind];
		N.addr = C.blk->tag;
		N.cmd = CACHE_READ;
		N.return_event = CACHE_EV_MOESI_ACTION_INVALIDREAD_TRANSFER;
		N.return_data = cdata;
		esim_schedule_event(CACHE_EV_ACCESS_START, ndata, 0);
	
	} else if (event == CACHE_EV_MOESI_ACTION_INVALIDREAD_TRANSFER) {
		
		struct esim_ic_transfer_t *ndata;
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));

		/* the block access to the next level of memory finished;
		 * we must transfer the block again through the interconnect */
		ndata = repos_create_object(esim_ic_transfer_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_ic_transfer_repos);
		N.ic = C.ic;
		N.source = 0;
		N.dest = C.node;
		N.size = MOESI_REQUEST_SIZE + cache_opt[C.cache->kind].bsize;
		N.recv_event = CACHE_EV_MOESI_ACTION_INVALIDREAD_END;
		N.recv_data = cdata;
		N.return_event = ESIM_EV_NONE;
		N.return_data = NULL;
		esim_schedule_event(IC_EV_TRANSFER_START, ndata, 0);
	
	} else if (event == CACHE_EV_MOESI_ACTION_INVALIDREAD_END) {
	
		struct esim_ic_transfer_t *tdata;
		
		/* free transfer event and get moesi action event */
		tdata = data;
		cdata = tdata->recv_data;
		assert(tdata->repos_id == repos_get_id(esim_ic_transfer_repos));
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));
		repos_free_object(esim_ic_transfer_repos, tdata);
		
		/* finish moesi action */
		esim_schedule_event(CACHE_EV_MOESI_ACTION_END, cdata, 0);
	
	} else if (event == CACHE_EV_MOESI_ACTION_END) {
		
		/* return to calling function */
		assert(cdata->repos_id == repos_get_id(esim_moesi_action_repos));
		int oevent = C.return_event;
		void *odata = C.return_data;
		repos_free_object(esim_moesi_action_repos, cdata);
		esim_schedule_event(oevent, odata, 0);
	
	} else
		panic("moesi_action: unknown esim event");
}


/* ESIM cache_access */

static void esim_cache_access(int event, void *data)
{
	struct esim_cache_access_t *cdata = data;
	struct esim_moesi_action_t *ndata;
	assert(cdata->repos_id == repos_get_id(esim_cache_access_repos));
	
	if (event == CACHE_EV_ACCESS_START) {
	
		/* access to main memory; return latency and finish */
		assert(C.cmd == CACHE_READ || C.cmd == CACHE_WRITE);
		if (C.kind == mainmemory) {
			C.mt->core[C.core].thread[C.thread].current_mm_accesses++;
			esim_schedule_event(CACHE_EV_ACCESS_END, cdata, mem_lat);
			return;
		}
		
		/* access to some cache */
		C.cache = cache_get(C.mt, C.core, C.thread, C.kind);
		C.opt = &cache_opt[C.kind];
		C.tag = C.addr & ~C.opt->bmask;
		C.set = (C.addr >> C.opt->logbsize) % C.opt->nsets;
		
		/* find block */
		for (C.blk = C.cache->sets[C.set].way_head; C.blk; C.blk = C.blk->way_next)
			if (C.blk->tag == C.tag && C.blk->status != CACHE_BLK_INVALID)
				break;
		
		/* hit or miss */
		esim_execute_event(C.blk ? CACHE_EV_ACCESS_WAIT_READY :
			CACHE_EV_ACCESS_MISS, cdata);
	
	} else if (event == CACHE_EV_ACCESS_WAIT_READY) {
		
		/* we wait until block is ready, scheduling the same event
		 * for the next cycle; if it is ready, we can continue
		 * processing the cache hit */
		if (!C.blk->ready) {
			esim_schedule_event(CACHE_EV_ACCESS_WAIT_READY, cdata, 1);
		} else {
			esim_execute_event(CACHE_EV_ACCESS_HIT, cdata);
		}
	
	} else if (event == CACHE_EV_ACCESS_HIT) {
		
		/* record hit */
		C.cache->hits++;
		
		/* if replacement policy is lru, reorder */
		if (C.blk->way_prev && C.opt->policy == cache_policy_lru)
			update_way_list(&C.cache->sets[C.set], C.blk, Head);
		
		/* we have a hit; update block moesi state;
		 * this is done asynchronously, and thus, we do not need
		 * a new callback event */
		ndata = repos_create_object(esim_moesi_action_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_moesi_action_repos);
		N.mt = C.mt;
		N.core = C.core;
		N.thread = C.thread;
		N.cache = C.cache;
		N.blk = C.blk;
		N.cmd = C.cmd;
		N.return_event = ESIM_EV_NONE;
		N.return_data = NULL;
		esim_schedule_event(CACHE_EV_MOESI_ACTION_START, ndata, 0);
		
		/* go to the end of cache_access function returning when
		 * the cache hit latency expires; if the latency is 1 cycle,
		 * we should return immediately */
		assert(C.opt->lat > 0);
		esim_schedule_event(CACHE_EV_ACCESS_END, cdata,
			C.opt->lat - 1);
	
	} else if (event == CACHE_EV_ACCESS_MISS) {
	
		/* record miss */
		C.cache->misses++;
		
		/* we have a miss; select a block to replace;
		 * look first for any invalid block */
		for (C.repl = C.cache->sets[C.set].way_head; C.repl; C.repl = C.repl->way_next)
			if (C.repl->status == CACHE_BLK_INVALID)
				break;
		
		/* if none found, apply replacement policy */
		if (!C.repl) {
			switch (C.opt->policy) {
			case cache_policy_lru:
			case cache_policy_fifo:
				C.repl = C.cache->sets[C.set].way_tail;
				update_way_list(&C.cache->sets[C.set], C.repl, Head);
				break;
			case cache_policy_random:
				C.repl = &C.cache->sets[C.set].blks[rand() % C.opt->assoc];
				break;
			default:
				panic("cache.c: bogus replacement policy");
			}
		}
		
		/* update the block tag and set the ready bit to 0
		 * until the miss is resolved */
		C.repl->tag = C.tag;
		C.repl->ready = FALSE;
		
		/* set the replaced block moesi status to CACHE_BLK_INVALID, by
		 * sending a CACHE_EVICT processor action; if the block
		 * was already invalid, no need */
		if (C.repl->status == CACHE_BLK_INVALID) {
			esim_schedule_event(CACHE_EV_ACCESS_MISS2, cdata, 0);
		} else {
			ndata = repos_create_object(esim_moesi_action_repos);
			assert(ndata);
			N.repos_id = repos_get_id(esim_moesi_action_repos);
			N.mt = C.mt;
			N.core = C.core;
			N.thread = C.thread;
			N.cache = C.cache;
			N.blk = C.repl;
			N.cmd = CACHE_EVICT;
			N.return_event = CACHE_EV_ACCESS_MISS2;
			N.return_data = cdata;
			esim_schedule_event(CACHE_EV_MOESI_ACTION_START, ndata, 0);
		}
	
	} else if (event == CACHE_EV_ACCESS_MISS2) {
		
		/* update replaced block; set its new moesi state */
		ndata = repos_create_object(esim_moesi_action_repos);
		assert(ndata);
		N.repos_id = repos_get_id(esim_moesi_action_repos);
		N.mt = C.mt;
		N.core = C.core;
		N.thread = C.thread;
		N.cache = C.cache;
		N.blk = C.repl;
		N.cmd = C.cmd;
		N.return_event = CACHE_EV_ACCESS_MISS3;
		N.return_data = cdata;
		esim_schedule_event(CACHE_EV_MOESI_ACTION_START, ndata, 0);
		
	} else if (event == CACHE_EV_ACCESS_MISS3) {
		
		/* the replaced block is ready to be accessed now;
		 * set the ready flag to TRUE */
		C.repl->ready = TRUE;
		esim_schedule_event(CACHE_EV_ACCESS_END, cdata, 0);

	} else if (event == CACHE_EV_ACCESS_END) {
		
		/* end of an access */
		if (C.kind == mainmemory) {
			C.mt->core[C.core].thread[C.thread].current_mm_accesses--;
			assert(C.mt->core[C.core].thread[C.thread].current_mm_accesses >= 0);
		}
		
		/* return to calling function */
		int oevent = C.return_event;
		void *odata = C.return_data;
		repos_free_object(esim_cache_access_repos, cdata);
		esim_schedule_event(oevent, odata, 0);
	
	} else
		panic("cache_access: unknown esim event");
}


/* ESIM cache_wrapper */
static void esim_cache_wrapper(int event, void *data)
{
	struct esim_cache_wrapper_t *cdata = data;
	assert(cdata->repos_id == repos_get_id(esim_cache_wrapper_repos));
	
	if (event == CACHE_EV_WRAPPER_START) {
		
		struct esim_cache_access_t *ndata;
		
		/* if we have not exceeded maximum concurrent accesses allowed,
		 * start cache access; else schedule same event for later */
		if (C.cache->concurrent < max_concurrent) {
			C.cache->concurrent++;
			ndata = repos_create_object(esim_cache_access_repos);
			assert(ndata);
			N.repos_id = repos_get_id(esim_cache_access_repos);
			N.mt = C.mt;
			N.core = C.core;
			N.thread = C.thread;
			N.kind = C.kind;
			N.addr = C.addr;
			N.cmd = C.cmd;
			N.return_event = CACHE_EV_WRAPPER_END;
			N.return_data = cdata;
			esim_schedule_event(CACHE_EV_ACCESS_START, ndata, 0);
		} else {
			esim_schedule_event(CACHE_EV_WRAPPER_START, cdata, 1);
		}
	
	} else if (event == CACHE_EV_WRAPPER_END) {
		
		/* release pending access and free data */
		access_info_end(C.access_id);
		C.cache->concurrent--;
		repos_free_object(esim_cache_wrapper_repos, cdata);
		
	} else
		panic("cache_wrapper: unknown esim event");
}


/* Handler for initialization and stats update events */
static void esim_cache_handler(int event, void *data)
{
	struct cache_t *cache = data;
	
	if (event == CACHE_EV_INITIALIZE) {
		
		esim_schedule_event(CACHE_EV_UPDATE_STATS, cache, 1);
		
	} else if (event == CACHE_EV_UPDATE_STATS) {
	
		int i;
		for (i = 0; i < 5; i++) {
			cache->moesi_acc[i] += cache->moesi_count[i];
			cache->moesi_rate[i] = (double) cache->moesi_acc[i] /
				cache_opt[cache->kind].nsets /
				cache_opt[cache->kind].assoc /
				esim_cycle;
		}
		esim_schedule_event(CACHE_EV_UPDATE_STATS, cache, 1);
	} else
		panic("cache_handler: unkown esim event");
}




/* Public Methods */

void cache_init(struct mt_t *mt)
{
	int i, core, thread;
	
	/* some global stats */
	stat_reg_dword("moesi:block_transfers", "# of blocks transferred through interconnects",
		&moesi_block_transfers, 0, NULL);
	stat_reg_dword("moesi:read_requests", "# of read requests broadcasted",
		&moesi_read_requests, 0, NULL);
	stat_reg_dword("moesi:write_requests", "# of write requests broadcasted",
		&moesi_write_requests, 0, NULL);
	
	/* get global opt values */
	for (i = 0; i < 6; i++)
		extract_opt(i, cache_sopt[i]);
	
	/* integrity */
	if (cache_opt[dl1].unified && !cache_opt[dl2].unified)
		fatal("dl1 cannot be unified with a not unified dl2");
	if (cache_opt[dl2].sharing < cache_opt[dl1].sharing)
		fatal("l2 must be equally or more shared than l1");
	if (cache_opt[dl1].sharing != cache_opt[il1].sharing ||
		cache_opt[dl2].sharing != cache_opt[il2].sharing ||
		cache_opt[dtlb].sharing != cache_opt[itlb].sharing)
		fatal("same level caches and tlbs must have the same sharing");
	if (cache_opt[dl1].lat < 1 || cache_opt[il1].lat < 1 ||
		cache_opt[dl2].lat < 1 || cache_opt[il2].lat < 1 ||
		cache_opt[dtlb].lat < 1 || cache_opt[itlb].lat < 1)
		fatal("hit latency must be greater than 0 for all caches/tlbs");
	if (cache_opt[dtlb].bsize != 4 || cache_opt[itlb].bsize != 4)
		fatal("tlb block size must be 4 (physical address = 32 bits)");
	
	/* ESIM events and event data repositories */
	CACHE_EV_INITIALIZE = esim_register_event(esim_cache_handler);
	CACHE_EV_UPDATE_STATS = esim_register_event(esim_cache_handler);
	
	esim_cache_wrapper_repos = repos_create(sizeof(struct esim_cache_wrapper_t), "esim_cache_wrapper_repos");
	CACHE_EV_WRAPPER_START = esim_register_event(esim_cache_wrapper);
	CACHE_EV_WRAPPER_END = esim_register_event(esim_cache_wrapper);
	
	esim_cache_access_repos = repos_create(sizeof(struct esim_cache_access_t), "esim_cache_access_repos");
	CACHE_EV_ACCESS_WAIT_READY = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_START = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_HIT = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_MISS = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_MISS2 = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_MISS3 = esim_register_event(esim_cache_access);
	CACHE_EV_ACCESS_END = esim_register_event(esim_cache_access);
	
	esim_moesi_action_repos = repos_create(sizeof(struct esim_moesi_action_t), "esim_moesi_action_repos");
	CACHE_EV_MOESI_ACTION_START = esim_register_event(esim_moesi_action);
	CACHE_EV_MOESI_ACTION_INVALIDREAD_START = esim_register_event(esim_moesi_action);
	CACHE_EV_MOESI_ACTION_INVALIDREAD_ACCESS = esim_register_event(esim_moesi_action);
	CACHE_EV_MOESI_ACTION_INVALIDREAD_TRANSFER = esim_register_event(esim_moesi_action);
	CACHE_EV_MOESI_ACTION_INVALIDREAD_END = esim_register_event(esim_moesi_action);
	CACHE_EV_MOESI_ACTION_END = esim_register_event(esim_moesi_action);
	
	esim_moesi_request_repos = repos_create(sizeof(struct esim_moesi_request_t), "esim_moesi_request_repos");
	CACHE_EV_MOESI_REQUEST_START = esim_register_event(esim_moesi_request);
	CACHE_EV_MOESI_REQUEST_RECV = esim_register_event(esim_moesi_request);
	CACHE_EV_MOESI_REQUEST_CONFIRM = esim_register_event(esim_moesi_request);
	CACHE_EV_MOESI_REQUEST_END = esim_register_event(esim_moesi_request);
	
	access_info_repos = repos_create(sizeof(struct access_info_t), "access_info_repos");
	
	
	/* create l2 caches */
	switch (cache_opt[dl2].sharing) {
	
	case cache_shared:
		mt->cache[dl2] = cache_create(dl2, 0, 0);
		mt->cache[il2] = cache_opt[dl2].unified ?
			mt->cache[dl2] : cache_create(il2, 0, 0);
		break;
		
	case cache_percore:
		FOREACH_CORE {
			CORE.cache[dl2] = cache_create(dl2, core, 0);
			CORE.cache[il2] = cache_opt[dl2].unified ?
				CORE.cache[dl2] : cache_create(il2, core, 0);
		}
		break;
		
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			THREAD.cache[dl2] = cache_create(dl2, core, thread);
			THREAD.cache[il2] = cache_opt[dl2].unified ?
				THREAD.cache[il2] : cache_create(il2, core, thread);
		}
		break;
	}
	
	/* create l1 caches */
	switch (cache_opt[dl1].sharing) {
	
	case cache_shared:
		mt->cache[dl1] = cache_create(dl1, 0, 0);
		mt->cache[il1] = cache_opt[dl1].unified ?
			mt->cache[dl1] : cache_create(il1, 0, 0);
		break;
	
	case cache_percore:
		FOREACH_CORE {
			CORE.cache[dl1] = cache_create(dl1, core, 0);
			CORE.cache[il1] = cache_opt[dl1].unified ?
				CORE.cache[dl1] : cache_create(il1, core, 0);
		}
		break;
	
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			THREAD.cache[dl1] = cache_create(dl1, core, thread);
			THREAD.cache[il1] = cache_opt[dl1].unified ?
				THREAD.cache[dl1] : cache_create(il1, core, thread);
		}
		break;
	}
	
	/* create tlbs */
	switch (cache_opt[dtlb].sharing) {
	
	case cache_shared:
		mt->cache[dtlb] = cache_create(dtlb, 0, 0);
		mt->cache[itlb] = cache_opt[dtlb].unified ?
			mt->cache[dtlb] : cache_create(itlb, 0, 0);
		break;
	
	case cache_percore:
		FOREACH_CORE {
			CORE.cache[dtlb] = cache_create(dtlb, core, 0);
			CORE.cache[itlb] = cache_opt[dtlb].unified ?
				CORE.cache[dtlb] : cache_create(itlb, core, 0);
		}
		break;
	
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			THREAD.cache[dtlb] = cache_create(dtlb, core, thread);
			THREAD.cache[itlb] = cache_opt[dtlb].unified ?
				THREAD.cache[dtlb] : cache_create(itlb, core, thread);
		}
		break;
	}
}


void cache_done(struct mt_t *mt)
{
	int core, thread;
	
	/* free tlbs */
	switch (cache_opt[dtlb].sharing) {
	
	case cache_shared:
		if (!cache_opt[dtlb].unified)
			cache_free(mt->cache[itlb]);
		cache_free(mt->cache[dtlb]);
		break;
	
	case cache_percore:
		FOREACH_CORE {
			if (!cache_opt[dtlb].unified)
				cache_free(CORE.cache[itlb]);
			cache_free(CORE.cache[dtlb]);
		}
		break;
		
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			if (!cache_opt[dtlb].unified)
				cache_free(THREAD.cache[itlb]);
			cache_free(THREAD.cache[dtlb]);
		}
		break;
	}
	
	/* free l1 caches */
	switch (cache_opt[dl1].sharing) {
	
	case cache_shared:
		if (!cache_opt[dl1].unified)
			cache_free(mt->cache[il1]);
		cache_free(mt->cache[dl1]);
		break;
	
	case cache_percore:
		FOREACH_CORE {
			if (!cache_opt[dl1].unified)
				cache_free(CORE.cache[il1]);
			cache_free(CORE.cache[dl1]);
		}
		break;
	
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			if (!cache_opt[dl1].unified)
				cache_free(THREAD.cache[il1]);
			cache_free(THREAD.cache[dl1]);
		}
		break;
	}
	
	/* free l2 caches */
	switch (cache_opt[dl2].sharing) {
	
	case cache_shared:
		if (!cache_opt[dl2].unified)
			cache_free(mt->cache[il2]);
		cache_free(mt->cache[dl2]);
		break;
	
	case cache_percore:
		FOREACH_CORE {
			if (!cache_opt[dl2].unified)
				cache_free(CORE.cache[il2]);
			cache_free(CORE.cache[dl2]);
		}
		break;
	
	case cache_perthread:
		FOREACH_CORE FOREACH_THREAD {
			if (!cache_opt[dl2].unified)
				cache_free(THREAD.cache[il2]);
			cache_free(THREAD.cache[dl2]);
		}
		break;
	}
	
	/* free object repositories */
	repos_free(esim_cache_wrapper_repos);
	repos_free(esim_cache_access_repos);
	repos_free(esim_moesi_action_repos);
	repos_free(esim_moesi_request_repos);
	repos_free(access_info_repos);
}


dword cache_access(struct mt_t *mt, int core, int thread,
	enum cache_kind_enum kind, word addr, int cmd)
{
	struct esim_cache_wrapper_t *ndata;
	dword access_id;
	
	/* record access */
	access_id = access_info_start(core, thread, kind,
		addr, cmd);
	
	/* event function call */
	ndata = repos_create_object(esim_cache_wrapper_repos);
	assert(ndata);
	N.repos_id = repos_get_id(esim_cache_wrapper_repos);
	N.mt = mt;
	N.core = core;
	N.thread = thread;
	assert(cache_level[kind] == 1);
	N.kind = kind;
	N.cache = cache_get(mt, core, thread, kind);
	N.addr = addr;
	N.cmd = cmd;
	N.access_id = access_id;
	esim_schedule_event(CACHE_EV_WRAPPER_START, ndata, 0);
		
	return access_id;
}


int cache_completed(dword access_id)
{
	struct access_info_t *access_info;
	for (access_info = access_info_db; access_info; access_info = access_info->next)
		if (access_info->access_id == access_id)
			return FALSE;
	return TRUE;
}


void cache_dump_accesses()
{
	struct access_info_t *access_info;
	printf("cache accesses (esim_cycle=%lld):\n", esim_cycle);
	for (access_info = access_info_db; access_info; access_info = access_info->next) {
		printf("\taccess_id=%lld c%dt%d %s addr=0x%x cmd=%d esim_cycle=%lld\n",
			access_info->access_id, access_info->core, access_info->thread,
			cache_name[access_info->kind], access_info->addr, access_info->cmd,
			access_info->esim_cycle_start);
	}
}

/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <mhandle.h>
#include <fcntl.h>
#include <config.h>
#include <list.h>
#include <time.h>
#include <sys/time.h>

#include "mt.h"
#include "ptrace.h"


/* processor parameters */
word	mt_cores;
word	mt_threads;
word	mt_quantum;
word	mt_switch_penalty;

enum	mt_fetch_kind_enum mt_fetch_kind;
enum	mt_fetch_priority_enum mt_fetch_priority;
word	mt_fetch_width;

enum	mt_decode_kind_enum mt_decode_kind;
word	mt_decode_width;

enum	mt_issue_kind_enum mt_issue_kind;
word	mt_issue_width;

enum	mt_commit_kind_enum mt_commit_kind;
word	mt_commit_width;

word	ifq_size;
word	ruu_size;
word	lsq_size;




/* Register Update Unit Element */

static struct ruu_elem_t *ruu_elem_free_list = NULL;

struct ruu_elem_t *ruu_elem_create()
{
	struct ruu_elem_t *ruu_elem;
	if (!ruu_elem_free_list)
		ruu_elem_free_list = calloc(1, sizeof(struct ruu_elem_t));
	ruu_elem = ruu_elem_free_list;
	ruu_elem_free_list = ruu_elem_free_list->next;
	bzero(ruu_elem, sizeof(struct ruu_elem_t));
	return ruu_elem;
}

void ruu_elem_free(struct ruu_elem_t *ruu_elem)
{
	ptrace_endinst(ruu_elem->seq);
	ruu_link_list_free(ruu_elem->olist);
	ruu_elem->seq = 0;
	ruu_elem->next = ruu_elem_free_list;
	ruu_elem_free_list = ruu_elem;
}

void ruu_elem_free_all()
{
	struct ruu_elem_t *next;
	while (ruu_elem_free_list) {
		next = ruu_elem_free_list->next;
		free(ruu_elem_free_list);
		ruu_elem_free_list = next;
	}
}

void ruu_elem_dump(struct ruu_elem_t *ruu_elem, FILE *f)
{
	int i;
	
	fprintf(f, "seq=%llu, in={", ruu_elem->seq);
	for (i = 0; i < 3; i++) {
		if (ruu_elem->ph_in[i] < 0) fprintf(f, "-");
		else fprintf(f, "%d", ruu_elem->ph_in[i]);
		if (i < 2) fprintf(f, ",");
	}
	fprintf(f, "}, out={");
	for (i = 0; i < 2; i++) {
		if (ruu_elem->ph_out[i] < 0) fprintf(f, "-");
		else fprintf(f, "%d", ruu_elem->ph_out[i]);
		if (i < 1) fprintf(f, ",");
	}
	fprintf(f, "} pc=0x%x ", ruu_elem->regs_PC);
	if (ruu_elem->inlsq && (ruu_elem->instfld.flags & F_LOAD)) {
		fprintf(f, "dl1=%s dtlb=%s ",
			cache_completed(ruu_elem->dl1_access_id) ? "-compl-" : "-pending-",
			cache_completed(ruu_elem->dtlb_access_id) ? "-compl-" : "-pending-");
	}
	md_print_inst(f, ruu_elem->instfld.inst, ruu_elem->regs_PC);
}

void ruu_list_dump(struct list_t *ruu_list, FILE *f)
{
	struct ruu_elem_t *ruu_elem;
	int i;
	for (i = 0; i < list_count(ruu_list); i++) {
		ruu_elem = list_get(ruu_list, i);
		fprintf(f, "%3d. ", i);
		ruu_elem_dump(ruu_elem, f);
		fprintf(f, "\n");
	}
}

void ruu_list_squash_thread(struct list_t *ruu_list, int core, int thread)
{
	int i;
	struct ruu_elem_t *ruu_elem;
	for (i = 0; i < list_count(ruu_list); i++) {
		ruu_elem = list_get(ruu_list, i);
		if (ruu_elem->core == core && ruu_elem->thread == thread) {
			ptrace_endinst(ruu_elem->seq);
			list_remove_at(ruu_list, i);
			ruu_elem_free(ruu_elem);
			i--;
		}
	}
}

void ruu_list_squash(struct list_t *ruu)
{
	struct ruu_elem_t *ruu_elem;
	while (list_count(ruu)) {
		ruu_elem = list_dequeue(ruu);
		ptrace_endinst(ruu_elem->seq);
		ruu_elem_free(ruu_elem);
	}
}




/* Register Update Unit Element Link */

static struct ruu_link_t *ruu_link_pool = NULL;

struct ruu_link_t *ruu_link_create(struct ruu_elem_t *ruu_elem)
{
	struct ruu_link_t *ruu_link;
	
	/* obtain a ruu_link */
	if (!ruu_link_pool)
		ruu_link_pool = calloc(1, sizeof(struct ruu_link_t));
	ruu_link = ruu_link_pool;
	ruu_link_pool = ruu_link_pool->next;
	
	/* initialize */
	assert(!ruu_link->alloc);
	bzero(ruu_link, sizeof(struct ruu_link_t));
	ruu_link->ruu_elem = ruu_elem;
	ruu_link->seq = ruu_elem->seq;
	ruu_link->alloc = TRUE;
	return ruu_link;
}

void ruu_link_free(struct ruu_link_t *ruu_link)
{
	assert(ruu_link->alloc);
	ruu_link->alloc = FALSE;
	ruu_link->next = ruu_link_pool;
	ruu_link_pool = ruu_link;
}

void ruu_link_free_all()
{
	struct ruu_link_t *next;
	while (ruu_link_pool) {
		next = ruu_link_pool->next;
		free(ruu_link_pool);
		ruu_link_pool = next;
	}
}

void ruu_link_list_free(struct ruu_link_t *ruu_link)
{
	struct ruu_link_t *next;
	
	while (ruu_link) {
		next = ruu_link->next;
		ruu_link_free(ruu_link);
		ruu_link = next;
	}
}

void ruu_link_list_dump(struct ruu_link_t *ruu_link, FILE *f)
{
	int index = 0;
	while (ruu_link) {
		if (ruu_link_valid(ruu_link)) {
			fprintf(f, "%3d. ", index);
			ruu_elem_dump(ruu_link->ruu_elem, f);
			fprintf(f, "\n");
		}
		ruu_link = ruu_link->next;
	}
}




/* Functional Units */

#define FU_RES_MAX	10
#define FU_NUM_CLASSES	12

struct fu_res_t {
	int	count;
	int	oplat;
	int	issuelat;
	char	*name;
};

static struct fu_res_t fu_res_pool[FU_NUM_CLASSES] = {
	{0, 0, 0, ""},
	{4, 1, 1, "IntALU"},
	{1, 3, 1, "IntMULT"},
	{1, 20, 19, "IntDIV"},
	{4, 4, 1, "FloatADD"},
	{2, 4, 1, "FloatCMP"},
	{2, 4, 1, "FloatCVT"},
	{1, 8, 1, "FloatMULT"},
	{1, 40, 20, "FloatDIV"},
	{1, 80, 40, "FloatSQRT"},
	{2, 1, 1, "RdPort"},
	{2, 1, 1, "WrPort"}
};

struct fu_t {
	int busy[NUM_FU_CLASSES][FU_RES_MAX];
	dword occupied, int_occupied, fp_occupied;
	dword idle, int_idle, fp_idle;
	double util, int_util, fp_util;
};

struct fu_t *fu_create()
{
	struct fu_t *fu = calloc(1, sizeof(struct fu_t));
	return fu;
}

void fu_free(struct fu_t *fu)
{
	free(fu);
}

/* reserve an fu; return fu latency or
 * 0 if it could not be reserved */
int fu_reserve(struct fu_t *fu, int class)
{
	int i, lat;
	for (i = 0; i < fu_res_pool[class].count; i++) {
		if (!fu->busy[class][i]) {
			lat = fu_res_pool[class].issuelat;
			assert(lat > 0);
			fu->busy[class][i] = lat;
			return lat;
		}
	}
	return 0;
}

void fu_release(struct fu_t *fu)
{
	int i, j;
	for (i = 1; i < NUM_FU_CLASSES; i++) {
		for (j = 0; j < fu_res_pool[i].count; j++) {
			if (fu->busy[i][j]) {
				fu->busy[i][j]--;
				if (i >= 1 && i <= 9)
					fu->occupied++;
				if (i >= 1 && i <= 3)
					fu->int_occupied++;
				if (i >= 4 && i <= 9)
					fu->fp_occupied++;
			} else {
				if (i >= 1 && i <= 9)
					fu->idle++;
				if (i >= 1 && i <= 3)
					fu->int_idle++;
				if (i >= 4 && i <= 9)
					fu->fp_idle++;
			}
		}
	}
}

void fu_release_all(struct fu_t *fu)
{
	int i, j;
	for (i = 1; i < NUM_FU_CLASSES; i++)
		for (j = 0; j < fu_res_pool[i].count; j++)
			fu->busy[i][j] = 0;
}




/* Fetch-Decode Queue */

void ifq_reg_options()
{
}

void ifq_init(struct mt_t *mt)
{
	int core, thread;
	if (mt_decode_kind == mt_decode_kind_shared) {
		FOREACH_CORE
			CORE.ifq = list_create(ifq_size);
	} else {
		FOREACH_CORE
			FOREACH_THREAD
				THREAD.ifq = list_create(ifq_size);
	}
}

void ifq_done(struct mt_t *mt)
{
	int core, thread;
	if (mt_decode_kind == mt_decode_kind_shared) {
		FOREACH_CORE {
			ruu_list_squash(CORE.ifq);
			list_free(CORE.ifq);
		}
	} else {
		FOREACH_CORE {
			FOREACH_THREAD {
				ruu_list_squash(THREAD.ifq);
				list_free(THREAD.ifq);
			}
		}
	}
}

struct list_t *ifq_get(struct mt_t *mt, int core, int thread)
{
	return mt_decode_kind == mt_decode_kind_shared ?
		CORE.ifq : THREAD.ifq;
}




/* Ready Queue */

struct readyq_t {
	int count;
	struct ruu_link_t *head;
};

void readyq_init(struct mt_t *mt)
{
	int core, thread;
	if (mt_issue_kind == mt_issue_kind_shared) {
		FOREACH_CORE
			CORE.readyq = readyq_create();
	} else {
		FOREACH_CORE
			FOREACH_THREAD
				THREAD.readyq = readyq_create();
	}
}

void readyq_done(struct mt_t *mt)
{
	int core, thread;
	if (mt_issue_kind == mt_issue_kind_shared) {
		FOREACH_CORE
			readyq_free(CORE.readyq);
	} else {
		FOREACH_CORE
			FOREACH_THREAD
				readyq_free(THREAD.readyq);
	}
}

struct readyq_t *readyq_get(struct mt_t *mt, int core, int thread)
{
	return mt_issue_kind == mt_issue_kind_shared ?
		CORE.readyq : THREAD.readyq;
}

struct readyq_t *readyq_create()
{
	return calloc(1, sizeof(struct readyq_t));
}

void readyq_free(struct readyq_t *readyq)
{
	ruu_link_list_free(readyq->head);
	free(readyq);
}

void readyq_enqueue(struct readyq_t *readyq, struct ruu_elem_t *ruu_elem)
{
	struct ruu_link_t *prev, *node, *new;
	
	assert(!ruu_elem->queued);
	ruu_elem->queued = TRUE;
	readyq->count++;
	
	/* locate insertion point */
	new = ruu_link_create(ruu_elem);
	if (ruu_elem->inlsq || ruu_elem->instfld.flags & (F_LONGLAT|F_CTRL)) {
		prev = NULL;
		node = readyq->head;
	} else {
		for (prev = NULL, node = readyq->head;
			node && node->seq < ruu_elem->seq;
			prev = node, node = node->next);
	}

	/* insert element */
	if (prev) {
		new->next = prev->next;
		prev->next = new;
	} else {
		new->next = readyq->head;
		readyq->head = new;
	}
}

struct ruu_link_t *readyq_clear(struct readyq_t *readyq)
{
	struct ruu_link_t *head = readyq->head;
	readyq->head = NULL;
	readyq->count = 0;
	return head;
}

int readyq_count(struct readyq_t *readyq)
{
	return readyq->count;
}




/* Event Queue */

struct eventq_t {
	struct ruu_link_t *head;
};

struct eventq_t *eventq_create()
{
	return calloc(1, sizeof(struct eventq_t));
}

void eventq_free(struct eventq_t *eventq)
{
	ruu_link_list_free(eventq->head);
	free(eventq);
}

struct ruu_elem_t *eventq_next(struct eventq_t *eventq, sdword now)
{
	struct ruu_link_t *next;
	struct ruu_elem_t *ruu_elem;
	
	/* remove not valid ruu_link's from the head of the list */
	while (eventq->head && !ruu_link_valid(eventq->head)) {
		next = eventq->head->next;
		ruu_link_free(eventq->head);
		eventq->head = next;
	}
	
	/* no event in list */
	if (!eventq->head)
		return NULL;
	
	/* event in list head has not still occurred */
	assert(eventq->head->when >= now);
	if (eventq->head->when > now)
		return NULL;
	
	/* return event in list head */
	ruu_elem = eventq->head->ruu_elem;
	next = eventq->head->next;
	ruu_link_free(eventq->head);
	eventq->head = next;
	return ruu_elem;
}

void eventq_enqueue(struct eventq_t *eventq, sdword when, struct ruu_elem_t *ruu_elem)
{
	struct ruu_link_t *prev, *node, *new;
	
	/* create new ruu_link */
	new = ruu_link_create(ruu_elem);
	new->when = when;
	
	/* locate place to insert new node */
	prev = NULL;
	node = eventq->head;
	while (node && node->when <= when) {
		prev = node;
		node = node->next;
	}
	
	/* insert */
	if (prev) {
		prev->next = new;
		new->next = node;
	} else {
		new->next = eventq->head;
		eventq->head = new;
	}
}




/* Physical Register File */

static word phregs_size;
static enum phregs_kind_enum {
	phregs_kind_shared = 0,
	phregs_kind_private
} phregs_kind;

enum phregs_status_enum {
	phregs_status_free = 0,
	phregs_status_busy,
	phregs_status_ready
};

struct phreg_t {
	enum phregs_status_enum status;
	struct ruu_elem_t *creator;
};

struct phregs_t {
	int size, avail;
	int map[MAX_THREADS][DCOUNT];
	struct phreg_t *phreg;
};

static void phregs_reg_stats(struct mt_t *mt)
{
	/*stat_reg_int("phregs.int_regs_used", "logical integer registers used",
		&phregs->int_regs_used, 0, NULL);
	stat_reg_int("phregs.fp_regs_used", "logical fp registers used",
		&phregs->fp_regs_used, 0, NULL);
	stat_reg_formula("phregs.total_regs_used", "total logical registers used",
		"phregs.int_regs_used + phregs.fp_regs_used", "%.0f");*/
}

void phregs_reg_options()
{
	static char *phregs_kind_map[] = { "shared", "private" };
	opt_reg_enum("-phregs_kind", "physical register file {shared|private}",
		(int *) &phregs_kind, phregs_kind_map, 2, "private");
	opt_reg_word("-phregs_size", "physical register file size (if private, per thread)",
		&phregs_size, 128);
}

static void phregs_init_thread(struct phregs_t *phregs, int thread)
{
	int dep, idx = 0;
	for (dep = 0; dep < DCOUNT; dep++) {
		if (!phregs->avail)
			fatal("phregs size too small; at least %d per thread", DCOUNT);
		while (phregs->phreg[idx].status != phregs_status_free)
			idx++;
		phregs->map[thread][dep] = idx;
		phregs->phreg[idx].status = phregs_status_ready;
		phregs->phreg[idx].creator = NULL;
		phregs->avail--;
	}
}

void phregs_init(struct mt_t *mt)
{
	int core, thread;
	
	if (phregs_size < DCOUNT + 32)
		fatal("phregs_size must be at least %d", DCOUNT + 32);
	if (phregs_kind == phregs_kind_shared) {
		FOREACH_CORE {
			CORE.phregs = phregs_create(phregs_size * mt_threads);
			FOREACH_THREAD
				phregs_init_thread(CORE.phregs, thread);
		}
	} else {
		FOREACH_CORE {
			FOREACH_THREAD {
				THREAD.phregs = phregs_create(phregs_size);
				phregs_init_thread(THREAD.phregs, thread);
			}
		}
	}
	phregs_reg_stats(mt);
}

void phregs_done(struct mt_t *mt)
{
	int core, thread;
	if (phregs_kind == phregs_kind_shared) {
		FOREACH_CORE
			phregs_free(CORE.phregs);
	} else {
		FOREACH_CORE
			FOREACH_THREAD
				phregs_free(THREAD.phregs);
	}
}

static void phregs_do_check(struct phregs_t *phregs)
{
	int i, used = 0;
	for (i = 0; i < phregs->size; i++)
		if (phregs->phreg[i].status != phregs_status_free)
			used++;
	assert(used == phregs->size - phregs->avail);
}

void phregs_check(struct mt_t *mt, int core)
{
	struct phregs_t *phregs;
	struct ruu_elem_t *ruu_elem;
	int thread, i, used = 0, fixed;
	
	FOREACH_THREAD {
	
		/* count used phregs in ruu + lsq */
		phregs = phregs_get(mt, core, thread);
		for (i = 0; i < list_count(THREAD.ruu); i++) {
			ruu_elem = list_get(THREAD.ruu, i);
			if (ruu_elem->ph_out[0] >= 0)
				used++;
			if (ruu_elem->ph_out[1] >= 0)
				used++;
		}
		for (i = 0; i < list_count(THREAD.lsq); i++) {
			ruu_elem = list_get(THREAD.lsq, i);
			if (ruu_elem->ph_out[0] >= 0)
				used++;
			if (ruu_elem->ph_out[1] >= 0)
				used++;
		}
		
		/* check ruu dep consistency */
		if (phregs_kind == phregs_kind_private) {
			fixed = DCOUNT;
			assert(used + fixed == phregs->size - phregs->avail);
			used = 0;
		}
	}
	
	/* check ruu dep consistency */
	if (phregs_kind == phregs_kind_shared) {
		fixed = mt_threads * DCOUNT;
		assert(used + fixed == CORE.phregs->size - CORE.phregs->avail);
		used = 0;
	}
	
	/* other tests */
	if (phregs_kind == phregs_kind_shared)
		phregs_do_check(CORE.phregs);
	else {
		FOREACH_THREAD
			phregs_do_check(THREAD.phregs);
	}
}

struct phregs_t *phregs_get(struct mt_t *mt, int core, int thread)
{
	return phregs_kind == phregs_kind_shared ?
		CORE.phregs : THREAD.phregs;
}

struct phregs_t *phregs_create(int size)
{
	struct phregs_t *phregs;
	phregs = calloc(1, sizeof(struct phregs_t));
	phregs->size = size;
	phregs->avail = size;
	phregs->phreg = calloc(size, sizeof(struct phreg_t));
	return phregs;
}

void phregs_free(struct phregs_t *phregs)
{
	free(phregs->phreg);
	free(phregs);
}

int phregs_avail(struct phregs_t *phregs)
{
	return phregs->avail;
}

void phregs_rename(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem)
{
	int i, loreg, phreg;
	struct ruu_elem_t *creator;
	struct ruu_link_t *ruu_link;
	
	/* rename input registers */
	for (i = 0; i < 3; i++) {
		loreg = ruu_elem->instfld.in[i];
		if (!DVALID(loreg)) {
			ruu_elem->ph_in[i] = -1;
			continue;
		}
		
		/* rename input register */
		phreg = phregs->map[ruu_elem->thread][loreg - DFIRST];
		ruu_elem->ph_in[i] = phreg;
		
		/* link ruu_elem to creator's odep list if phreg not ready;
		 * warning: it could be linked twice if 2 input operads are the same */
		if (phregs->phreg[phreg].status == phregs_status_busy) {
			creator = phregs->phreg[phreg].creator;
			assert(creator);
			ruu_link = ruu_link_create(ruu_elem);
			ruu_link->next = creator->olist;
			creator->olist = ruu_link;
		}
	}
	
	/* rename output registers */
	for (i = 0; i < 2; i++) {
		loreg = ruu_elem->instfld.out[i];
		if (!DVALID(loreg)) {
			ruu_elem->ph_oout[i] = -1;
			ruu_elem->ph_out[i] = -1;
			continue;
		}
	
		/* find free register */
		for (phreg = 0; phreg < phregs->size; phreg++)
			if (phregs->phreg[phreg].status == phregs_status_free)
				break;
		assert(phreg < phregs->size);
		assert(phregs->avail > 0);
		assert(phregs->phreg[phreg].status == phregs_status_free);
		assert(phregs->phreg[phreg].creator == NULL);
		
		/* allocate output registers */
		ruu_elem->ph_oout[i] = phregs->map[ruu_elem->thread][loreg - DFIRST];
		ruu_elem->ph_out[i] = phreg;
		phregs->phreg[phreg].status = phregs_status_busy;
		phregs->phreg[phreg].creator = ruu_elem;
		phregs->map[ruu_elem->thread][loreg - DFIRST] = phreg;
		phregs->avail--;
	}
}

void phregs_release(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem)
{
	int i, loreg;
	
	for (i = 0; i < 2; i++) {
		loreg = ruu_elem->instfld.out[i];
		if (!DVALID(loreg)) {
			assert(ruu_elem->ph_oout[i] == -1);
			assert(ruu_elem->ph_out[i] == -1);
			continue;
		}
		
		assert(phregs->avail < phregs->size);
		assert(phregs->phreg[ruu_elem->ph_oout[i]].status == phregs_status_ready);
		assert(phregs->phreg[ruu_elem->ph_out[i]].status == phregs_status_ready);
		
		/* release */
		phregs->phreg[ruu_elem->ph_oout[i]].status = phregs_status_free;
		phregs->phreg[ruu_elem->ph_oout[i]].creator = NULL;
		phregs->avail++;
	}
}

void phregs_recover(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem)
{
	int i, loreg;
	
	for (i = 1; i >= 0; i--) {
		loreg = ruu_elem->instfld.out[i];
		if (!DVALID(loreg)) {
			assert(ruu_elem->ph_oout[i] == -1);
			assert(ruu_elem->ph_out[i] == -1);
			continue;
		}
		
		assert(phregs->avail < phregs->size);
		assert(phregs->map[ruu_elem->thread][loreg - DFIRST] == ruu_elem->ph_out[i]);
		
		phregs->map[ruu_elem->thread][loreg - DFIRST] = ruu_elem->ph_oout[i];
		phregs->phreg[ruu_elem->ph_out[i]].status = phregs_status_free;
		phregs->phreg[ruu_elem->ph_out[i]].creator = NULL;
		phregs->avail++;
	}
}

void phregs_resolve(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem)
{
	int i, phreg;
	
	for (i = 0; i < 2; i++) {
		phreg = ruu_elem->ph_out[i];
		if (phreg == -1)
			continue;
		assert(phreg >= 0 && phreg < phregs->size);
		assert(phregs->phreg[phreg].status == phregs_status_busy);
		phregs->phreg[phreg].status = phregs_status_ready;
	}
}

/* return true if input dependence 'idep' is resolved */
int phregs_idep_ready(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem, int idep)
{
	int phreg;
	
	/* if there was no dependence, ready */
	assert(idep >= 0 && idep <= 2);
	phreg = ruu_elem->ph_in[idep];
	if (phreg < 0)
		return TRUE;
	
	/* dependence found; phreg ready? */
	assert(phregs->phreg[phreg].status != phregs_status_free);
	return phregs->phreg[phreg].status == phregs_status_ready;
}

/* return true if all input operands are ready */
int phregs_ready(struct phregs_t *phregs, struct ruu_elem_t *ruu_elem)
{
	int i;
	for (i = 0; i < 3; i++)
		if (!phregs_idep_ready(phregs, ruu_elem, i))
			return FALSE;
	return TRUE;
}




/* Kernel Contexts with Core-Thread Mapping */

struct ctxmap_t
{
	int count;
	struct {
		int core, thread;
	} ctx[KE_MAXCTX];
};

void ctxmap_init(struct mt_t *mt)
{
	int ctx, core, thread;
	
	mt->map = calloc(1, sizeof(struct ctxmap_t));
	for (ctx = 0; ctx < KE_MAXCTX; ctx++)
		mt->map->ctx[ctx].core =
		mt->map->ctx[ctx].thread = -1;
	FOREACH_CORE
		FOREACH_THREAD
			THREAD.ctx = -1;
}

void ctxmap_done(struct mt_t *mt)
{
	free(mt->map);
}

int ctxmap_count(struct mt_t *mt)
{
	return mt->map->count;
}

/* return the corresponding kernel context of a pair core-thread;
 * if no kernel context is associated, return -1 */
int ctxmap_thread(struct mt_t *mt, int core, int thread)
{
	if (core < 0 || core >= mt_cores ||
		thread < 0 || thread >= mt_threads)
		return -1;
	return THREAD.ctx;
}

/* return the pair core-thread where a kernel context is allocated;
 * if it was not allocated, try to allocate it */
void ctxmap_ctx(struct mt_t *mt, int ctx, int *core, int *thread)
{
	int i, j, mapcore = -1, mapthread = -1, ok = 0;
	ke_assert_ctx(mt->ke, ctx);
	
	/* not yet allocated? */
	if (mt->map->ctx[ctx].core < 0) {
		for (i = j = 0; i < mt_cores && !ok; i++) {
			for (j = 0; j < mt_threads && !ok; j++) {
				if (mt->core[i].thread[j].ctx < 0) {
					ok = 1;
					mapcore = i;
					mapthread = j;
				}
			}
		}
		if (!ok)
			fatal("too much software contexts (increase mt_cores or mt_threads)");
		mt->core[mapcore].thread[mapthread].ctx = ctx;
		mt->map->ctx[ctx].core = mapcore;
		mt->map->ctx[ctx].thread = mapthread;
		mt->map->count++;
		debug("ctx %d allocated in core %d - thread %d", ctx, mapcore, mapthread);
	}
	
	/* return core-thread */
	*core = mt->map->ctx[ctx].core;
	*thread = mt->map->ctx[ctx].thread;
}

void ctxmap_unmap(struct mt_t *mt, int core, int thread)
{
	assert(THREAD.ctx >= 0);
	mt->map->ctx[THREAD.ctx].core = -1;
	mt->map->ctx[THREAD.ctx].thread = -1;
	THREAD.ctx = -1;
	mt->map->count--;
}

/* make shure that all kernel contexts are allocated in some thread */
void ctxmap_update(struct mt_t *mt)
{
	int ctx, core, thread;
	
	FOREACH_CTX(mt->ke) {
		struct regs_t *regs = ke_regs(mt->ke, ctx);
		if (mt->map->ctx[ctx].core < 0 || mt->map->ctx[ctx].thread < 0) {
			ctxmap_ctx(mt, ctx, &core, &thread);
			THREAD.fetch_NPC = regs->regs_NPC;
			THREAD.fetch_NNPC = regs->regs_NNPC;
		}
	}
}




/* Multi-Core Multi-Thread Processor Pipeline */
 
/* options & stats */
void mt_reg_options()
{
	static char *mt_fetch_kind_map[] = { "timeslice", "switchonevent", "multiple" };
	static char *mt_fetch_priority_map[] = { "equal", "icount" };
	static char *mt_issue_kind_map[] = { "shared", "timeslice", "replicated" };
	static char *mt_decode_kind_map[] = { "shared", "timeslice", "replicated" };
	static char *mt_commit_kind_map[] = { "timeslice", "replicated" };
	
	opt_reg_word("-mt_cores", "number of processor cores",
		&mt_cores, 1);
	opt_reg_word("-mt_threads", "number of threads per core",
		&mt_threads, 1);
	opt_reg_word("-mt_quantum", "time quantum in cycles for switch-on-event fetch",
		&mt_quantum, 1000);
	opt_reg_word("-mt_switch_penalty", "thread switch penalty in cycles "
		"for switch-on-event fetch", &mt_switch_penalty, 15);
	opt_reg_enum("-mt_fetch_kind", "fetch policy {timeslice|switchonevent|multiple}",
		(int *) &mt_fetch_kind, mt_fetch_kind_map, 3, "timeslice");
	opt_reg_enum("-mt_fetch_priority", "apply thread fetch priorities {equal|icount}",
		(int *) &mt_fetch_priority, mt_fetch_priority_map, 2, "equal");
	opt_reg_word("-mt_fetch_width", "fetch width (in instr/cycle)",
		&mt_fetch_width, 4);
	opt_reg_enum("-mt_decode_kind", "decode stage sharing {shared|timeslice|replicated}",
		(int *) &mt_decode_kind, mt_decode_kind_map, 3, "shared");
	opt_reg_word("-mt_decode_width", "decode width (for shared/timeslice decode)",
		&mt_decode_width, 4);
	opt_reg_enum("-mt_issue_kind", "issue stage sharing {shared|timeslice|replicated}",
		(int *) &mt_issue_kind, mt_issue_kind_map, 3, "shared");
	opt_reg_word("-mt_issue_width", "issue width (for shared/timeslice issue)",
		&mt_issue_width, 4);
	opt_reg_enum("-mt_commit_kind", "commit stage sharing {timeslice|replicated}",
		(int *) &mt_commit_kind, mt_commit_kind_map, 2, "timeslice");
	opt_reg_word("-mt_commit_width", "commit depth (in instr/thread/cycle)",
		&mt_commit_width, 4);
	opt_reg_word("-ifq_size", "fetch-dispatch queue size (in instr)",
		&ifq_size, 8);
	opt_reg_word("-ruu_size", "register update unit size (in instr/thread)",
		&ruu_size, 80);
	opt_reg_word("-lsq_size", "load-store queue size (in instr/thread)",
		&lsq_size, 40);
}

static void mt_thread_reg_stats(struct mt_t *mt, int core, int thread)
{
	char id[100], name[100], formula[100];
	
	/* thread string identifier */
	sprintf(id, "c%dt%d", core, thread);
	
	sprintf(name, "%s.fetched", id);
	stat_reg_dword(name, "num inst fetched", &THREAD.fetched, 0, NULL);
	
	sprintf(name, "%s.decoded", id);
	stat_reg_dword(name, "num inst decoded", &THREAD.decoded, 0, NULL);
	
	sprintf(name, "%s.issued", id);
	stat_reg_dword(name, "num inst issued", &THREAD.issued, 0, NULL);
	
	sprintf(name, "%s.committed", id);
	stat_reg_dword(name, "num inst committed", &THREAD.committed, 0, NULL);
	
	sprintf(name, "%s.ipc", id);
	sprintf(formula, "%s.committed / sim.cycles", id);
	stat_reg_formula(name, "thread ipc", formula, "%.4f");
}

static void mt_reg_stats(struct mt_t *mt)
{
	
	/* stages and ipc */
	stat_reg_dword("sim.cycles", "num cycles simulated",
		&mt->cycles, 0, NULL);
	stat_reg_dword("sim.fetched", "total inst fetched",
		&mt->fetched, 0, NULL);
	stat_reg_dword("sim.decoded", "total inst decoded",
		&mt->decoded, 0, NULL);
	stat_reg_dword("sim.issued", "total inst issued",
		&mt->issued, 0, NULL);
	stat_reg_dword("sim.committed", "total inst committed",
		&mt->committed, 0, NULL);
	stat_reg_formula("sim.ipc", "global ipc",
		"sim.committed / sim.cycles", "%.4f");
	
	/* branches */
	stat_reg_dword("sim.branches", "num branches committed",
		&mt->branches, 0, NULL);
	stat_reg_dword("sim.misspred", "num branches misspredicted",
		&mt->misspred, 0, NULL);
	stat_reg_formula("sim.predacc", "branch prediction accuracy",
		"(sim.branches - sim.misspred) / sim.branches", "%.4f");
	
	/* simulation time */
	stat_reg_double("sim.time", "simulation time in seconds",
		&mt->time, 0, "%.1f");
	stat_reg_formula("sim.cps", "cycles simulated per second",
		"sim.cycles / sim.time", "%.2e");
	stat_reg_formula("sim.ips", "inst simulated per second",
		"sim.committed / sim.time", "%.2e");
		
/*	stat_reg_dword("sim.issued", "num issued instr",
		&mt->issued, 0, NULL);
	stat_reg_dword("sim.fastfwd_inst", "num fast forwarded instructions",
		&mt->fastfwd_inst, 0, NULL);
	stat_reg_dword("sim.fastfwd_cycles", "num fast forwarded cycles",
		&mt->fastfwd_cycles, 0, NULL);
	stat_reg_double("sim.util", "functional units utilization",
		&mt->util, 0, "%.4f");
	stat_reg_double("sim.int_util", "integer f.u. utilization",
		&mt->int_util, 0, "%.4f");
	stat_reg_double("sim.fp_util", "floating point f.u. utilization",
		&mt->fp_util, 0, "%.4f");*/
}


/* creation */
struct mt_t *mt_create()
{
	struct mt_t *mt;
	int core, thread;
	
	/* create mt structure */
	mt = calloc(1, sizeof(struct mt_t));
	
	ctxmap_init(mt);
	phregs_init(mt);
	ifq_init(mt);
	readyq_init(mt);
	cache_init(mt);
	ic_init(mt);
	
	mt->ke = ke_create();
	mt->mm = mm_create();
	FOREACH_CORE {
		CORE.eventq = eventq_create();
		CORE.fu = fu_create();
		FOREACH_THREAD {
			THREAD.bpred = bpred_create();
			THREAD.ruu = list_create(ruu_size);
			THREAD.lsq = list_create(lsq_size);
			mt_thread_reg_stats(mt, core, thread);
		}
	}
	
	mt_reg_stats(mt);
	return mt;
}


/* destruction */
void mt_free(struct mt_t *mt)
{
	int core, thread;
	
	FOREACH_CORE {
		eventq_free(CORE.eventq);
		fu_free(CORE.fu);
		FOREACH_THREAD {
			bpred_free(THREAD.bpred);
			ruu_list_squash(THREAD.ruu);
			ruu_list_squash(THREAD.lsq);
			list_free(THREAD.ruu);
			list_free(THREAD.lsq);
		}
	}
	
	ctxmap_done(mt);
	phregs_done(mt);
	ifq_done(mt);
	readyq_done(mt);
	cache_done(mt);
	ic_done(mt);
	
	mm_free(mt->mm);
	ke_free(mt->ke);
	ruu_elem_free_all();
	ruu_link_free_all();
	free(mt);
}


/* load programs to different contexts from a configuration text file or
 * from arguments */
void mt_load_progs(struct mt_t *mt, int argc, char **argv, char *ctxfile)
{
	int ctx;
	
	/* create context from command line */
	if (argc > 1) {
		ctx = ke_new_ctx(mt->ke);
		ld_add_args(mt->ke, ctx, argc - 1, argv + 1);
		ld_load_prog(mt->ke, ctx, argv[1]);
	}
	
	/* if no context config file, already done */
	if (*ctxfile)
		ld_load_progs(mt->ke, ctxfile);
	ctxmap_update(mt);
	if (!ke_alive_count(mt->ke))
		fatal("no executable loaded");
}

void mt_start(struct mt_t *mt)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	mt->time = t.tv_sec + t.tv_usec / 1e6;
}

void mt_finish(struct mt_t *mt)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	mt->time = t.tv_sec + t.tv_usec / 1e6 - mt->time;
	mt->cycles = ke_cycle(mt->ke);
/*	mt->util = (double) mt->occupied /
		(double) (mt->occupied + mt->idle);
	mt->int_util = (double) mt->int_occupied /
		(double) (mt->int_occupied + mt->int_idle);
	mt->fp_util = (double) mt->fp_occupied /
		(double) (mt->fp_occupied + mt->fp_idle);*/
}

void mt_dump(struct mt_t *mt, FILE *f)
{
	int core, thread;
	printf("Cycle %lld\n", ke_cycle(mt->ke));
	FOREACH_CORE {
		fprintf(f, "Core %d:\n", core);
		
		if (mt_decode_kind == mt_decode_kind_shared) {
			fprintf(f, "ifq:\n");
			ruu_list_dump(CORE.ifq, f);
		}
		
		if (mt_issue_kind == mt_issue_kind_shared) {
			fprintf(f, "readyq:\n");
			ruu_link_list_dump(CORE.readyq->head, f);
		}
		
		fprintf(f, "eventq:\n");
		ruu_link_list_dump(CORE.eventq->head, f);
			
		FOREACH_THREAD {
			fprintf(f, "Thread %d:\n", thread);
			
			fprintf(f, "ruu:\n");
			ruu_list_dump(THREAD.ruu, f);
			
			fprintf(f, "lsq:\n");
			ruu_list_dump(THREAD.lsq, f);
			
			if (mt_decode_kind != mt_decode_kind_shared) {
				fprintf(f, "ifq:\n");
				ruu_list_dump(THREAD.ifq, f);
			}
			
			if (mt_issue_kind != mt_issue_kind_shared) {
				fprintf(f, "readyq:\n");
				ruu_link_list_dump(THREAD.readyq->head, f);
			}
			
			fprintf(f, "mapped context: %d\n", THREAD.ctx);
			if (ke_valid_ctx(mt->ke, THREAD.ctx))
				ke_dump_ctx(mt->ke, THREAD.ctx, f);
			
			fprintf(f, "\n");
		}
	}
}

/* run fast forward simulation during 'n' cycles;
 * if 'n' < 0, run whole simulation with fast forward;
 * if delay is true, start context ctx in cycle n/ctxnum*ctx */
void mt_fast_forward(struct mt_t *mt, sdword n, int delay)
{
	sdword i, delaytime;
	int ctx;
	
	delaytime = n >= 0 ? n / ke_active_count(mt->ke)
		: 1000000;
	
	for (i = 0; i < n || n < 0; i++) {
		FOREACH_CTX(mt->ke) {
			if (!ke_running(mt->ke, ctx))
				continue;
			if (delay && ctx > i / delaytime)
				continue;
			ke_execute_inst(mt->ke, ctx);
			mt->fastfwd_inst++;
		}
		
		/* next cycle */
		mt->fastfwd_cycles++;
		ke_new_cycle(mt->ke);
		if (!ke_active_count(mt->ke))
			break;
	}
	
	/* kill all finished contexts */
	while (ke_active_count(mt->ke) != ke_alive_count(mt->ke)) {
		FOREACH_CTX(mt->ke) {
			if (ke_finished(mt->ke, ctx)) {
				ke_kill_ctx(mt->ke, ctx);
				break;
			}
		}
	}

	/* update fetch PCs */
	ke_reset_cycle(mt->ke);
	ctxmap_update(mt);
}

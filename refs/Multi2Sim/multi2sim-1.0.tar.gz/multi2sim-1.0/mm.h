/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef MM_H
#define MM_H

#include "kernel/misc.h"

struct mm_t;

/* creation & destruction */
struct mm_t *mm_create();
void mm_free(struct mm_t *mm);

/* translate virtual address + context id to a physical address;
 * if the virtual page is not allocated, create it */
void mm_translate(struct mm_t *mm, int ctx, word vtl_addr, word *phaddr);

/* translate a physical address to a virtual address and a context id;
 * if physical address does not exist, return 0 */
int mm_rtranslate(struct mm_t *mm, word phaddr, int *ctx, word *vtladdr);


#endif

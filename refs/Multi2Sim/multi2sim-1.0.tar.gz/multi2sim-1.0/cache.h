/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef CACHE_H
#define CACHE_H

#include "kernel/misc.h"


/* block status */
#define CACHE_BLK_MODIFIED	0
#define CACHE_BLK_OWNED		1
#define CACHE_BLK_EXCLUSIVE	2
#define CACHE_BLK_SHARED	3
#define CACHE_BLK_INVALID	4

/* cache access command */
#define CACHE_READ		1
#define CACHE_WRITE		2
#define CACHE_EVICT		3



/* Structures */

struct mt_t;
struct cache_t;

enum cache_kind_enum {
	dl1 = 0,
	dl2,
	il1,
	il2,
	dtlb,
	itlb,
	mainmemory
};

enum cache_sharing_enum {
	cache_perthread = 0,
	cache_percore,
	cache_shared
};

enum cache_policy_enum {
	cache_policy_lru = 0,
	cache_policy_random,
	cache_policy_fifo
};

struct cache_opt_t {
	word nsets, lognsets;
	word bsize, logbsize;
	word assoc, logassoc;
	word bmask;
	word lat;
	enum cache_policy_enum policy;
	enum cache_sharing_enum sharing;
	int unified;	/* instruction-data unified */
};

struct cache_blk_t {
	struct cache_blk_t *way_next;
	struct cache_blk_t *way_prev;
	int ready;
	int status;
	word tag;
};

struct cache_set_t {
	struct cache_blk_t *way_head;
	struct cache_blk_t *way_tail;
	struct cache_blk_t *blks;
};

struct cache_t {
	
	/* properties */
	enum	cache_kind_enum kind;
	struct	cache_set_t *sets;
	int	concurrent;		/* # of concurrent accesses */
	
	/* stats */
	dword	hits;
	dword	misses;
	dword	reads;
	dword	writes;
	dword	evicts;
	dword	readreq;
	dword	writereq;
	
	dword	moesi_count[5];		/* # of blocks in each moesi state in each cycle */
	dword	moesi_acc[5];		/* acc # of blocks in each moesi state */
	double	moesi_rate[5];		/* % of blocks with each status, averaging all cycles */
};




/* Configuration parameters */

extern word tlb_miss_lat;
extern word mem_lat;
extern struct cache_opt_t cache_opt[6];


/* Constants */

extern char *cache_name[];
extern int cache_level[];
extern enum cache_kind_enum cache_next[];



/* Functions */

void cache_reg_options();
void cache_init(struct mt_t *mt);
void cache_done(struct mt_t *mt);

/* start a cache access with ESIM; return a unique id for
 * this access */
dword cache_access(struct mt_t *mt, int core, int thread,
	enum cache_kind_enum kind, word addr, int cmd);

/* return true if access with id 'access_id' has been completed */
int cache_completed(dword access_id);
void cache_dump_accesses();

#endif


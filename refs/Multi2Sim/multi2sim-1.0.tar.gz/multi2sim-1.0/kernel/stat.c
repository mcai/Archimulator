/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdlib.h>
#include <string.h>
#include <mhandle.h>

#include "stat.h"
#include "misc.h"
#include "options.h"


/* global private stat data base */
static struct stat_sdb_t *sdb = NULL;


enum stat_class_t {
	sc_int = 0,
	sc_dword,
	sc_sdword,
	sc_double,
	sc_formula,
	sc_note,
	sc_func
};

struct stat_stat_t {
	struct	stat_stat_t *next;
	char	*name;
	char	*desc;
	char	*format;
	enum	stat_class_t sc;
	
	union {
		struct {
			int		*var;
			int		init_val;
		} for_int;
		
		struct {
			dword	*var;
			dword	init_val;
		} for_dword;
		
		struct {
			sdword	*var;
			sdword	init_val;
		} for_sdword;
		
		struct {
			double	*var;
			double	init_val;
		} for_double;
		
		struct {
			char	*formula;
		} for_formula;
		
		struct {
			print_stats_fn_t func;
		} for_func;
		
	} variant;
};

struct stat_sdb_t {
	struct	stat_stat_t *head, *tail;
	struct	eval_t *eval;
	int	width;
};



/* return de value of an identifier */
double get_id_value(char *name)
{
	struct	stat_stat_t *stat;
	double	res = 0;
	
	/* search identifier in data base */
	for (stat = sdb->head; stat; stat = stat->next) {
		if (!strcmp(stat->name, name)) {
			switch (stat->sc) {
			case sc_int:
				res = (double) *stat->variant.for_int.var;
				break;
			case sc_dword:
				res = (double) *stat->variant.for_dword.var;
				break;
			case sc_sdword:
				res = (double) *stat->variant.for_sdword.var;
				break;
			case sc_double:
				res = *stat->variant.for_double.var;
				break;
			case sc_formula:
				res = eval_expr(sdb->eval, stat->variant.for_formula.formula);
				break;
			default:
				panic("erroneous stat->sc for stat '%s'",
				     stat->name);
			}
			break;
		}
	}
	
	/* if not fount in stat data base, search in options data base */
	if (!stat)
		res = opt_get_option(name);
	
	return res;
}



void stat_sdb_init()
{
	sdb = calloc(1, sizeof(struct stat_sdb_t));
	sdb->eval = eval_create(get_id_value);
	sdb->width = 10;
}



void stat_sdb_uninit()
{
	struct stat_stat_t *stat;
	
	if (!sdb)
		return;

	/* free stats */
	while (sdb->head) {
		stat = sdb->head;
		sdb->head = stat->next;
		free(stat->name);
		free(stat->desc);
		if (stat->sc == sc_formula)
			free(stat->variant.for_formula.formula);
		free(stat);
	}
			
	/* free rest */
	eval_free(sdb->eval);
	free(sdb);
	sdb = NULL;
}



void stat_add_stat(struct stat_stat_t *stat)
{
	if (!sdb)
		return;
	
	/* check max width */
	if (strlen(stat->name) > sdb->width)
		sdb->width = strlen(stat->name);
	
	/* add stat to stat list */
	if (!sdb->head)
		sdb->head = sdb->tail = stat;
	else {
		sdb->tail->next = stat;
		sdb->tail = stat;
	}
}



void stat_reg_note(char *note)
{
	struct stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	stat->name = strdup("");
	stat->desc = strdup(note);
	stat->sc = sc_note;
	stat_add_stat(stat);
}


/* register a function */
void stat_reg_func(print_stats_fn_t func)
{
	struct stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	stat->name = strdup("");
	stat->desc = strdup("");
	stat->sc = sc_func;
	stat->variant.for_func.func = func;
	stat_add_stat(stat);
}


void
stat_reg_int(
	char	*name,
	char	*desc,
	int	*var,
	int	init_val,
	char	*format)
{
	struct	stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	
	*var = init_val;
	stat->name = strdup(name);
	stat->desc = strdup(desc);
	stat->format = format ? format : "%12d";
	stat->sc = sc_int;
	stat->variant.for_int.var = var;
	stat->variant.for_int.init_val = init_val;
	stat_add_stat(stat);
}



void
stat_reg_dword(
	char	*name,
	char	*desc,
	dword	*var,
	dword	init_val,
	char	*format)
{
	struct	stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	
	*var = init_val;
	stat->name = strdup(name);
	stat->desc = strdup(desc);
	stat->format = format ? format : "%12llu";
	stat->sc = sc_dword;
	stat->variant.for_dword.var = var;
	stat->variant.for_dword.init_val = init_val;
	stat_add_stat(stat);
}



void
stat_reg_formula(
	char	*name,
	char	*desc,
	char	*expr,
	char	*format)
{
	struct	stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	
	stat->name = strdup(name);
	stat->desc = strdup(desc);
	stat->format = format ? format : "%12f";
	stat->sc = sc_formula;
	stat->variant.for_formula.formula = strdup(expr);
	stat_add_stat(stat);
}



void
stat_reg_sdword(
	char	*name,
	char	*desc,
	sdword	*var,
	sdword	init_val,
	char	*format)
{
	struct	stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	
	*var = init_val;
	stat->name = strdup(name);
	stat->desc = strdup(desc);
	stat->format = format ? format : "%12lld";
	stat->sc = sc_sdword;
	stat->variant.for_sdword.var = var;
	stat->variant.for_sdword.init_val = init_val;
	stat_add_stat(stat);
}



void stat_reg_double(
	char	*name,
	char	*desc,
	double	*var,
	double	init_val,
	char	*format)
{
	struct	stat_stat_t *stat = calloc(1, sizeof(struct stat_stat_t));
	
	*var = init_val;
	stat->name = strdup(name);
	stat->desc = strdup(desc);
	stat->format = format ? format : "%12.2f";
	stat->sc = sc_double;
	stat->variant.for_double.var = var;
	stat->variant.for_double.init_val = init_val;
	stat_add_stat(stat);
}
	


void stat_print_stats(FILE *fd)
{
	struct	stat_stat_t *stat;
	char	s[128];
	int		i;
	
	if (!sdb)
		return;
	
	/* key */
	sprintf(s, "\n%%-%ds %%12s # %%s\n", sdb->width);
	fprintf(fd, s, "stat", "value", "description");
	for (i = 0; i < 60; i++)
		fprintf(fd, "-");
	fprintf(fd, "\n");
	
	/* stats */
	for (stat = sdb->head; stat; stat = stat->next) {
		
		/* actions for all stats */
		if (stat->sc == sc_note) {
			if (*stat->desc)
				fprintf(fd, "\n# %s\n", stat->desc);
			else
				fprintf(fd, "\n");
			continue;
		}
		else if (stat->sc != sc_func) {
			sprintf(s, "%%-%ds ", sdb->width);
			fprintf(fd, s, stat->name);
		}
		
		/* action depending on stat */
		switch (stat->sc) {
		
		case sc_int:
			sprintf(s, stat->format, *stat->variant.for_int.var);
			break;
			
		case sc_dword:
			sprintf(s, stat->format, *stat->variant.for_dword.var);
			break;
			
		case sc_sdword:
			sprintf(s, stat->format, *stat->variant.for_sdword.var);
			break;
			
		case sc_double:
			sprintf(s, stat->format, *stat->variant.for_double.var);
			break;
		
		case sc_formula:
			sprintf(s, stat->format, eval_expr(sdb->eval,
				stat->variant.for_formula.formula));
			break;
			
		case sc_func:
			stat->variant.for_func.func(fd);
			continue;
			
		default:
			panic("estadística '%s' de tipo no válido", stat->name);
		
		}
		
		/* more general actions */
		fprintf(fd, "%12s # %s\n", s, stat->desc);
	}
	fprintf(fd, "\n");
}

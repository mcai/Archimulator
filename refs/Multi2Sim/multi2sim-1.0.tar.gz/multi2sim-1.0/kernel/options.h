/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef OPTIONS_H
#define OPTIONS_H

#include <stdio.h>
#include "misc.h"


void opt_odb_init();
void opt_odb_uninit();


/* macros for signed options */
extern char *opt_sword_defformat;
/*FIXME format */
#define opt_reg_sword(name, desc, var, def_val) \
	opt_reg_word(name, desc, (word *) (var), (word) (def_val))
#define opt_reg_sword_list(name, desc, vars, nvars, nelt, def_val) \
	opt_reg_word_list(name, desc, (word *) (vars), nvars, nelt, (word *) (def_val))


void opt_reg_word(
	char	*name,
	char	*desc,
	word	*var,
	word	def_val);
	
void opt_reg_word_list(
	char	*name,
	char	*desc,
	word	*vars,
	int	nvars,
	int	*nelt,
	word	*def_val);
	
void opt_reg_dword(
	char	*name,
	char	*desc,
	dword	*var,
	dword	def_val);

void opt_reg_double(
	char	*name,
	char	*desc,
	double	*var,
	double	def_val);
	
void opt_reg_string(
	char	*name,
	char	*desc,
	char	**var,
	char	*def_val);
	
void opt_reg_string_list(
	char	*name,
	char	*desc,
	char	**vars,
	int	nvars,
	int	*nelt,
	char	**def_val);

void opt_reg_flag(
	char	*name,
	char	*desc,
	int	*var,
	int	def_val);
	
void opt_reg_flag_list(
	char	*name,
	char	*desc,
	int	*vars,
	int	nvars,
	int	*nelt,
	int	*def_val);
	
void opt_reg_enum(
	char	*name,
	char	*desc,
	int	*var,
	char	**values,
	int	count,
	char	*def_val);


/* operations with odb */
void opt_print_options(FILE *fd);
void opt_check_options(int *argc, char **argv);
void opt_check_config(char *cfg_file);

/* return the double value of a registered option */
double opt_get_option(char *name);


#endif

/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <string.h>
#include <stdio.h>
#include <mhandle.h>
#include <unistd.h>
#include <sys/stat.h>

#include "options.h"


/* global private options data base */
static struct opt_odb_t *odb = NULL;
static char *vtlargv = NULL;	/* virtual args created in config loading */
char *opt_sword_defformat = "%u";


/* option kinds */
enum opt_class_t {
	oc_int = 0,
	oc_dword,
	oc_word,
	oc_float,
	oc_double,
	oc_flag,
	oc_enum,
	oc_string,
	oc_NUM
};

/* Estructura que representa una opción de línea de órdenes */
struct opt_opt_t {

	struct	opt_opt_t *next;
	char	*name;
	char	*desc;
	int	nvars;
	int	*nelt;
	char	*format;

	enum	opt_class_t oc;
	union opt_variant_t {
	
		struct {
			word *var;
		} for_word;
		
		struct {
			dword *var;
		} for_dword;
		
		struct {
			float *var;
		} for_float;

		struct {
			double *var;
		} for_double;

		struct {
			int *var;
		} for_flag;
		
		struct {
			char **values;	/* possible strings */
			int count;	/* number of possible strings */
			int *var;	/* current value (int) */
		} for_enum;
		
		struct {
			char **var;
		} for_string;
		
	} variant;
};


/* Notas que se imprimen antes de la lista de opciones cuando se muestra la
 * ayuda de la línea de órdenes */
struct opt_note_t {
	struct	opt_note_t *next;
	char	*note;
};


/* Definición de base de datos de opciones */
struct opt_odb_t {
	struct	opt_opt_t *options;
	char	*header;
	struct	opt_note_t *notes;
};




/* Creación y destrucción */
void opt_odb_init()
{
	odb = (struct opt_odb_t *) calloc(1, sizeof(struct opt_odb_t));
}


void opt_odb_uninit()
{
	struct opt_opt_t *elt, *next;
	
	if (!odb)
		return;
	
	/* releas options & data base */
	elt = odb->options;
	while (elt) {
		next = elt->next;
		free(elt);
		elt = next;
	}
	free(odb);
	if (vtlargv)
		free(vtlargv);
	odb = NULL;
	vtlargv = NULL;
}


/* Funciones auxiliares */
void add_option(struct opt_opt_t *opt)
{
	struct	opt_opt_t *elt, *prev;

	if (!odb)
		return;
	
	// Opción debe empezar con guión
	if (opt->name[0] != '-')
		panic("option '%s' does not start with '-'", opt->name);
		
	// Busca opción repetida en base de datos
	for (prev = NULL, elt = odb->options;
		elt;
		prev = elt, elt = elt->next)
	{
		if (!strcmp(elt->name, opt->name))
			panic("option '%s' redefined", opt->name);
	}
	
	// Añade la opción
	opt->next = NULL;
	if (prev) prev->next = opt;
	else odb->options = opt;
}


/* Registro de opciones */
#define CHECK_LIST { \
	if (!nvars) \
		panic("options.c: %s: 0-length list not allowed", name); }\

void opt_reg_word(
	char	*name,
	char	*desc,
	word	*var,
	word	def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12d";
	opt->oc = oc_int;
	opt->variant.for_word.var = var;
	add_option(opt);
	*var = def_val;
}

void opt_reg_word_list(
	char	*name,
	char	*desc,
	word	*vars,
	int	nvars,		// nº de entradas en el array (0=indeterminado)
	int	*nelt,		// nº de entradas pasadas como argumentos
	word	*def_val)
{
	struct	opt_opt_t *opt;
	int		i;
	
	CHECK_LIST;
	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = nvars;
	opt->nelt = nelt;
	opt->format = "%d";
	opt->oc = oc_int;
	opt->variant.for_word.var = vars;
	add_option(opt);
	if (nvars)
		for (i = 0; i < nvars; i++)
			vars[i] = def_val[i];
}

void opt_reg_dword(
	char	*name,
	char	*desc,
	dword	*var,
	dword	def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12llu";
	opt->oc = oc_dword;
	opt->variant.for_dword.var = var;
	add_option(opt);
	*var = def_val;
}

void opt_reg_string(
	char	*name,
	char	*desc,
	char	**var,
	char	*def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12s";
	opt->oc = oc_string;
	opt->variant.for_string.var = var;
	add_option(opt);
	*var = def_val;
}

void opt_reg_double(
	char	*name,
	char	*desc,
	double	*var,
	double	def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12.2e";
	opt->oc = oc_double;
	opt->variant.for_double.var = var;
	add_option(opt);
	*var = def_val;
}

void opt_reg_string_list(
	char	*name,
	char	*desc,
	char	**vars,
	int	nvars,		// nº de entradas en el array (0=indeterminado)
	int	*nelt,		// nº de entradas pasadas como argumentos
	char	**def_val)
{
	struct	opt_opt_t *opt;
	int		i;
	
	CHECK_LIST;
	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = nvars;
	opt->nelt = nelt;
	opt->format = "%s";
	opt->oc = oc_string;
	opt->variant.for_string.var = vars;
	add_option(opt);
	if (nvars)
		for (i = 0; i < nvars; i++)
			vars[i] = def_val[i];
}

void opt_reg_flag(
	char	*name,
	char	*desc,
	int	*var,
	int	def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12s";
	opt->oc = oc_flag;
	opt->variant.for_flag.var = var;
	add_option(opt);
	*var = def_val;
}

void opt_reg_flag_list(
	char	*name,
	char	*desc,
	int	*vars,
	int	nvars,		// nº de entradas en el array (0=indeterminado)
	int	*nelt,		// nº de entradas pasadas como argumentos
	int	*def_val)
{
	struct	opt_opt_t *opt;
	int		i;
	
	CHECK_LIST;
	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = nvars;
	opt->nelt = nelt;
	opt->format = "%s";
	opt->oc = oc_flag;
	opt->variant.for_flag.var = vars;
	add_option(opt);
	if (nvars)
		for (i = 0; i < nvars; i++)
			vars[i] = def_val[i];
}

/* returns the index of 'val' in the value list */
int strtoenum(char *val, char **values, int count)
{
	int i;
	char s[100];
	
	/* looks for val in the value list */
	for (i = 0; i < count; i++)
		if (!strcmp(val, values[i]))
			return i;
	
	/* error if not found */
	strcpy(s, "");
	for (i = 0; i < count; i++) {
		if (i)
			strcat(s, "|");
		strcat(s, values[i]);
	}
	fatal("value '%s' not valid; possible values are {%s}",
	     val, s);
	return 0; /* keep compiler happy */
}

void opt_reg_enum(
	char	*name,
	char	*desc,
	int	*var,
	char	**values,
	int	count,
	char	*def_val)
{
	struct opt_opt_t *opt;

	opt = (struct opt_opt_t *) calloc(1, sizeof(struct opt_opt_t));
	opt->name = name;
	opt->desc = desc;
	opt->nvars = 1;
	opt->format = "%12s";
	opt->oc = oc_enum;
	opt->variant.for_enum.var = var;
	opt->variant.for_enum.values = values;
	opt->variant.for_enum.count = count;
	add_option(opt);
	*var = strtoenum(def_val, values, count);
}




/* debug */
void opt_print_options(FILE *fd)
{
	struct	opt_opt_t *opt;
	char	val[128], s[128];
	int	i, nelt;
	
	if (!odb)
		return;
	
	/* key */
	fprintf(fd, "option                    value        # description\n");
	for (i = 0; i < 60; i++)
		fprintf(fd, "-");
	fprintf(fd, "\n");
	
	/* options */
	for (opt = odb->options; opt; opt = opt->next) {
		
		// Acciones generales
		nelt = opt->nelt ? *opt->nelt : opt->nvars;
		fprintf(fd, "%-25s ", opt->name);
		*val = 0;
		
		// Acciones según opción
		switch (opt->oc) {
		
		case oc_int:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_word.var[i]);
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
			
		case oc_dword:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_dword.var[i]);
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
			
		case oc_double:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_double.var[i]);
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
			
		case oc_string:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_string.var[i]);
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
		
		case oc_flag:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_flag.var[i] ? "t" : "f");
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
			
		case oc_enum:
			for (i = 0; i < nelt; i++) {
				sprintf(s, opt->format, opt->variant.for_enum.values[
						opt->variant.for_enum.var[i]]);
				strcat(val, s);
				if (i < nelt - 1) strcat(val, " ");
			}
			break;
			
		default:
			panic("option '%s' not valid", opt->name);
		
		}
		
		fprintf(fd, "%12s # %s\n", val, opt->desc);
	}
	fprintf(fd, "\n");
}




/* Read command line until the current argument is not an option.
 * Modify argc and argv */
#define IS_OPT(X) (argv[X][0]=='-')
#define LAST_ARG(X) ((X)==(*argc-1)||IS_OPT((X)+1))

void opt_check_options(int *argc, char **argv)
{
	int i, nelt = 0, new_argc;
	struct opt_opt_t *opt = NULL;
	
	/* no args */
	if (!odb || *argc <= 1)
		return;
	
	for (i = 1; i < *argc; i++) {
		
		if (IS_OPT(i)) {
	
			for (opt = odb->options; opt; opt = opt->next)
				if (!strcmp(opt->name, argv[i]))
					break;
			if (!opt)
				fatal("%s: invalid option", argv[i]);
			if (LAST_ARG(i))
				fatal("option '%s' without arguments", opt->name);
				
			/* argument counter */
			nelt = 0;
			if (opt->nelt)
				*opt->nelt = 0;
			continue;
		}
		else
		{
			/* no option */
			if (i == 1)
				break;
		}
		
		/* store argument depending on option kind */
		switch (opt->oc) {
		
		case oc_int:
			if (strlen(argv[i]) >= 2 && argv[i][0] == '0' && (argv[i][1] == 'x'
				|| argv[i][1] == 'X'))
				sscanf(argv[i] + 2, "%x", &opt->variant.for_word.var[nelt]);
			else
				opt->variant.for_word.var[nelt] = atoi(argv[i]);
			break;
			
		case oc_dword:
			sscanf(argv[i], "%llu", &opt->variant.for_dword.var[nelt]);
			break;
			
		case oc_double:
			sscanf(argv[i], "%lf", &opt->variant.for_double.var[nelt]);
			break;
			
		case oc_string:
			opt->variant.for_string.var[nelt] = argv[i];
			break;
		
		case oc_flag:
			if (!strcasecmp(argv[i], "t"))
				opt->variant.for_flag.var[nelt] = TRUE;
			else if (!strcasecmp(argv[i], "f"))
				opt->variant.for_flag.var[nelt] = FALSE;
			else fatal("option '%s' can take 't' or 'f'", opt->name);
			break;
			
		case oc_enum:
			opt->variant.for_enum.var[nelt] = strtoenum(argv[i],
				opt->variant.for_enum.values,
				opt->variant.for_enum.count);
			break;
			
		default:
			panic("type of option '%s' not valid", opt->name);
		}
		
		/* update args counter */
		nelt++;
		if (opt->nelt)
			*opt->nelt = nelt;
		if (LAST_ARG(i) && nelt < opt->nvars)
			fatal("%s: option requires %d argument(s)", opt->name, opt->nvars);
		if (!LAST_ARG(i) && nelt >= opt->nvars) {
			i++;
			break;
		}
	}
	
	/* actualiza 'argc' y 'argv' */
	new_argc = *argc - i + 1;
	for (i = 1; i < new_argc; i++)
		argv[i] = argv[i + *argc - new_argc];
	*argc = new_argc;
}



/* Lee configuración de un fichero */
void opt_check_config(char *cfg_file)
{
	FILE	*f;
	char	**argv, *argvcurr, buf[1000], *s, *end;
	int	argc, maxargc = 200, len;
	struct	stat fs;
	
	if (!odb)
		return;
	if (vtlargv)
		fatal("cannot load more than one config file");
	
	/* open file */
	lstat(cfg_file, &fs);
	f = fopen(cfg_file, "rt");
	if (!f)
		fatal("%s: cannot open config file", cfg_file);
	
	/* read arguments */
	argc = 1;
	argv = (char **) calloc(maxargc, sizeof(char *));
	vtlargv = (char *) malloc(fs.st_size + 1);
	argv[0] = "sim";
	argvcurr = vtlargv;
	while (1) {
	
		/* read a line in the file */
		fgets(buf, 1000, f);
		if (feof(f))
			break;
		s = buf;
		
		/* extract arguments */
		while (*s) {
			
			/* erase spaces or end of line */
			while (*s == '\n' || *s == ' ') s++;
			if (!*s) break;
		
			/* maxarg exceeded? */
			if (argc == maxargc)
				fatal("too many arguments in '%s'", cfg_file);
			
			/* get argument length */
			end = index(s, ' ');
			len = end ? end - s : strlen(s);
			if (s[len - 1] == '\n') len--;
			
			/* store argument */
			argv[argc] = argvcurr;
			strncpy(argvcurr, s, len);
			argvcurr[len] = 0;
			argvcurr += len + 1;
			s += len;
			argc++;
		}
	}
	
	/* close & analyze arguments */
	fclose(f);
	opt_check_options(&argc, argv);
	free(argv);
}


/* return the double value of a registered option */
double opt_get_option(char *name)
{
	struct opt_opt_t *opt;
	
	if (!odb)
		return 0.0;
	
	for (opt = odb->options; opt; opt = opt->next) {
		if (!strcmp(opt->name + 1, name)) {
			
			switch (opt->oc) {
				
			case oc_int:
				return (double) *opt->variant.for_word.var;
				
			case oc_dword:
				return (double) *opt->variant.for_dword.var;
				
			case oc_double:
				return *opt->variant.for_double.var;
			
			default:
				panic("cannot get double value for option '%s'", opt->name);
		
			}
		}
	}
	panic("option '%s' does not exist", name);
	return 0.0; /* keep compiler happy */
}

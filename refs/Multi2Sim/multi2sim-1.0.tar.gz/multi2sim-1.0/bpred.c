/* Multi2Sim - Multithread-Multicore Simulation Tool
 * Copyright (C) 2007 Rafael Ubal Tena
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/* bpred.c - branch predictor routines */

/* SimpleScalar(TM) Tool Suite
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 * All Rights Reserved. 
 * 
 * THIS IS A LEGAL DOCUMENT, BY USING SIMPLESCALAR,
 * YOU ARE AGREEING TO THESE TERMS AND CONDITIONS.
 * 
 * No portion of this work may be used by any commercial entity, or for any
 * commercial purpose, without the prior, written permission of SimpleScalar,
 * LLC (info@simplescalar.com). Nonprofit and noncommercial use is permitted
 * as described below.
 * 
 * 1. SimpleScalar is provided AS IS, with no warranty of any kind, express
 * or implied. The user of the program accepts full responsibility for the
 * application of the program and the use of any results.
 * 
 * 2. Nonprofit and noncommercial use is encouraged. SimpleScalar may be
 * downloaded, compiled, executed, copied, and modified solely for nonprofit,
 * educational, noncommercial research, and noncommercial scholarship
 * purposes provided that this notice in its entirety accompanies all copies.
 * Copies of the modified software can be delivered to persons who use it
 * solely for nonprofit, educational, noncommercial research, and
 * noncommercial scholarship purposes provided that this notice in its
 * entirety accompanies all copies.
 * 
 * 3. ALL COMMERCIAL USE, AND ALL USE BY FOR PROFIT ENTITIES, IS EXPRESSLY
 * PROHIBITED WITHOUT A LICENSE FROM SIMPLESCALAR, LLC (info@simplescalar.com).
 * 
 * 4. No nonprofit user may place any restrictions on the use of this software,
 * including as modified by the user, by any other authorized user.
 * 
 * 5. Noncommercial and nonprofit users may distribute copies of SimpleScalar
 * in compiled or executable form as set forth in Section 2, provided that
 * either: (A) it is accompanied by the corresponding machine-readable source
 * code, or (B) it is accompanied by a written offer, with no time limit, to
 * give anyone a machine-readable copy of the corresponding source code in
 * return for reimbursement of the cost of distribution. This written offer
 * must permit verbatim duplication by anyone, or (C) it is distributed by
 * someone who received only the executable form, and is accompanied by a
 * copy of the written offer of source code.
 * 
 * 6. SimpleScalar was developed by Todd M. Austin, Ph.D. The tool suite is
 * currently maintained by SimpleScalar LLC (info@simplescalar.com). US Mail:
 * 2395 Timbercrest Court, Ann Arbor, MI 48105.
 * 
 * Copyright (C) 1994-2003 by Todd M. Austin, Ph.D. and SimpleScalar, LLC.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <mhandle.h>
#include "kernel/options.h"
#include "kernel/stat.h"
#include "bpred.h"


/* configuration parameters */
static int def_bimod_config[1] = {2048};
static int def_twolev_config[4] = {1, 1024, 8, FALSE};
static int def_comb_config[1] = {1024};
static int def_btb_config[2] = {512, 4};

static char *bpred_type;
static int bimod_config[1];
static int twolev_config[4];
static int comb_config[1];
static int btb_config[2];
static int ras_size;


/* register options */
void bpred_reg_options()
{
	opt_reg_string("-bpred", "{perfect|nottaken|taken|bimod|2lev|comb}",
		&bpred_type, "bimod");
	opt_reg_sword_list("-bpred:bimod", "bimodal predictor config"
		" (<table size>)", bimod_config, 1, NULL, def_bimod_config);
	opt_reg_sword_list("-bpred:2lev", "2-level predictor config "
		"(<l1size> <l2size> <hist_size> <xor>)", twolev_config, 4, NULL,
		def_twolev_config);
	opt_reg_sword_list("-bpred:comb", "Combined predictor config (<meta_table_size>)",
		comb_config, 1, NULL, def_comb_config);
	opt_reg_sword("-bpred:ras", "return address stack size (0 = no stack)",
		&ras_size, 8);
	opt_reg_sword_list("-bpred:btb", "BTB config (<nsets> <assoc>)",
		btb_config, 2, NULL, def_btb_config);
}


/* stats */
void bpred_reg_stats(struct bpred_t *bpred)
{
	stat_reg_dword("bpred.addr_hits", "num correct addr-predictions",
		&bpred->addr_hits, 0, NULL);
	stat_reg_dword("bpred.dir_hits", "num correct dir-predictions (incl addr)",
		&bpred->dir_hits, 0, NULL);
	stat_reg_dword("bpred.used_ras", "num RAS predictions used",
		&bpred->used_ras, 0, NULL);
	stat_reg_dword("bpred.used_bimod", "num bimodal predictions used (BPredComd)",
		&bpred->used_bimod, 0, NULL);
	stat_reg_dword("bpred.used_2lev", "num 2-level predictions used (BPredComb)",
		&bpred->used_2lev, 0, NULL);
	stat_reg_dword("bpred.jr_hits", "num correct addr-predictions for JR's",
		&bpred->jr_hits, 0, NULL);
	stat_reg_dword("bpred.jr_seen", "num JR's seen",
		&bpred->jr_seen, 0, NULL);
	stat_reg_dword("bpred.jr_non_ras_hits", "num correct addr-preds for non-RAS JR's",
		&bpred->jr_non_ras_hits, 0, NULL);
	stat_reg_dword("bpred.jr_non_ras_seen", "num non-RAS JR's seen",
		&bpred->jr_non_ras_seen, 0, NULL);
	stat_reg_dword("bpred.misses", "num incorrect predictions",
		&bpred->misses, 0, NULL);
	stat_reg_dword("bpred.lookups", "num lookups",
		&bpred->lookups, 0, NULL);
	stat_reg_dword("bpred.retstack_pops", "number of times a value was popped",
		&bpred->retstack_pops, 0, NULL);
	stat_reg_dword("bpred.retstack_pushed", "number of times a value was pushed",
		&bpred->retstack_pushes, 0, NULL);
	stat_reg_dword("bpred.ras_hits", "num correct return-address predictions",
		&bpred->ras_hits, 0, NULL);
}


/* creation & destruction */
struct bpred_dir_t *bpred_dir_create (
	enum	bpred_class class,
	word	l1size,
	word	l2size,
	word	shift_width,
	word	xor)
{
	struct	bpred_dir_t *pred_dir;
	word	cnt;
	int	flipflop;

	pred_dir = calloc(1, sizeof(struct bpred_dir_t));
	pred_dir->class = class;

	cnt = -1;
	switch (class) {
	case BPred2Level: {
	
		if (!l1size || (l1size & (l1size-1)) != 0)
			fatal("bpred level 1 size must be power of 2 and > 0");
		pred_dir->config.two.l1size = l1size;
		
		if (!l2size || (l2size & (l2size-1)) != 0)
			fatal("bpred level 2 size must be power of 2 and > 0");
		pred_dir->config.two.l2size = l2size;
		
		if (!shift_width || shift_width > 30)
			fatal("bpred shift width must be in range [1, 30]");
		pred_dir->config.two.shift_width = shift_width;
		
		pred_dir->config.two.xor = xor;
		pred_dir->config.two.shiftregs = calloc(l1size, sizeof(int));
		pred_dir->config.two.l2table = calloc(l2size, sizeof(byte));

		/* init counters */
		flipflop = 1;
		for (cnt = 0; cnt < l2size; cnt++) {
			pred_dir->config.two.l2table[cnt] = flipflop;
			flipflop = 3 - flipflop;
		}

		break;
	}

	case BPred2bit:
		if (!l1size || (l1size & (l1size-1)) != 0)
			fatal("bpred level 1 size must be power of 2 and > 0");
		pred_dir->config.bimod.size = l1size;
		pred_dir->config.bimod.table = calloc(l1size, sizeof(byte));
		
		/* init */
		flipflop = 1;
		for (cnt = 0; cnt < l1size; cnt++) {
			pred_dir->config.bimod.table[cnt] = flipflop;
			flipflop = 3 - flipflop;
		}

		break;

	case BPredTaken:
	case BPredNotTaken:
	
		break;

	default:
		panic("bpred.c: tipo erróneo de predictor");
	}

	return pred_dir;
}


void bpred_after_priming(struct bpred_t *bpred)
{
	if (!bpred)
		return;

	bpred->lookups = 0;
	bpred->addr_hits = 0;
	bpred->dir_hits = 0;
	bpred->used_ras = 0;
	bpred->used_bimod = 0;
	bpred->used_2lev = 0;
	bpred->jr_hits = 0;
	bpred->jr_seen = 0;
	bpred->misses = 0;
	bpred->retstack_pops = 0;
	bpred->retstack_pushes = 0;
	bpred->ras_hits = 0;
}


struct bpred_t *__bpred_create(
	enum	bpred_class class,
	word	bimod_size,
	word	l1size,
	word	l2size,
	word	meta_size,
	word	shift_width,
	word	xor,
	word	btb_sets,
	word	btb_assoc,
	word	retstack_size)
{
	struct	bpred_t *pred;

	pred = calloc(1, sizeof(struct bpred_t));
	pred->class = class;

	switch (class) {
	case BPredComb:
		pred->dirpred.bimod =
			bpred_dir_create(BPred2bit, bimod_size, 0, 0, 0);
		pred->dirpred.twolev =
			bpred_dir_create(BPred2Level, l1size, l2size, shift_width, xor);
		pred->dirpred.meta = 
			bpred_dir_create(BPred2bit, meta_size, 0, 0, 0);
		break;

	case BPred2Level:
		pred->dirpred.twolev = 
			bpred_dir_create(class, l1size, l2size, shift_width, xor);
		break;

	case BPred2bit:
		pred->dirpred.bimod = 
			bpred_dir_create(class, bimod_size, 0, 0, 0);

	case BPredTaken:
	case BPredNotTaken:
		break;

	default:
		panic("bpred.c: tipo de predictor inválido.");
	}

	/* return stack */
	switch (class) {
		
	case BPredComb:
	case BPred2Level:
	case BPred2bit:
	{
		int i;

		/* errors */
		if (!btb_sets || (btb_sets & (btb_sets-1)) != 0)
			fatal("btb number of sets must be power of 2 and > 0");
		if (!btb_assoc || (btb_assoc & (btb_assoc-1)) != 0)
			fatal("btb associativity must be power of 2 and > 0");
			
		/* allocate memory */
		pred->btb.btb_data = calloc(btb_sets * btb_assoc,
			sizeof(struct bpred_btb_ent_t));
		pred->btb.sets = btb_sets;
		pred->btb.assoc = btb_assoc;
		
		/* update LRU list */
		if (pred->btb.assoc > 1) {
			for (i = 0; i < (pred->btb.assoc * pred->btb.sets); i++) {
				if (i % pred->btb.assoc != pred->btb.assoc - 1)
					pred->btb.btb_data[i].next = &pred->btb.btb_data[i + 1];
				else
					pred->btb.btb_data[i].next = NULL;	    
				if (i % pred->btb.assoc != pred->btb.assoc - 1)
					pred->btb.btb_data[i + 1].prev = &pred->btb.btb_data[i];
			}
		}

		/* create ras */
		if ((retstack_size & (retstack_size - 1)) != 0)
			fatal("return stack size must be power of 2");
		pred->retstack.size = retstack_size;
		if (retstack_size)
			pred->retstack.stack = calloc(retstack_size, sizeof(struct bpred_btb_ent_t));
		pred->retstack.tos = retstack_size - 1;
      
		break;
	}
    
	case BPredTaken:
	case BPredNotTaken:
		break;
		
	default:
		panic("bpred.c: tipo de predictor no válido");
	}

	return pred;
}


struct bpred_t *bpred_create()
{
	struct bpred_t *bpred;
	
	if (!strcmp(bpred_type, "taken"))
		bpred = __bpred_create(BPredTaken, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		
	else if (!strcmp(bpred_type, "nottaken"))
		bpred = __bpred_create(BPredNotTaken, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		
	else if (!strcmp(bpred_type, "bimod"))
		bpred = __bpred_create(BPred2bit,
			bimod_config[0], 0, 0, 0, 0, 0,
			btb_config[0], btb_config[1], ras_size);
	
	else if (!strcmp(bpred_type, "2lev"))
		bpred = __bpred_create(BPred2Level, 0,
			twolev_config[0], twolev_config[1], 0,
			twolev_config[2], twolev_config[3],
			btb_config[0], btb_config[1], ras_size);
		
	else if (!strcmp(bpred_type, "comb"))
		bpred = __bpred_create(BPredComb,
			bimod_config[0], twolev_config[0],
			twolev_config[1], comb_config[0],
			twolev_config[2], twolev_config[3],
			btb_config[0], btb_config[1], ras_size);
			
	else if (!strcmp(bpred_type, "perfect"))
		bpred = NULL;
		
	else {
		fatal("%s: branch predictor type not valid", bpred_type);
		bpred = NULL; /* compiler happy */
	}
		
	return bpred;
}


void bpred_dir_free(struct bpred_dir_t *pred_dir)
{
	if (!pred_dir)
		return;
	switch (pred_dir->class) {
		case BPred2Level:
			free(pred_dir->config.two.shiftregs);
			free(pred_dir->config.two.l2table);
			break;
			
		case BPred2bit:
			free(pred_dir->config.bimod.table);
			break;
			
		default:
			break;
	}
	free(pred_dir);
}


void bpred_free(struct bpred_t *pred)
{
	if (!pred)
		return;
	switch (pred->class) {
		case BPredComb:
		case BPred2Level:
		case BPred2bit:
			free(pred->btb.btb_data);
			free(pred->retstack.stack);
			break;
			
		default:
			break;
	}
	bpred_dir_free(pred->dirpred.bimod);
	bpred_dir_free(pred->dirpred.twolev);
	bpred_dir_free(pred->dirpred.meta);
	free(pred);
}




#define BIMOD_HASH(PRED, ADDR) \
  ((((ADDR) >> 19) ^ ((ADDR) >> 2)) & ((PRED)->config.bimod.size-1))

char *bpred_dir_lookup(
	struct	bpred_dir_t *pred_dir,
	word	baddr)
{
	byte	*p = NULL;

	switch (pred_dir->class) {
	case BPred2Level: {
    
		int	l1index, l2index;

		l1index = (baddr >> 2) & (pred_dir->config.two.l1size - 1);
		l2index = pred_dir->config.two.shiftregs[l1index];
        
		if (pred_dir->config.two.xor) {
			l2index = (((l2index ^ (baddr >> 2))
				& ((1 << pred_dir->config.two.shift_width) - 1))
				| ((baddr >> 2) << pred_dir->config.two.shift_width));
		} else {
			l2index = l2index |
				((baddr >> 2) << pred_dir->config.two.shift_width);
		}
		l2index = l2index & (pred_dir->config.two.l2size - 1);
		p = &pred_dir->config.two.l2table[l2index];
	}
	break;
		
	case BPred2bit:
		p = &pred_dir->config.bimod.table[BIMOD_HASH(pred_dir, baddr)];
		break;
		
	case BPredTaken:
	case BPredNotTaken:
	
		break;
		
	default:
		panic("bpred.c: clase de predictor errónea.");
	}

	return (char *) p;
}

word bpred_lookup(
	struct	bpred_t *pred,
	word	baddr,
	word	btarget,
	struct	md_instfld_t *instfld,
	int	is_call,
	int	is_return,
	struct	bpred_update_t *dir_update_ptr,
	int	*stack_recover_idx)
{
	struct	bpred_btb_ent_t *pbtb = NULL;
	int		index, i;

	if (!dir_update_ptr)
		panic("bpred.c: no hay registro de actualización del predictor.");

	if (!pred)
		return 0;
	*stack_recover_idx = pred->retstack.size ?
		pred->retstack.tos : 0;
	
	if (!instfld->flags & F_CTRL)
		return 0;

	
	pred->lookups++;
	dir_update_ptr->dir.ras = FALSE;
	dir_update_ptr->pdir1 = NULL;
	dir_update_ptr->pdir2 = NULL;
	dir_update_ptr->pmeta = NULL;

	switch (pred->class) {
	case BPredComb:
		if ((instfld->flags & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND)) {
			char	*bimod, *twolev, *meta;
			
			bimod = bpred_dir_lookup(pred->dirpred.bimod, baddr);
			twolev = bpred_dir_lookup(pred->dirpred.twolev, baddr);
			meta = bpred_dir_lookup(pred->dirpred.meta, baddr);
			dir_update_ptr->pmeta = meta;
			dir_update_ptr->dir.meta  = (*meta >= 2);
			dir_update_ptr->dir.bimod = (*bimod >= 2);
			dir_update_ptr->dir.twolev  = (*twolev >= 2);
			if (*meta >= 2) {
				dir_update_ptr->pdir1 = twolev;
				dir_update_ptr->pdir2 = bimod;
			} else {
				dir_update_ptr->pdir1 = bimod;
				dir_update_ptr->pdir2 = twolev;
			}
		}
		break;
		
	case BPred2Level:
		if ((instfld->flags & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND)) {
			dir_update_ptr->pdir1 =
				bpred_dir_lookup(pred->dirpred.twolev, baddr);
		}
		break;
		
	case BPred2bit:
		if ((instfld->flags & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND)) {
			dir_update_ptr->pdir1 =
				bpred_dir_lookup(pred->dirpred.bimod, baddr);
		}
		break;
		
	case BPredTaken:
		return btarget;
		
	case BPredNotTaken:
		if ((instfld->flags & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND)) {
			return baddr + sizeof(word);
		} else {
			return btarget;
		}
		
	default:
		panic("bpred.c: clase de predictor errónea");
	}


	if (is_return && pred->retstack.size) {
		word target = pred->retstack.stack[pred->retstack.tos].target;
		pred->retstack.tos = (pred->retstack.tos + pred->retstack.size - 1)
			% pred->retstack.size;
		pred->retstack_pops++;
		dir_update_ptr->dir.ras = TRUE;
		return target;
	}

	if (is_call && pred->retstack.size) {
		pred->retstack.tos = (pred->retstack.tos + 1) % pred->retstack.size;
		pred->retstack.stack[pred->retstack.tos].target = 
			baddr + sizeof(word) * 2;
		pred->retstack_pushes++;
	}
  
	index = (baddr >> 2) & (pred->btb.sets - 1);
	if (pred->btb.assoc > 1) {
		index *= pred->btb.assoc;
		for (i = index; i < (index + pred->btb.assoc) ; i++) {
			if (pred->btb.btb_data[i].addr == baddr) {
				pbtb = &pred->btb.btb_data[i];
				break;
			}
		}
		
	} else {
		pbtb = &pred->btb.btb_data[index];
		if (pbtb->addr != baddr)
			pbtb = NULL;
	}

	if ((instfld->flags & (F_CTRL|F_UNCOND)) == (F_CTRL|F_UNCOND))
		return (pbtb ? pbtb->target : 1);

	if (!pbtb)
		return ((*(dir_update_ptr->pdir1) >= 2) ? 1 : 0);
	else
		return ((*(dir_update_ptr->pdir1) >= 2) ? pbtb->target : 0);
}





void bpred_recover(
	struct	bpred_t *pred,
	word	baddr,
	int	stack_recover_idx)
{
	if (!pred || pred->class == BPredTaken || pred->class == BPredNotTaken)
		return;
	pred->retstack.tos = stack_recover_idx;
	if (stack_recover_idx < 0 || stack_recover_idx >= pred->retstack.size)
		panic("recuperación fallida de pila de saltos en predictor");
}



void bpred_update(
	struct	bpred_t *pred,
	word	baddr,
	word	btarget,
	int	taken,
	int	pred_taken,
	int	correct,
	struct	md_instfld_t *instfld,
	struct	bpred_update_t *dir_update_ptr)
{
	struct	bpred_btb_ent_t *pbtb = NULL;
	struct	bpred_btb_ent_t *lruhead = NULL, *lruitem = NULL;
	int	index, i;

	if (!pred)
		return;
	if (!(instfld->flags & F_CTRL))
		return;

	if (correct)
		pred->addr_hits++;
	if (!!pred_taken == !!taken)
		pred->dir_hits++;
	else
		pred->misses++;
	if (dir_update_ptr->dir.ras) {
		pred->used_ras++;
		if (correct)
			pred->ras_hits++;
	} else if ((instfld->flags & (F_CTRL|F_COND)) == (F_CTRL|F_COND)) {
		if (dir_update_ptr->dir.meta)
			pred->used_2lev++;
		else
			pred->used_bimod++;
	}

	if (instfld->flags & F_RET) {
		pred->jr_seen++;
		if (correct)
			pred->jr_hits++;
      
		if (!dir_update_ptr->dir.ras) {
			pred->jr_non_ras_seen++;
			if (correct)
				pred->jr_non_ras_hits++;
		} else {
			return;
		}
	}

	if (pred->class == BPredNotTaken || pred->class == BPredTaken)
		return;



	if ((instfld->flags & (F_CTRL|F_UNCOND)) != (F_CTRL|F_UNCOND) &&
		(pred->class == BPred2Level || pred->class == BPredComb))
	{
		int	l1index, shift_reg;
      
		l1index = (baddr >> 2) & (pred->dirpred.twolev->config.two.l1size - 1);
		shift_reg = (pred->dirpred.twolev->config.two.shiftregs[l1index] << 1)
			| (!!taken);
		pred->dirpred.twolev->config.two.shiftregs[l1index] =
			shift_reg & ((1 << pred->dirpred.twolev->config.two.shift_width) - 1);
	}

	if (taken) {
		index = (baddr >> 2) & (pred->btb.sets - 1);
      
		if (pred->btb.assoc > 1) {
			index *= pred->btb.assoc;
	  
			for (i = index; i < (index + pred->btb.assoc) ; i++) {
				if (pred->btb.btb_data[i].addr == baddr) {
					assert(!pbtb);
					pbtb = &pred->btb.btb_data[i];
				}
	      
				assert(pred->btb.btb_data[i].prev 
					!= pred->btb.btb_data[i].next);
				if (!pred->btb.btb_data[i].prev) {
					assert(!lruhead);
					lruhead = &pred->btb.btb_data[i];
				}
				if (!pred->btb.btb_data[i].next) {
					assert(!lruitem);
					lruitem = &pred->btb.btb_data[i];
				}
			}
			assert(lruhead && lruitem);
	  
			if (!pbtb)
				pbtb = lruitem;	
				
			if (pbtb != lruhead) {
			
				if (pbtb->prev)
					pbtb->prev->next = pbtb->next;
				if (pbtb->next)
					pbtb->next->prev = pbtb->prev;
					
				pbtb->next = lruhead;
				pbtb->prev = NULL;
				lruhead->prev = pbtb;
				assert(pbtb->prev || pbtb->next);
				assert(pbtb->prev != pbtb->next);
			}
		} else {
			pbtb = &pred->btb.btb_data[index];
		}
	}
      

	if (dir_update_ptr->pdir1) {
		if (taken) {
			if (*dir_update_ptr->pdir1 < 3)
				++*dir_update_ptr->pdir1;
		} else {
			if (*dir_update_ptr->pdir1 > 0)
				--*dir_update_ptr->pdir1;
		}
	}

	if (dir_update_ptr->pdir2) {
		if (taken) {
			if (*dir_update_ptr->pdir2 < 3)
				++*dir_update_ptr->pdir2;
		} else {
			if (*dir_update_ptr->pdir2 > 0)
				--*dir_update_ptr->pdir2;
		}
	}

	if (dir_update_ptr->pmeta) {
		if (dir_update_ptr->dir.bimod != dir_update_ptr->dir.twolev) {
		
			if (dir_update_ptr->dir.twolev == (word)taken) {
				if (*dir_update_ptr->pmeta < 3)
					++*dir_update_ptr->pmeta;
			} else {

				if (*dir_update_ptr->pmeta > 0)
					--*dir_update_ptr->pmeta;
			}
		}
	}


	if (pbtb) {
		assert(taken);
		if (pbtb->addr == baddr) {
			if (!correct)
				pbtb->target = btarget;
		} else {
			pbtb->addr = baddr;
			pbtb->op = instfld->op;
			pbtb->target = btarget;
		}
	}
}

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <signal.h>
#include <unistd.h>
#include <esim.h>
#include <chrono.h>
#include <execinfo.h>
#include <mhandle.h>

#include "kernel/public.h"
#include "mt.h"
#include "cache.h"


static dword max_cycles = 0;
static dword max_inst = 0;
static char *sfastfwd = "0";
static int fastfwd_delay = 0;
static sdword fastfwd;
static char *ctxfile = "";
static char *configfile = "";
static char *debugfile = "";
static char *sim_title = "";

struct mt_t *mt; /* FIXME static */


static void sim_reg_options()
{
	opt_reg_string("-title", "simulation title", &sim_title);
	opt_reg_string("-config", "processor configuration file", &configfile);
	opt_reg_string("-ctxconfig", "context configuration file", &ctxfile);
	opt_reg_string("-debug", "file to dump debug information", &debugfile);	
	opt_reg_uint64("-max_cycles", "cycle to stop program (0=no stop)", &max_cycles);
	opt_reg_uint64("-max_inst", "max number of retireed instructions (0=no max)", &max_inst);
	opt_reg_string("-fastfwd", "cycles to run with fast simulation (<x>|all)", &sfastfwd);
	opt_reg_bool("-fastfwd_delay", "fast forward delay (t|f)", &fastfwd_delay);
}


static void sim_reg_stats()
{
}


static void sim_backtrace()
{
	void *bt[20];
	int i, n;
	n = backtrace(bt, 20);
	fprintf(stderr, "Simulator backtrace:");
	for (i = 0; i < n; i++) {
		fprintf(stderr, " %p", bt[i]);
	}
	fprintf(stderr, "\n");
}


/* signal handler for SIGINT and SIGALRM */
#define ALARM_INTERVAL	5
static int sigint_received;
static void mt_sighandler(int signum)
{
	sdword cycle = ke_cycle(mt->ke);
	static dword last_inst_count;
	static sdword last_cycle;
	FILE *f;
	
	switch (signum) {
	
	case SIGINT:
		if (sigint_received)
			abort();
		sigint_received = TRUE;
		mt_dump(mt, stderr);
		cache_dump_accesses(stdout);
		fprintf(stderr, "SIGINT received\n");
		break;
		
	case SIGALRM:
		if (cycle - last_cycle == 0)
			panic("cycle %llu: simulator stalled in stage %s", cycle, mt->stage);
		if (mt->retired - last_inst_count == 0) {
			mt_dump(mt, stderr);
			cache_dump_accesses(stdout);
			
			{
				long long int when;
				int event;
				void *data;
				printf("esim events:\n");
				while ((when = esim_extract_event(&event, &data)))
					printf("\tcycle %8lld ev=%d\n", when, event);
			}
			
			panic("cycle %llu: pipeline stalled", cycle);
		}
		last_inst_count = mt->retired;
		last_cycle = cycle;
		alarm(ALARM_INTERVAL);
		break;
	
	case SIGABRT:
		signal(SIGABRT, SIG_DFL);
		mt_dump(mt, stdout);
		ke_dump_stats(mt->ke, 1);
		cache_dump_accesses(stdout);
		sim_backtrace();
		exit(1);
		break;
	
	case SIGUSR1:
		ke_dump_stats(mt->ke, 1);
		break;
		
	case SIGUSR2:
		f = fopen("multi2sim.log", "wt");
		cache_dump_accesses(f);
		fclose(f);
		break;
	
	}
}


int main(int argc, char **argv)
{
	/* options & stats */
	stat_init();
	opt_init();
	sim_reg_options();
	ptrace_reg_options();
	sim_reg_stats();
	mt_reg_options();
	cache_reg_options();
	ic_reg_options();
	opt_check_options(&argc, argv);
	if (*configfile)
		opt_check_config(configfile);

	/* initial information */
	fprintf(stderr, "\nOut-of-Order Multi-Thread Processor Simulator\n");
	fprintf(stderr, "Last compilation: %s %s\n\n", __DATE__, __TIME__);
	opt_print_options(stderr);

	/* initialization */
	ptrace_init();
	uinst_init();
	esim_init();
	debug_open(debugfile);

	/* load programs */
	mt = mt_create();
	mt_load_progs(mt, argc, argv, ctxfile);
	mt_start(mt);

	/* fast forward simulation */
	fastfwd = strcmp(sfastfwd, "all") ? atoi(sfastfwd) : -1;
	mt_fast_forward(mt, fastfwd, fastfwd_delay);

	/* exhaustive simulation */
	signal(SIGINT, &mt_sighandler);
	signal(SIGABRT, &mt_sighandler);
	signal(SIGUSR1, &mt_sighandler);
	signal(SIGUSR2, &mt_sighandler);
	signal(SIGALRM, &mt_sighandler);
	alarm(ALARM_INTERVAL);
	
	while (ke_alive_count(mt->ke)) {

		/* processor stages */
		mt_retire(mt);
		mt_writeback(mt);
		mt_refresh(mt);
		mt_issue(mt);
		mt_dispatch(mt);
		mt_fetch(mt);

		/* next cycle */
		ke_new_cycle(mt->ke);
		mt->cycles = ke_cycle(mt->ke);
		ptrace_newcycle(mt->cycles);
		esim_process_events();

		/* halt execution? */
		if (sigint_received)
			break;
		if (max_cycles && mt->cycles >= max_cycles)
			break;
		if (max_inst && mt->retired >= max_inst)
			break;
	}
	signal(SIGALRM, SIG_IGN);

	/* empty esim */
	esim_empty();

	/* finalization */
	debug_close();
	mt_finish(mt);
	stat_print_stats(stderr);
	stat_done();
	opt_done();
	ptrace_done();
	mt_free(mt);
	uinst_done();
	esim_done();
	debug_close();
	mhandle_done();

	return 0;
}

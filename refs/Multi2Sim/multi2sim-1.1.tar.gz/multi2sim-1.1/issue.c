#include "mt.h"


/* Issue one instruction in a thread from the corresponding LQ.
 * Return FALSE if no instruction could be issued */
static int issue_lq_one(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *lq = THREAD.lq;
	struct uinst_t *load;
	sdword now = ke_cycle(mt->ke);
	word phaddr;
	
	/* Find instruction to issue */
	for (; !lnlist_eol(lq); lnlist_next(lq)) {
		
		/* Get element from LQ.
		 * If it is not memready, go to the next one */
		load = lnlist_get(lq);
		if (!load->memready)
			continue;
		
		/* Access memory only if data was not forwarded */
		if (!load->forwarded) {
		
			/* If no additional concurrent access is
			* enabled in the cache, no other load will issue. */
			if (!cache_can_access(mt, core, thread, dl1) ||
				!cache_can_access(mt, core, thread, dtlb))
				return FALSE;
			
			/* Try to reserve read port.
			* If no read port available, no other load will issue. */
			if (!fu_reserve(CORE.fu, RdPort))
				return FALSE;
			
			/* Ok, we can issue. Access the data TLB and cache */
			mm_translate(mt->mm, ke_memid(mt->ke, THREAD.ctx), load->effaddr, &phaddr);
			load->dl1_access_id = cache_access(mt, core, thread, dl1, phaddr, CACHE_READ);
			load->dtlb_access_id = cache_access(mt, core, thread, dtlb,
				mt_tlb_address(mt, THREAD.ctx, load->effaddr), CACHE_READ);
		}
		
		/* If load was speculatively bypassed, introduce 20 cycles fetch stall.
		 * This is an approximate penalty of the reexecution of speculative instructions */
		if (load->bypassed)
			THREAD.fetch_stall = MAX(THREAD.fetch_stall, 20);
		
		/* Remove 'load' from LQ */
		assert(load->in_lq);
		assert(!load->in_iq);
		lnlist_remove(lq);
		load->in_lq = FALSE;
		
		/* Schedule 'load' in Event Queue for next cycle.
		 * Writeback stage will check if it is really completed. */
		assert(!load->in_eventq);
		load->memissued = TRUE;
		load->issuewhen = now;
		load->when = now + 1;
		eventq_insert(CORE.eventq, load);
		load->in_eventq = TRUE;
		
		/* Instruction issued */
		ptrace_newstage(load->seq, "M", 0);
		return TRUE;
	}
	
	/* Exited from loop, no 'load' issued */
	return FALSE;
}


/* Issue one instruction in a thread from the corresponding IQ.
 * Return FALSE if no instruction could be issued */
static int issue_iq_one(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *iq = THREAD.iq;
	struct phregs_t *phregs = THREAD.phregs;
	struct uinst_t *uinst;
	sdword now = ke_cycle(mt->ke);
	int lat, fu_class;
	
	/* Find instruction to issue */
	for (; !lnlist_eol(iq); lnlist_next(iq)) {
		
		/* Get element from IQ */
		uinst = lnlist_get(iq);
		assert(uinst_exists(uinst));
		assert(uinst->core == core);
		assert(uinst->thread == thread);
		if (!uinst->ready)
			continue;
		
		/* If inst does not require fu, one cycle latency.
		 * Otherwise, try to reserve the corresponding fu. */
		if (!uinst->instfld.fu_class) {
			lat = 1;
		} else {
			fu_class = UINST_IS_MEM(uinst) ? IntALU : uinst->instfld.fu_class;
			lat = fu_reserve(CORE.fu, fu_class);
			if (!lat)
				continue;
		}
		
		/* Ok, instruction was issued to the corresponding fu.
		 * Remove it from IQ */
		assert(uinst->in_iq);
		lnlist_remove(iq);
		uinst->in_iq = FALSE;
		
		/* Schedule inst in Event Queue */
		assert(!uinst->in_eventq);
		assert(lat > 0);
		uinst->issued = TRUE;
		uinst->issuewhen = now;
		uinst->when = now + lat;
		eventq_insert(CORE.eventq, uinst);
		uinst->in_eventq = TRUE;
		
		/* Notify physical register module, because 'pending_readers'
		 * should be decreased for input dependencies */
		phregs_read(phregs, uinst);
		
		/* Instruction issued */
		ptrace_newstage(uinst->seq, "EX", 0);
		THREAD.issued++;
		mt->issued++;
		return TRUE;
	}
	
	/* Exited from loop, no instruction issued */
	return FALSE;
}


/* Issue one instruction in a thread. Give priority to LQ.
 * Return FALSE if no instruction could be issued in the thread. */
static int issue_thread_one(struct mt_t *mt, int core, int thread)
{
	/* Try to schedule inst from LQ */
	if (issue_lq_one(mt, core, thread))
		return TRUE;
	
	/* Try to schedule inst from IQ */
	if (issue_iq_one(mt, core, thread))
		return TRUE;
	
	/* No instruction issued */
	return FALSE;
}


static void issue_core(struct mt_t *mt, int core)
{
	int quant, pass;
	
	/* Decrement fu busy counters */
	fu_release(CORE.fu);
	
	/* Issue */
	quant = mt_issue_width;
	
	switch (mt_issue_kind) {
	
	case mt_issue_kind_shared:
		pass = mt_threads;
		while (quant && pass) {
			CORE.issue_current = (CORE.issue_current + 1) % mt_threads;
			if (issue_thread_one(mt, core, CORE.issue_current)) {
				quant--;
				pass = mt_threads;
			} else
				pass--;
		}
		break;
	
	case mt_issue_kind_timeslice:
		
		/* Find a thread to issue */
		for (pass = mt_threads; quant && pass; pass--) {
			CORE.issue_current = (CORE.issue_current + 1) % mt_threads;
			if (issue_thread_one(mt, core, CORE.issue_current)) {
				quant--;
				break;
			}
		}
		while (quant && pass) {
			if (!issue_thread_one(mt, core, CORE.issue_current))
				break;
			quant--;
		}
		break;
	}
}


void mt_issue(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_issue";
	FOREACH_CORE
		issue_core(mt, core);
}

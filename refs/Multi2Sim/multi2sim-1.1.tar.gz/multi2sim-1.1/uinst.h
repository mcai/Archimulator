#ifndef UINST_H
#define UINST_H

#include <stdio.h>
#include <list.h>
#include <lnlist.h>


#define UINST_IS_STORE(uinst) (uinst->instfld.flags & F_STORE)
#define UINST_IS_LOAD(uinst) (uinst->instfld.flags & F_LOAD)
#define UINST_IS_MEM(uinst) (uinst->instfld.flags & F_MEM)
#define UINST_IS_CTRL(uinst) (uinst->instfld.flags & F_CTRL)


/* Micro Instruction (uinst)
 * This is an element from an IFQ, IQ, LSQ, VB or EventQ.
 * They are created at the fetch stage (inserted in the IFQ) and
 * destroyed when they exit the pipeline */

struct uinst_t {
	
	/* calculated in mt_fetch() */
	struct	md_instfld_t instfld;
	int ctx, core, thread;
	dword seq;
	word regs_pc, phys_pc;
	word regs_npc, regs_nnpc;
	word pred_npc, pred_nnpc;
	int halt;
	int specmode;
	int misspred;
	int recover_inst;
	word effaddr;
	sdword when; /* cycle when inst is completed */
	sdword issuewhen; /* cycle when inst was issued */
	
	/* branch prediction */
	int bimod_taken, bimod_idx;
	int gshare_taken, gshare_idx;
	int choice_value, choice_idx;
	
	/* ids of cache access for 'loads' */
	dword dl1_access_id;
	dword dtlb_access_id;
	
	/* queues where instruction is in */
	int in_ifq;
	int in_iq;
	int in_lq;
	int in_sq;
	int in_eventq;
	int in_rob;

	/* instruction status */
	int ready;
	int issued;
	int completed;
	
	/* 'load' instruction status */
	int memready;
	int memissued;
	int memcompleted;
	int forwarded;		/* a previous aliasing store forwarded data */
	int bypassed;		/* speculatively bypassed */
	
	/* pysical register file mapping */
	int ph_in[3];		/* physical input regs */
	int ph_out[2];		/* physical output regs */
	int ph_oout[2];		/* old output mappings */
};


/* initialization and destruction of uinst repositories */
void uinst_init();
void uinst_done();

struct uinst_t *uinst_create();
void uinst_free(struct uinst_t *uinst);
void uinst_free_if_not_queued(struct uinst_t *uinst);
int uinst_exists(struct uinst_t *uinst);
void uinst_dump(struct uinst_t *uinst, FILE *f);
void uinst_list_dump(struct list_t *uinst_list, FILE *f);
void uinst_lnlist_dump(struct lnlist_t *uinst_list, FILE *f);

#endif

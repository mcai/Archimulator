#include <string.h>
#include "mt.h"

#define PTRACE_MAX_THREADS	8

static FILE *ptrace_outfd;
static FILE *ptrace_pcfd[PTRACE_MAX_THREADS];
static char *ptrace_pc = "";
static char *ptrace_file = "";


/* start ptrace */
void ptrace_init() {
	ptrace_outfd = open_write(ptrace_file);
	if (!ptrace_outfd && ptrace_file[0])
		fatal("%s: cannot open trace file", ptrace_file);
}


/* stop ptrace */
void ptrace_done() {
	int i;
	close_file(ptrace_outfd);
	for (i = 0; i < PTRACE_MAX_THREADS; i++)
		close_file(ptrace_pcfd[i]);
}


void ptrace_reg_options()
{
	opt_reg_string("-ptrace:file", "ptrace output file (stdout|stderr|<fname>)",
		&ptrace_file);
	opt_reg_string("-ptrace:pc", "trace file for pc sequence of ctx 0",
		&ptrace_pc);
}


void ptrace_newpc(int ctx, word pc, int specmode)
{
	char name[MAX_STRING_SIZE];
	static dword committed = 0;
	if (!ptrace_pc[0])
		return;
	if (ctx >= PTRACE_MAX_THREADS)
		fatal("increase PTRACE_MAX_THREADS");
	if (!ptrace_pcfd[ctx]) {
		sprintf(name, "%s%02d.log", ptrace_pc, ctx);
		ptrace_pcfd[ctx] = open_write(name);
	}
	fprintf(ptrace_pcfd[ctx], "%s0x%x%s\t",
		specmode ? "(" : "", pc, specmode ? ")" : "");
	if (!specmode)
		fprintf(ptrace_pcfd[ctx], "%llu", (long long) ++committed);
	fprintf(ptrace_pcfd[ctx], "\n");
}


void ptrace_newinst(dword seq, int ctx, word inst,
	word pc, word addr)
{
	if (!ptrace_outfd)
		return;
	
	fprintf(ptrace_outfd, "+ %llu %d 0x%08x 0x%08x ", (long long) seq, ctx, pc, addr);
	md_print_inst(ptrace_outfd, inst, pc);
	fprintf(ptrace_outfd, "\n");

	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newuop(dword seq, int ctx, char *desc, word pc, word addr)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "+ %llu %d 0x%08x 0x%08x %s",
		(long long) seq, ctx, pc, addr, desc);
	fprintf(ptrace_outfd, "\n");

	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_endinst(dword seq)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "- %llu\n", (long long) seq);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newcycle(sdword cycle)
{
	if (!ptrace_outfd)
		return;
		
	fprintf(ptrace_outfd, "@ %lld\n", (long long) cycle);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}


void ptrace_newstage(dword seq, char *pstage, word pevents)
{
	if (!ptrace_outfd)
		return;
	fprintf(ptrace_outfd, "* %llu %s 0x%08x\n", (long long) seq, pstage, pevents);
	if (ptrace_outfd == stderr || ptrace_outfd == stdout)
		fflush(ptrace_outfd);
}

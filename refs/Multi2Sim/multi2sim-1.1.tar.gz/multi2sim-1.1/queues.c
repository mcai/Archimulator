#include "mt.h"




/* Instruction Fetch Queue */

word ifq_size = 32;
enum ifq_kind_enum ifq_kind = ifq_kind_shared;


void ifq_reg_options()
{
	static char *ifq_kind_map[] = { "private", "shared" };
	opt_reg_enum("-ifq_kind", "fetch queue sharing {private|shared}",
		(int *) &ifq_kind, ifq_kind_map, 2);
	opt_reg_uint32("-ifq_size", "fetch queue size (when private, per thread) 0=unlimited",
		&ifq_size);
}


void ifq_init(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		THREAD.ifq = lnlist_create();
}


void ifq_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD {
		while (lnlist_count(THREAD.ifq))
			uinst_free_if_not_queued(ifq_dequeue(THREAD.ifq));
		lnlist_free(THREAD.ifq);
	}
}


int ifq_full(struct mt_t *mt, int core, int thread)
{
	int count = 0;
	
	/* Unlimited IFQ is never full */
	if (!ifq_size)
		return FALSE;
	
	/* Count instructions in IFQ depending on sharing model */
	if (ifq_kind == ifq_kind_shared) {
		FOREACH_THREAD
			count += lnlist_count(THREAD.ifq);
	} else
		count = lnlist_count(THREAD.ifq);
	
	/* Return TRUE if IFQ is full */
	assert(count <= ifq_size);
	return count == ifq_size;
}


void ifq_enqueue(struct lnlist_t *ifq, struct uinst_t *uinst)
{
	assert(!uinst->in_ifq);
	uinst->in_ifq = TRUE;
	lnlist_out(ifq);
	lnlist_insert(ifq, uinst);
}


struct uinst_t *ifq_dequeue(struct lnlist_t *ifq)
{
	struct uinst_t *uinst;
	if (!lnlist_count(ifq))
		return NULL;
	lnlist_head(ifq);
	uinst = lnlist_get(ifq);
	assert(uinst_exists(uinst));
	assert(uinst->in_ifq);
	lnlist_remove(ifq);
	uinst->in_ifq = FALSE;
	return uinst;
}




/* Reorder Buffer */

word rob_size = 32;
enum rob_kind_enum rob_kind = rob_kind_private;


void rob_reg_options()
{
	static char *rob_kind_map[] = { "private", "shared" };
	opt_reg_enum("-rob_kind", "reorder buffer sharing {private|shared}",
		(int *) &rob_kind, rob_kind_map, 2);
	opt_reg_uint32("-rob_size", "reorder buffer size (if private, per thread); 0=unlimited",
		&rob_size);
}


void rob_init(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		THREAD.rob = lnlist_create();
}


void rob_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD {
		while (lnlist_count(THREAD.rob))
			uinst_free_if_not_queued(rob_dequeue(THREAD.rob));
		lnlist_free(THREAD.rob);
	}
}


int rob_full(struct mt_t *mt, int core, int thread)
{
	int count = 0;
	
	/* Unlimited ROBs are never full */
	if (!rob_size)
		return FALSE;
	
	/* Count instructions in ROB depending on sharing model */
	if (rob_kind == rob_kind_private) {
		count = lnlist_count(THREAD.rob);
	} else {
		FOREACH_THREAD
			count += lnlist_count(THREAD.rob);
	}
	
	/* Return TRUE if full */
	assert(count <= rob_size);
	return count == rob_size;
}


void rob_enqueue(struct lnlist_t *rob, struct uinst_t *uinst)
{
	assert(!uinst->in_rob);
	uinst->in_rob = TRUE;
	lnlist_out(rob);
	lnlist_insert(rob, uinst);
}


struct uinst_t *rob_dequeue(struct lnlist_t *rob)
{
	struct uinst_t *uinst;
	if (!lnlist_count(rob))
		return NULL;
	lnlist_head(rob);
	uinst = lnlist_get(rob);
	assert(uinst_exists(uinst));
	assert(uinst->in_rob);
	lnlist_remove(rob);
	uinst->in_rob = FALSE;
	return uinst;
}




/* Instruction Queue */

word iq_size = 32;
enum iq_kind_enum iq_kind = iq_kind_private;


void iq_reg_options()
{
	static char *iq_kind_map[] = { "private", "shared" };
	opt_reg_enum("-iq_kind", "instruction queue sharing {private|shared}",
		(int *) &iq_kind, iq_kind_map, 2);
	opt_reg_uint32("-iq_size", "instruction queue size (if private, per thread) 0=unlimited",
		&iq_size);
}


void iq_init(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		THREAD.iq = lnlist_create();
}


void iq_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD {
		while (lnlist_count(THREAD.iq))
			uinst_free_if_not_queued(iq_dequeue(THREAD.iq));
		lnlist_free(THREAD.iq);
	}
}


int iq_full(struct mt_t *mt, int core, int thread)
{
	int count = 0;
	
	/* Unlimited IQs are never full */
	if (!iq_size)
		return FALSE;
	
	/* Count instructions in IQ depending on sharing model */
	if (iq_kind == iq_kind_private) {
		count = lnlist_count(THREAD.iq);
	} else {
		FOREACH_THREAD
			count += lnlist_count(THREAD.iq);
	}
	
	/* Return TRUE if full */
	assert(count <= iq_size);
	return count == iq_size;
}


void iq_enqueue(struct lnlist_t *iq, struct uinst_t *uinst)
{
	assert(!uinst->in_iq);
	uinst->in_iq = TRUE;
	lnlist_out(iq);
	lnlist_insert(iq, uinst);
}


struct uinst_t *iq_dequeue(struct lnlist_t *iq)
{
	struct uinst_t *uinst;
	if (!lnlist_count(iq))
		return NULL;
	lnlist_head(iq);
	uinst = lnlist_get(iq);
	assert(uinst_exists(uinst));
	assert(uinst->in_iq);
	lnlist_remove(iq);
	uinst->in_iq = FALSE;
	return uinst;
}




/* Load Queue */

word lq_size = 32;


void lq_reg_options()
{
	opt_reg_uint32("-lq_size", "load queue size (if private, per thread)",
		&lq_size);
}


void lq_init(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		THREAD.lq = lnlist_create();
}


void lq_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD {
		while (lnlist_count(THREAD.lq))
			uinst_free_if_not_queued(lq_dequeue(THREAD.lq));
		lnlist_free(THREAD.lq);
	}
}


void lq_enqueue(struct lnlist_t *lq, struct uinst_t *uinst)
{
	assert(!uinst->in_lq);
	uinst->in_lq = TRUE;
	lnlist_out(lq);
	lnlist_insert(lq, uinst);
}


struct uinst_t *lq_dequeue(struct lnlist_t *lq)
{
	struct uinst_t *uinst;
	if (!lnlist_count(lq))
		return NULL;
	lnlist_head(lq);
	uinst = lnlist_get(lq);
	assert(uinst_exists(uinst));
	assert(uinst->in_lq);
	lnlist_remove(lq);
	uinst->in_lq = FALSE;
	return uinst;
}




/* Store Queue */

word sq_size = 32;


void sq_reg_options()
{
	opt_reg_uint32("-sq_size", "store queue size (if private, per thread)",
		&sq_size);
}


void sq_init(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		THREAD.sq = lnlist_create();
}


void sq_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD {
		while (lnlist_count(THREAD.sq))
			uinst_free_if_not_queued(sq_dequeue(THREAD.sq));
		lnlist_free(THREAD.sq);
	}
}


void sq_enqueue(struct lnlist_t *sq, struct uinst_t *uinst)
{
	assert(!uinst->in_sq);
	uinst->in_sq = TRUE;
	lnlist_out(sq);
	lnlist_insert(sq, uinst);
}


struct uinst_t *sq_dequeue(struct lnlist_t *sq)
{
	struct uinst_t *uinst;
	if (!lnlist_count(sq))
		return NULL;
	lnlist_head(sq);
	uinst = lnlist_get(sq);
	assert(uinst_exists(uinst));
	assert(uinst->in_sq);
	lnlist_remove(sq);
	uinst->in_sq = FALSE;
	return uinst;
}




/* Event Queue */

void eventq_init(struct mt_t *mt)
{
	int core;
	FOREACH_CORE
		CORE.eventq = lnlist_create();
}


void eventq_done(struct mt_t *mt)
{
	int core;
	FOREACH_CORE {
		while (lnlist_count(CORE.eventq))
			uinst_free_if_not_queued(eventq_extract(CORE.eventq));
		lnlist_free(CORE.eventq);
	}
}


static int eventq_compare(const void *item1, const void *item2)
{
	const struct uinst_t *uinst1 = item1;
	const struct uinst_t *uinst2 = item2;
	return uinst1->when != uinst2->when ? uinst1->when - uinst2->when
		: uinst1->seq - uinst2->seq;
}


int eventq_longlat(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *eventq = CORE.eventq;
	struct uinst_t *uinst;
	sdword now = ke_cycle(mt->ke);
	
	for (lnlist_head(eventq); !lnlist_eol(eventq); lnlist_next(eventq)) {
		uinst = lnlist_get(eventq);
		if (uinst->thread != thread)
			continue;
		if (now - uinst->issuewhen > 20)
			return TRUE;
	}
	return FALSE;
}


void eventq_insert(struct lnlist_t *eventq, struct uinst_t *uinst)
{
	struct uinst_t *item;
	assert(!uinst->in_eventq);
	lnlist_head(eventq);
	for (;;) {
		item = lnlist_get(eventq);
		if (!item || eventq_compare(uinst, item) < 0)
			break;
		lnlist_next(eventq);
	}
	lnlist_insert(eventq, uinst);
	uinst->in_eventq = TRUE;
}


struct uinst_t *eventq_extract(struct lnlist_t *eventq)
{
	struct uinst_t *uinst;
	if (!lnlist_count(eventq))
		return NULL;
	lnlist_head(eventq);
	uinst = lnlist_get(eventq);
	assert(uinst_exists(uinst));
	assert(uinst->in_eventq);
	lnlist_remove(eventq);
	uinst->in_eventq = FALSE;
	return uinst;
}

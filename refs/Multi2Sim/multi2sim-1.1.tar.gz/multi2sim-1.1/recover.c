#include "mt.h"

#define REMOVE_FROM_LNLIST(LNLIST)					\
	lnlist_head(LNLIST);						\
	while (!lnlist_eol(LNLIST)) {					\
		uinst = lnlist_get(LNLIST);				\
		if (uinst->thread == thread && uinst->specmode) {	\
			lnlist_remove(LNLIST);				\
			uinst->in_##LNLIST = FALSE;			\
			uinst_free_if_not_queued(uinst);		\
		} else lnlist_next(LNLIST);				\
	}
	

void mt_recover(struct mt_t *mt, int core, int thread)
{
	int ctx, idx;
	struct lnlist_t *ifq, *rob, *iq, *lq, *sq, *eventq;
	struct uinst_t *uinst;
	struct phregs_t *phregs;
	struct regs_t *regs;
	
	ctx = THREAD.ctx;
	regs = ke_regs(mt->ke, ctx);

	eventq = CORE.eventq;
	ifq = THREAD.ifq;
	rob = THREAD.rob;
	iq = THREAD.iq;
	lq = THREAD.lq;
	sq = THREAD.sq;
	phregs = THREAD.phregs;
	
	/* Remove instructions of this thread in
	 * IFQ, IQ, LQ, SQ and Event Queue */
	REMOVE_FROM_LNLIST(ifq);
	REMOVE_FROM_LNLIST(iq);
	REMOVE_FROM_LNLIST(lq);
	REMOVE_FROM_LNLIST(sq);
	REMOVE_FROM_LNLIST(eventq);

	/* Remove instructions from ROB, restoring the state of the
	 * physical register file. */
	for (idx = lnlist_count(rob) - 1; idx >= 0; idx--) {
		
		/* Get instruction */
		lnlist_goto(rob, idx);
		uinst = lnlist_get(rob);
		assert(uinst->thread == thread);
		if (!uinst->specmode)
			break;
		
		/* Do we have to decrement pending_readers? */
		if (!uinst->issued)
			phregs_read(phregs, uinst);
		
		/* Do we have to mark destination physical registers as
		 * completed? */
		if (UINST_IS_LOAD(uinst) && !uinst->memcompleted)
			phregs_write(phregs, uinst);
		if (!UINST_IS_LOAD(uinst) && !uinst->completed)
			phregs_write(phregs, uinst);
		
		/* Undo map and remove entry in ROB */
		phregs_undo(phregs, uinst);
		lnlist_remove(rob);
		uinst->in_rob = FALSE;
		uinst_free_if_not_queued(uinst);
	}
	
	/* If we actually fetched wrong instructions, recover kernel */
	if (THREAD.specmode) {
		ke_recover(mt->ke, ctx);
		THREAD.specmode = FALSE;
	}

	/* Recover penalty - Stall fetch */
	THREAD.fetch_stall = MAX(THREAD.fetch_stall, mt_recover_penalty);
	
	/* Stats */
	mt->misspred++;
	THREAD.fetch_npc = regs->regs_npc;
	THREAD.fetch_nnpc = regs->regs_nnpc;
}

#include "mt.h"


/* Kernel Contexts with Core-Thread Mapping */

struct ctxmap_t
{
	int count;
	struct {
		int core, thread;
	} ctx[KE_MAXCTX];
};


void ctxmap_init(struct mt_t *mt)
{
	int ctx, core, thread;
	
	mt->map = calloc(1, sizeof(struct ctxmap_t));
	for (ctx = 0; ctx < KE_MAXCTX; ctx++)
		mt->map->ctx[ctx].core =
		mt->map->ctx[ctx].thread = -1;
	FOREACH_CORE
		FOREACH_THREAD
			THREAD.ctx = -1;
}


void ctxmap_done(struct mt_t *mt)
{
	free(mt->map);
}


int ctxmap_count(struct mt_t *mt)
{
	return mt->map->count;
}


/* Return the corresponding kernel context of a pair core-thread;
 * if no kernel context is associated, return -1 */
int ctxmap_thread(struct mt_t *mt, int core, int thread)
{
	if (core < 0 || core >= mt_cores ||
		thread < 0 || thread >= mt_threads)
		return -1;
	return THREAD.ctx;
}


/* Return the pair core-thread where a kernel context is allocated;
 * if it was not allocated, try to allocate it */
void ctxmap_ctx(struct mt_t *mt, int ctx, int *core, int *thread)
{
	int i, j, mapcore = -1, mapthread = -1, ok = 0;
	ke_assert_ctx(mt->ke, ctx);
	
	/* not yet allocated? */
	if (mt->map->ctx[ctx].core < 0) {
		for (i = j = 0; i < mt_cores && !ok; i++) {
			for (j = 0; j < mt_threads && !ok; j++) {
				if (mt->core[i].thread[j].ctx < 0) {
					ok = 1;
					mapcore = i;
					mapthread = j;
				}
			}
		}
		if (!ok)
			fatal("too much software contexts (increase mt_cores or mt_threads)");
		mt->core[mapcore].thread[mapthread].ctx = ctx;
		mt->map->ctx[ctx].core = mapcore;
		mt->map->ctx[ctx].thread = mapthread;
		mt->map->count++;
		debug("ctx %d allocated in core %d - thread %d", ctx, mapcore, mapthread);
	}
	
	/* return core-thread */
	*core = mt->map->ctx[ctx].core;
	*thread = mt->map->ctx[ctx].thread;
}


void ctxmap_unmap(struct mt_t *mt, int core, int thread)
{
	assert(THREAD.ctx >= 0);
	mt->map->ctx[THREAD.ctx].core = -1;
	mt->map->ctx[THREAD.ctx].thread = -1;
	THREAD.ctx = -1;
	mt->map->count--;
}


/* Make shure that all kernel contexts are allocated in some thread */
void ctxmap_update(struct mt_t *mt)
{
	int ctx, core, thread;
	
	FOREACH_CTX(mt->ke) {
		struct regs_t *regs = ke_regs(mt->ke, ctx);
		if (mt->map->ctx[ctx].core < 0 || mt->map->ctx[ctx].thread < 0) {
			ctxmap_ctx(mt, ctx, &core, &thread);
			THREAD.fetch_npc = regs->regs_npc;
			THREAD.fetch_nnpc = regs->regs_nnpc;
		}
	}
}

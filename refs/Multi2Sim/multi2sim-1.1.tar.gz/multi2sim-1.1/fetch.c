#include "mt.h"


static int can_fetch(struct mt_t *mt, int core, int thread)
{
	/* following conditions must be enforced to fetch:
	 *  1) the kernel context is in state 'running'
	 *  2) the fetch stage is not stalled
	 *  3) the pending cache misses are resolved */
	return THREAD.ctx >= 0 &&
		ke_running(mt->ke, THREAD.ctx) &&
		!THREAD.fetch_stall &&
		cache_completed(THREAD.il1_id) &&
		cache_completed(THREAD.itlb_id);
}


/* Access level 1 instruction cache. Return FALSE if block is not
 * immediately available. */
static int il1_read(struct mt_t *mt, int core, int thread)
{
	word paddr, fetch_blk;
	
	/* If fetch buffer of current thread has already the block,
	 * we do not need to fetch */
	fetch_blk = THREAD.fetch_nnpc & ~(cache_opt[il1].bsize - 1);
	if (fetch_blk == THREAD.fetch_blk)
		return TRUE;
	
	/* Check if maximum number of concurrent accesses allow
	 * current operation */
	if (!cache_can_access(mt, core, thread, il1) ||
		!cache_can_access(mt, core, thread, itlb))
		return FALSE;
	
	/* Access instruction cache and tlb */
	mm_translate(mt->mm, ke_memid(mt->ke, THREAD.ctx), THREAD.fetch_npc, &paddr);
	THREAD.il1_id = cache_access(mt, core, thread,
		il1, paddr, CACHE_READ);
	THREAD.itlb_id = cache_access(mt, core, thread,
		itlb, mt_tlb_address(mt, THREAD.ctx, THREAD.fetch_npc),
		CACHE_READ);
	THREAD.fetch_blk = fetch_blk;
	
	/* If access is not immediately available, return FALSE */
	if (!can_fetch(mt, core, thread))
		return FALSE;
	
	/* Ok, we read the block successfully */
	return TRUE;
}


static void fetch_thread(struct mt_t *mt, int core, int thread, int quant)
{
	word inst, phys_pc;
	int ctx, result, done = 0;
	struct regs_t *regs;
	struct mem_t *mem;
	struct md_instfld_t instfld;
	struct uinst_t *uinst;
	struct lnlist_t *ifq = THREAD.ifq;
	
	/* can we fetch? */
	if (!can_fetch(mt, core, thread)
		|| !quant
		|| ifq_full(mt, core, thread))
		return;
	
	/* get thread context */
	ctx = THREAD.ctx;
	assert(ctx >= 0);
	
	/* Read a block of instructions */
	if (!il1_read(mt, core, thread))
		return;
	
	/* fetch instructions */
	while (quant && !done) {
		
		/* check if context is still running by a call to can_fetch */
		if (!can_fetch(mt, core, thread))
			break;
		
		/* do we have place in ifq? */
		if (ifq_full(mt, core, thread))
			break;
		
		/* update specmode */
		regs = ke_regs(mt->ke, ctx);
		if (regs->regs_npc != THREAD.fetch_npc)
			THREAD.specmode = TRUE;
		
		/* notify the kernel the next inst it must fetch */
		ke_set_npc(mt->ke, ctx, THREAD.fetch_npc);
	
		/* fetch instruction from memory */
		THREAD.fetch_pc = THREAD.fetch_npc;
		THREAD.fetch_npc = THREAD.fetch_nnpc;
		if (!THREAD.specmode && THREAD.fetch_pc & 3)
			fatal("ctx%d: 0x%x: not aligned pc", ctx, THREAD.fetch_pc);
		mem = ke_mem(mt->ke, ctx);
		mem_read_word(mem, THREAD.fetch_pc & ~3, &inst);
		
		/* functional simulation */
		result = ke_execute_inst(mt->ke, ctx);
		if (!result && !THREAD.specmode)
			fatal("0x%x: not implemented instruction", THREAD.fetch_pc);
		ke_instfld(mt->ke, ctx, &instfld);
		assert(regs->regs_pc == THREAD.fetch_pc);
		
		/* do we have a new context? */
		if (ke_alive_count(mt->ke) > ctxmap_count(mt))
			ctxmap_update(mt);
		
		/* If next address to fetch is not inside current block, done */
		if (THREAD.fetch_npc >> cache_opt[il1].logbsize !=
			THREAD.fetch_pc >> cache_opt[il1].logbsize)
			done = TRUE;
		
		/* Calculate physical PC */
		mm_translate(mt->mm, ke_memid(mt->ke, ctx),
			regs->regs_pc, &phys_pc);
		
		/* Create element to place in ifq */
		uinst = uinst_create();
		uinst->instfld = instfld;
		uinst->ctx = ctx;
		uinst->core = core;
		uinst->thread = thread;
		uinst->seq = ++mt->seq;
		uinst->regs_pc = regs->regs_pc;		/* THREAD.fetch_pc */
		uinst->regs_npc = regs->regs_npc;
		uinst->regs_nnpc = regs->regs_nnpc;
		uinst->pred_npc = THREAD.fetch_npc;
		uinst->phys_pc = phys_pc;
		uinst->halt = ke_finished(mt->ke, ctx);
		uinst->effaddr = ke_effaddr(mt->ke, ctx);
		uinst->specmode = THREAD.specmode;
		uinst->recover_inst = regs->regs_npc != THREAD.fetch_npc && !THREAD.specmode;
			
		/* Access branch predictor to compute fetch_nnpc */
		uinst->pred_nnpc = bpred_lookup(THREAD.bpred, uinst);
		THREAD.fetch_nnpc = uinst->pred_nnpc;
		uinst->misspred = UINST_IS_CTRL(uinst) && !THREAD.specmode &&
			uinst->pred_nnpc != uinst->regs_nnpc;
		
		/* Insert element in IFQ */
		uinst->in_ifq = TRUE;
		lnlist_out(ifq);
		lnlist_insert(ifq, uinst);
		
		/* another instruction fetched */
		ptrace_newinst(mt->seq, ctx, inst, THREAD.fetch_pc, 0);
		ptrace_newstage(mt->seq, "IF", 0);
		mt->fetched++;
		THREAD.fetched++;
		quant--;
	}
}


static void fetch_core(struct mt_t *mt, int core)
{
	int thread, must_switch, new, count, i;
	int canfetch[MAX_THREADS], quant[MAX_THREADS];
	sdword cycle;
	
	/* calculate number of running threads in this core */
	count = 0;
	FOREACH_THREAD {
	
		/* decrement fetch locks */
		if (THREAD.fetch_stall)
			THREAD.fetch_stall--;
			
		/* can fetch from this context */
		quant[thread] = 0;
		canfetch[thread] = can_fetch(mt, core, thread);
		if (canfetch[thread])
			count++;
	}
	
	/* cannot fetch from any thread */
	if (!count)
		return;
	
	/* If flag 'wait_pipe_empty' is active, we must wait until the pipeline is
	 * empty. If it isn't so, stall fetch */
	if (CORE.fetch_wait_pipe_empty) {
		if (!mt_pipe_empty(mt, core))
			return;
		CORE.fetch_wait_pipe_empty = FALSE;
	}
	
	/* assign quantum to each thread */
	switch (mt_fetch_kind) {
	
	case mt_fetch_kind_multiple:
	
		if (mt_fetch_priority == mt_fetch_priority_icount) {
			
			/* set 3 levels of thread priority:
			 *   level 0: threads with more than 3/4 RUU occupancy
			 *   level 1: threads with 2/4 to 3/4 RUU occupancy
			 *   level 2: threads with 0 to 2/4 RUU occupancy
			 * Fetch 'level' inst from each thread until 'fetch_width'
			 * completes */
			 
			int total = mt_fetch_width;
			int level[MAX_THREADS];
			
			/* assign priority level */
			FOREACH_THREAD {
				level[thread] = 0;
				if (!canfetch[thread])
					continue;
				if (lnlist_count(THREAD.rob) > rob_size * 3 / 4) {
					canfetch[thread] = 0;
					count--;
				} else if (lnlist_count(THREAD.rob) > rob_size * 2 / 4) {
					level[thread] = 1;
				} else
					level[thread] = 2;
			}
			
			/* we could have no thread to fetch now */
			if (!count)
				return;
			
			/* assign quantums */
			while (total) {
				CORE.fetch_current = thread = (CORE.fetch_current + 1) % mt_threads;
				if (!level[thread])
					continue;
				level[thread] = MIN(level[thread], total);
				quant[thread] += level[thread];
				total -= level[thread];
			}
			
		} else {
		
			/* fetch_priority = mt_fetch_priority_equal */
			int total = mt_fetch_width;
			while (total) {
				CORE.fetch_current = (CORE.fetch_current + 1) % mt_threads;
				if (!canfetch[CORE.fetch_current])
					continue;
				quant[CORE.fetch_current]++;
				total--;
			}
		}
		break;
	
	case mt_fetch_kind_switchonevent:
		
		/* make context switch if:
			a) thread quantum expired
			b) some issued instruction latency exceeds thread switch penalty */
		cycle = ke_cycle(mt->ke);
		thread = CORE.fetch_current;
		must_switch = !ke_running(mt->ke, THREAD.ctx);
		if (cycle - CORE.fetch_switch > mt_quantum ||
			eventq_longlat(mt, core, thread) ||
			THREAD.current_mm_accesses ||
			must_switch)
		{
			/* find a new thread to switch to */
			for (new = (thread + 1) % mt_threads; new != thread;
				new = (new + 1) % mt_threads)
			{
				if (canfetch[new]) {
					if (must_switch)
						break;
					if (!eventq_longlat(mt, core, new) &&
						!THREADI(new).current_mm_accesses)
						break;
				}
			}
				
			/* if thread switch successful */
			if (new != thread) {
				CORE.fetch_current = new;
				CORE.fetch_switch = cycle;
				if (mt_switch_penalty)
					THREADI(new).fetch_stall = mt_switch_penalty;
				else
					CORE.fetch_wait_pipe_empty = TRUE;
			}
		}
			
		/* assign quantum to selected thread */
		quant[CORE.fetch_current] = mt_fetch_width;
		break;
		
	case mt_fetch_kind_timeslice:
		
		for (i = 0; i < mt_threads; i++) {
			CORE.fetch_current = (CORE.fetch_current + 1) % mt_threads;
			if (canfetch[CORE.fetch_current])
				break;
		}
		assert(i < mt_threads);
		quant[CORE.fetch_current] = mt_fetch_width;
		break;
	
	}
	
	/* fetch from each thread */
	FOREACH_THREAD
		fetch_thread(mt, core, thread, quant[thread]);
}


void mt_fetch(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_fetch";
	FOREACH_CORE
		fetch_core(mt, core);
}

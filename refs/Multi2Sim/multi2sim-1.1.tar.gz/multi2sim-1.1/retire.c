#include "mt.h"


/* Write in the level 1 data cache. */
static void dl1_write(struct mt_t *mt, int core, int thread, word addr)
{
	word paddr;
	
	assert(cache_can_access(mt, core, thread, dl1));
	assert(cache_can_access(mt, core, thread, dtlb));
	mm_translate(mt->mm, ke_memid(mt->ke, THREAD.ctx), addr, &paddr);
	cache_access(mt, core, thread, dl1, paddr, CACHE_WRITE);
	cache_access(mt, core, thread, dtlb,
		mt_tlb_address(mt, THREAD.ctx, addr), CACHE_READ);
}


static int can_retire_thread(struct mt_t *mt, int core, int thread)
{
	struct uinst_t *uinst;
	struct lnlist_t *rob = THREAD.rob;

	/* Check if there are instructions in the ROB */
	if (!lnlist_count(rob))
		return FALSE;
	
	/* Get instruction from ROB head */
	lnlist_head(rob);
	uinst = lnlist_get(rob);
	
	/* In the ROB architecture, instructions must be completed in order
	 * to be retired */
	if (mt_arch == mt_arch_rob) {
		if (UINST_IS_LOAD(uinst) && !uinst->memcompleted)
			return FALSE;
		if (!uinst->completed)
			return FALSE;
	}
	
	/* If it is a store, check if instruction cache permits access */
	if (UINST_IS_STORE(uinst)) {
		if (!uinst->completed)
			return FALSE;
		if (!cache_can_access(mt, core, thread, dl1) ||
			!cache_can_access(mt, core, thread, dtlb))
			return FALSE;
	}
	
	/* Epoch Initiators in the VB architecture */
	if (mt_arch == mt_arch_vb) {
	
		/* Loads cannot leave VB until address is computed */
		if (UINST_IS_LOAD(uinst) && !uinst->completed)
			return FALSE;
	
		/* Branches cannot leave VB until they are completed */
		if (UINST_IS_CTRL(uinst) && !uinst->completed)
			return FALSE;
	}
	
	/* Ok, we can retire */
	return TRUE;
}


static void retire_thread(struct mt_t *mt, int core, int thread, int quant)
{
	struct lnlist_t *rob = THREAD.rob;
	struct lnlist_t *sq = THREAD.sq;
	struct phregs_t *phregs = THREAD.phregs;
	struct uinst_t *uinst, *store;
	
	while (quant && can_retire_thread(mt, core, thread)) {
		
		/* Get instruction at the head of the VB */
		lnlist_head(rob);
		uinst = lnlist_get(rob);
		assert(uinst_exists(uinst));
		assert(uinst->core == core);
		assert(uinst->thread == thread);
		
		/* Get associated structures */
		
		/* First instruction in specmode; recover */
		if (uinst->specmode && mt_recover_kind == mt_recover_kind_retire) {
			mt_recover(mt, core, thread);
			continue;
		}
		
		/* Free physical registers */
		assert(!uinst->specmode);
		phregs_retire(phregs, uinst);
		
		/* Stores */
		if (UINST_IS_STORE(uinst)) {
			
			/* Find 'store' in SQ */
			lnlist_head(sq);
			store = lnlist_get(sq);
			assert(store == uinst);
			
			/* Access Memory */
			dl1_write(mt, core, thread, store->effaddr);
			
			/* Remove it from SQ */
			lnlist_remove(sq);
			store->in_sq = FALSE;
		}

		/* If this is the last inst of a context */
		if (uinst->halt) {
			ke_kill_ctx(mt->ke, uinst->ctx);
			ctxmap_unmap(mt, core, thread);
		}

		/* Stats */
		ptrace_newstage(uinst->seq, "C", 0);
		ptrace_endinst(uinst->seq);
		THREAD.retired++;
		mt->retired++;
		if (UINST_IS_CTRL(uinst))
			mt->branches++;
		quant--;
		
		/* Retire instruction */
		lnlist_head(rob);
		lnlist_remove(rob);
		uinst->in_rob = FALSE;
		uinst_free_if_not_queued(uinst);
	}
}


static void retire_core(struct mt_t *mt, int core)
{
	int pass, quant, new;
	
	switch (mt_retire_kind) {

	case mt_retire_kind_shared:
		pass = mt_threads;
		quant = mt_retire_width;
		while (quant && pass) {
			CORE.retire_current = (CORE.retire_current + 1) % mt_threads;
			if (can_retire_thread(mt, core, CORE.retire_current)) {
				retire_thread(mt, core, CORE.retire_current, 1);
				quant--;
				pass = mt_threads;
			} else
				pass--;
		}
		break;
	
	case mt_retire_kind_timeslice:
	
		/* look for a not empty VB */
		new = (CORE.retire_current + 1) % mt_threads;
		while (new != CORE.retire_current && !can_retire_thread(mt, core, new))
			new = (new + 1) % mt_threads;
		
		/* retire new thread */
		CORE.retire_current = new;
		retire_thread(mt, core, new, mt_retire_width);
		break;
	
	}
}


void mt_retire(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_retire";
	FOREACH_CORE
		retire_core(mt, core);
}

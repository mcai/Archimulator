#include <stdlib.h>
#include <assert.h>
#include <mhandle.h>
#include "mm.h"

#define MM_INITIAL_SIZE		(1<<10)
#define MM_LOG_PAGE_SIZE	(12)
#define MM_PAGE_SIZE		(1<<MM_LOG_PAGE_SIZE)
#define MM_PAGE_MASK		(MM_PAGE_SIZE-1)
#define MM_FRAME_MASK		(~MM_PAGE_MASK)


/* element of frame list */
struct frame_t {
	int	ctx;
	word	vtladdr;
};


/* element of pages hash table */
struct page_t {
	char	valid;
	word	phaddr;
	int	ctx;
	word	vtladdr;
};


struct mm_t
{
	/* hash table of allocated pages */
	struct	page_t	*page;
	word	page_count;
	word	page_size;
	
	/* list of frames */
	struct	frame_t *frame;
	word	frame_size;
	
	/* last translate */
	int	last_valid;
	int	last_ctx;
	word	last_vtladdr;
	word	last_phaddr;
};


/* creation & destruction */
struct mm_t *mm_create()
{
	struct mm_t *mm;
	mm = calloc(1, sizeof(struct mm_t));
	mm->frame_size = MM_INITIAL_SIZE;
	mm->page_size = MM_INITIAL_SIZE;
	mm->frame = calloc(mm->frame_size, sizeof(struct frame_t));
	mm->page = calloc(mm->page_size, sizeof(struct page_t));
	mm->last_ctx = -1;
	return mm;
}


void mm_free(struct mm_t *mm)
{
	free(mm->frame);
	free(mm->page);
	free(mm);
}


/* if page exists, return idx where it is;
 * if it does not exist, return idx where it must be placed;
 * 'vtladdr' must be a page start address */
static word mm_hash_pos(struct mm_t *mm, int ctx, word vtladdr)
{
	word idx;
	assert(ctx >= 0);
	idx = (vtladdr + (mm->page_size / (ctx + 1))) % mm->page_size;
	while (mm->page[idx].valid) {
		if (mm->page[idx].ctx == ctx && mm->page[idx].vtladdr == vtladdr)
			break;
		idx = MOD(idx + 1, mm->page_size);
	}
	return idx;
}


/* grow page hash table */
static void mm_grow_pages(struct mm_t *mm)
{
	struct	page_t *oldpage = mm->page;
	word	oldsize = mm->page_size;
	word	i, idx;
	
	/* create new table */
	mm->page_size = oldsize << 1;
	mm->page = calloc(mm->page_size, sizeof(struct page_t));
	for (i = 0; i < oldsize; i++) {
		if (oldpage[i].valid) {
			idx = mm_hash_pos(mm, oldpage[i].ctx, oldpage[i].vtladdr);
			mm->page[idx] = oldpage[i];
		}
	}
	free(oldpage);
}


/* grow list of frames */
static void mm_grow_frames(struct mm_t *mm)
{
	struct frame_t *new;
	word newsize = mm->frame_size << 1;
	new = calloc(newsize, sizeof(struct frame_t));
	memcpy(new, mm->frame, mm->page_count * sizeof(struct frame_t));
	free(mm->frame);
	mm->frame = new;
	mm->frame_size = newsize;
}


void mm_translate(struct mm_t *mm, int ctx, word vtladdr, word *phaddr)
{
	word idx;
	word vtlpage = vtladdr & MM_FRAME_MASK;
	word vtloffs = vtladdr & MM_PAGE_MASK;
	struct page_t *page;
	struct frame_t *frame;
	
	/* last translation? */
	if (ctx == mm->last_ctx && vtlpage == mm->last_vtladdr
		&& mm->last_valid) {
		*phaddr = mm->last_phaddr + vtloffs;
		return;
	}
	
	/* grow list or frames? */
	if (mm->page_count >= mm->frame_size)
		mm_grow_frames(mm);
	if (mm->page_count >= mm->page_size / 3)
		mm_grow_pages(mm);
	
	/* if page does not exist, create it */
	idx = mm_hash_pos(mm, ctx, vtlpage);
	page = &mm->page[idx];
	if (!page->valid) {
	
		/* create a frame */
		frame = &mm->frame[mm->page_count];
		frame->ctx = ctx;
		frame->vtladdr = vtlpage;
		page->valid = TRUE;
		page->ctx = ctx;
		page->vtladdr = vtlpage;
		page->phaddr = mm->page_count << MM_LOG_PAGE_SIZE;
		mm->page_count++;
	}
	
	/* return */
	mm->last_ctx = ctx;
	mm->last_vtladdr = vtlpage;
	mm->last_phaddr = page->phaddr;
	mm->last_valid = TRUE;
	*phaddr = page->phaddr + vtloffs;
}


int mm_rtranslate(struct mm_t *mm, word phaddr, int *ctx, word *vtladdr)
{
	word idx;
	word phoffs = phaddr & MM_PAGE_MASK;
	idx = phaddr >> MM_LOG_PAGE_SIZE;
	if (idx >= mm->page_count)
		return FALSE;
	*ctx = mm->frame[idx].ctx;
	*vtladdr = mm->frame[idx].vtladdr + phoffs;
	return TRUE;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../kernel/misc.h"
#include "table.h"

#define TABLE_TITLE "Traza (seq, thread_id, pc, inst)"


void ussage() {
	printf("Sintaxis: ptrace [-s <offs>] [-c <cycle>]\n"
		"\t-pc <offs>   Comienza traza a partir del PC <offs> de la forma 0xXXX\n"
		"\t-c <cycle>   Comienza traza a partir del ciclo <cycle>\n"
		"\t-i <inst>    Comienza traza después de encontrar instrucción <inst>\n"
		"\t-step <n>    Muestra el estado cada <n> ciclos (por defecto 1)\n"
		"\t-height <h>  Altura de la tabla de traza\n");
	exit(1);
}


/* variables globales */
static word	start_pc = 0;
static sdword	start_cycle = 0;
static int	step = 1;
static int	height = 30;
static char	*start_inst = NULL;
static int 	start_inst_len = 0;
static int	active = FALSE;
static FILE	*kbrd;


/* lee argumentos */
void check_args(int argc, char **argv)
{
	int i;
	
	/* recorre argumentos */
	for (i = 1; i < argc; i++)
	{
		if (!strcmp(argv[i], "-pc"))
		{
			if (i + 1 == argc)
				ussage();
			sscanf(argv[i + 1], "0x%x", &start_pc);
			++i;
		}
		else if (!strcmp(argv[i], "-c"))
		{
			if (i + 1 == argc)
				ussage();
			sscanf(argv[i + 1], "%lld", (long long *) &start_cycle);
			++i;
		}
		else if (!strcmp(argv[i], "-i"))
		{
			if (i + 1 == argc)
				ussage();
			start_inst = argv[i + 1];
			start_inst_len = strlen(start_inst);
			++i;
		}
		else if (!strcmp(argv[i], "-step")) {
			if (i + 1 == argc)
				ussage();
			sscanf(argv[i + 1], "%d", &step);
			++i;
		}
		else if (!strcmp(argv[i], "-height")) {
			if (i + 1 == argc)
				ussage();
			sscanf(argv[i + 1], "%d", &height);
			++i;
		}
		else
			ussage();
	}
}


void stop()
{
	char	aux[128];
	int	done = FALSE;
	
	do {
		printf("(Intro=SigCiclo, Ctrl+C=fin, n=SigPC/Inst): ");
		fgets(aux, 10, kbrd);
		aux[strlen(aux) - 1] = '\0';
		if (!aux[0])
			done = TRUE;
		else if (!strcmp(aux, "n"))
		{
			if (!start_inst && !start_pc) {
				printf("\tNo se especificó '-pc' ni '-i'\n");
				continue;
			}
			active = FALSE;
			done = TRUE;
		}
		else
			printf("\tOrden no reconocida: %s\n", aux);
	} while (!done);
}


int main(int argc, char **argv)
{
	char	s[128], name[128], stg[128], aux[128], *ylbl;
	int	ptrace_start = FALSE, thread_id;
	dword	cycle, seq;
	word	pc;
	struct	table_t *table;

	/* lee parámetros */
	check_args(argc, argv);

	/* crea tabla y abre fichero */
	table = table_create("", 30, height, 2, 45);
	kbrd = fopen("/dev/tty", "rt");
	if (!start_pc && !start_cycle && !start_inst)
		active = TRUE;

	while (1) {
	
		/* lectura de entrada estándar */
		fgets(s, 128, stdin);
		if (feof(stdin))
			break;
		if (*s == '@')
			ptrace_start = TRUE;
		if (!ptrace_start)
			continue;

		/* acción según comando */
		switch (*s) {
			
		case '@':
			/* se activa la traza? */
			sscanf(s, "@ %Ld", (long long *) &cycle);
			if (start_cycle && cycle >= start_cycle)
				active = TRUE;
			
			/* imprime tabla */
			if ((cycle % step == step - 1) && cycle && active) {
				table_print(table, stdout);
				stop();
			}
			sprintf(aux, "%lld", (long long) (cycle % 100));
			table_setxlbl(table, cycle, aux);

			/* título */
			sprintf(table->name, "%s - ciclo = %lld", TABLE_TITLE, (long long) cycle);
			break;
				
		case '+':
			sscanf(s, "+ %Ld %d 0x%x %*s %[^\n]s", (long long *) &seq, &thread_id, &pc, name);
			sprintf(aux, "%04lld %d %06x %s", (long long) seq, thread_id, pc & 0xffffff, name);
			table_setylbl(table, seq, aux);

			/* se activa traza por pc? */
			if (start_pc && pc == start_pc)
				active = TRUE;

			/* se activa traza por start_inst? */
			if (start_inst && !strncmp(start_inst, name, start_inst_len) &&
					(!name[start_inst_len] || name[start_inst_len] == ' '))
				active = TRUE;
			break;

		case '*':
			sscanf(s, "* %Ld %s", (long long *) &seq, stg);
			table_setcell(table, cycle, seq, stg);
			break;

		case '-':
			sscanf(s, "- %Ld", (long long *) &seq);
			ylbl = table_ylbl(table, seq);
			if (ylbl)
				strncpy(ylbl, "----", 4);
			break;

		default:
			if (active)
				printf("%s", s);
			
		}
	}

	table_print(table, stdout);
	fclose(kbrd);
	free(table);
	return 0;
}


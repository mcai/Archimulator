#ifndef TABLE_H
#define TABLE_H

#include <stdio.h>


struct table_t {
	char	name[128];		// Nombre de la tabla
	int	width;
	int	height;
	
	char	***data;		// Matriz de cadenas
	int	data_width;		// Ancho de celda
	
	char	**xlabel;		// Etiquetas de columnas
	char	**ylabel;		// Etiquetas de filas
	int	ylbl_width;		// Ancho de etiqueta de filas
	
	int	xfirst;			// Primer elemento de la tabla en columna
	int	yfirst;			// Primer elemento de la tabla en fila
	int	xhead;			// Primer elemento del vector en columna
	int	yhead;			// Primer elemento del vector en fila
	
	int	total_width;	// Ancho total
	int	total_height;	// Altura total
};


struct table_t *table_create(
	char	*name,
	int	width,
	int	height,
	int	data_width,
	int	ylbl_width);

void table_setcell(
	struct	table_t *t,
	int	x,
	int	y,
	char	*str);

void table_setxlbl(
	struct	table_t *t,
	int	x,
	char	*str);

void table_setylbl(
	struct	table_t *t,
	int	y,
	char	*str);

/* devuelve TRUE si una celda está en rango visible */
int table_visible(
	struct	table_t *t,
	int	x,
	int	y);

/* devuelve la cadena de la etiqueta si está visible (si no, NULL) */
char *table_ylbl(
	struct	table_t *t,
	int	y);
	
void table_print(
	struct	table_t *t,
	FILE	*f);

#endif

#include "table.h"

#include "../kernel/misc.h"
#include <string.h>


/*
 * FUNCIONES AUXILIARES
 */

// Imprime en F el carácter C N veces.
void rep(FILE *f, char c, int n) {
	int i;
	for (i = 0; i < n; i++)
		fprintf(f, "%c", c);
}

// Imprime hasta rellenar n espacios
void printspc(FILE *f, char *s, int n) {
	fprintf(f, "%s", s);
	rep(f, ' ', n - strlen(s));
}


// Elimina todas las celdas
void table_clear(struct table_t *t) {
	int		i, j;
	
	// Celdas
	for (i = 0; i < t->width; i++)
		for (j = 0; j < t->height; j++)
			t->data[i][j][0] = '\0';
			
	// Etiquetas
	for (i = 0; i < t->width; i++)
		t->xlabel[i][0] = '\0';
	for (i = 0; i < t->height; i++)
		t->ylabel[i][0] = '\0';

}

// Desplazamiento horizontal
void horiz_scroll(struct table_t *t) {
	int		i;
	
	// Elimina primera columna visualizada
	for (i = 0; i < t->height; i++)
		t->data[t->xhead][i][0] = '\0';
	t->xlabel[t->xhead][0] = '\0';
	t->xfirst++;
	t->xhead = MOD(t->xhead + 1, t->width);
}

// Desplazamiento vertical
void vert_scroll(struct table_t *t) {
	int		i;
	
	// Elimina primera fila visualizada
	for (i = 0; i < t->width; i++)
		t->data[i][t->yhead][0] = '\0';
	t->ylabel[t->yhead][0] = '\0';
	t->yfirst++;
	t->yhead = MOD(t->yhead + 1, t->height);
}


/* Desplaza la tabla para mostrar cela (x,y)
 * Devuelve FALSE si se intentó desplazar la tabla hacia atrás.
 * Sólo se permiten desplazamientos hacia adelante. */
int touch_cell(struct table_t *t, int x, int y)
{
	int		reset = FALSE;
	
	// Sale si la celda es anterior
	if (x < t->xfirst || y < t->yfirst)
		return FALSE;
	
	// Si está muy lejos la nueva celda, se borra toda la tabla
	if (x >= t->xfirst + t->width * 2 - 1) {
		reset = TRUE;
		t->xfirst = x - t->width + 1;
	}
	if (y >= t->yfirst + t->height * 2 - 1) {
		reset = TRUE;
		t->yfirst = y - t->height + 1;
	}
	if (reset)
		table_clear(t);
	
	// Desplazamientos de la tabla
	while (x >= t->xfirst + t->width)
		horiz_scroll(t);
	while (y >= t->yfirst + t->height)
		vert_scroll(t);
	return TRUE;
}




/*
 * FUNCIONES DE LA TABLA
 */
 
struct table_t *table_create(
	char	*name,
	int		width,
	int		height,
	int		data_width,
	int		ylbl_width)
{
	struct table_t *t;
	int i, j;
	
	// Parámetros
	t = (struct table_t *) calloc(1, sizeof(struct table_t));
	strncpy(t->name, name, 128);
	t->width = width;
	t->height = height;
	t->data_width = data_width;
	t->ylbl_width = ylbl_width;
	
	// Derivados
	t->total_width = (data_width + 1) * width + ylbl_width;
	t->total_height = height + 2; // Con título y etiquetas x
	
	// Celdas
	t->data = (char ***) calloc(width, sizeof(char **));
	for (i = 0; i < width; i++) {
		t->data[i] = (char **) calloc(height, sizeof(char *));
		for (j = 0; j < height; j++)
			t->data[i][j] = (char *) calloc(1, t->data_width + 1);
	}
	
	// Etiquetas
	t->xlabel = (char **) calloc(width, sizeof(char *));
	for (i = 0; i < width; i++)
		t->xlabel[i] = (char *) calloc(1, t->data_width + 1);
	t->ylabel = (char **) calloc(height, sizeof(char *));
	for (i = 0; i < height; i++)
		t->ylabel[i] = (char *) calloc(1, t->ylbl_width + 1);
	
	// Devuelve tabla creada
	return t;
}


void table_setcell(
	struct	table_t *t,
	int		x,
	int		y,
	char	*str)
{
	// Si se intenta actualizar una anterior, se aborta
	if (!touch_cell(t, x, y))
		return;
	
	// Actualiza celda
	x = MOD(x - t->xfirst + t->xhead, t->width);
	y = MOD(y - t->yfirst + t->yhead, t->height);
	strncpy(t->data[x][y], str, t->data_width);
	t->data[x][y][t->data_width] = '\0';
}


void table_setxlbl(
	struct	table_t *t,
	int		x,
	char	*str)
{
	if (!touch_cell(t, x, t->yfirst))
		return;
	x = MOD(x - t->xfirst + t->xhead, t->width);
	strncpy(t->xlabel[x], str, t->data_width);
	t->xlabel[x][t->data_width] = '\0';
}


void table_setylbl(struct table_t *t, int y, char *str)
{
	if (!touch_cell(t, t->xfirst, y))
		return;
	y = MOD(y - t->yfirst + t->yhead, t->height);
	strncpy(t->ylabel[y], str, t->ylbl_width);
	t->ylabel[y][t->ylbl_width] = '\0';
}


/* devuelve TRUE si una celda está en rango visible */
int table_visible(
	struct	table_t *t,
	int		x,
	int		y)
{
	return
		x >= t->xfirst && x < t->xfirst + t->width &&
		y >= t->yfirst && y < t->yfirst + t->height;
}


/* devuelve la cadena de la etiqueta si está visible (si no, NULL) */
char *table_ylbl(
	struct	table_t *t,
	int		y)
{
	if (!table_visible(t, t->xfirst, y))
		return NULL;
	return t->ylabel[MOD(y - t->yfirst + t->yhead, t->height)];
}


void table_print(struct	table_t *t,
				FILE	*f)
{
	int		i, j, x, y;
	
	// Título
	rep(f, '*', 5);
	fprintf(f, " %s ", t->name);
	fflush(stdout);
	rep(f, '*', t->total_width - strlen(t->name) - 7);
	rep(f, '\n', 1);
	
	
	// Etiquetas x
	rep(f, ' ', t->ylbl_width + 1);
	for (i = 0; i < t->width; i++)
		printspc(f, t->xlabel[(i + t->xhead) % t->width], t->data_width + 1);
	rep(f, '\n', 1);
	
	// Líneas
	for (i = 0; i < t->height; i++) {
	
		// Etiqueta 'y'
		y = MOD(i + t->yhead, t->height);
		printspc(f, t->ylabel[y], t->ylbl_width + 1);
		
		// Celdas
		for (j = 0; j < t->width; j++) {
			x = MOD(j + t->xhead, t->width);
			printspc(f, t->data[x][y], t->data_width + 1);
		}
		
		// Cambio de línea
		rep(f, '\n', 1);
	}
}

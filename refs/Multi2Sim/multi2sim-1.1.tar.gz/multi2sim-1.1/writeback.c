#include "mt.h"

static void writeback_core(struct mt_t *mt, int core)
{
	struct uinst_t *uinst;
	struct phregs_t *phregs;
	sdword now = ke_cycle(mt->ke);
	int thread;

	for (;;) {
	
		/* Peek element from the head of the event queue */
		lnlist_head(CORE.eventq);
		uinst = lnlist_get(CORE.eventq);
		if (lnlist_error(CORE.eventq) || uinst->when > now)
			break;
		
		/* Check element integrity */
		assert(uinst_exists(uinst));
		assert(uinst->when == now);
		assert(uinst->core == core);
		assert(uinst->ready);
		if (UINST_IS_LOAD(uinst) && uinst->completed) {
			assert(!uinst->memcompleted);
		} else {
			assert(!uinst->completed);
		}
		
		/* Ok, can extract element */
		lnlist_remove(CORE.eventq);
		uinst->in_eventq = FALSE;
		thread = uinst->thread;
		phregs = THREAD.phregs;
		
		/* Loads */
		if (UINST_IS_LOAD(uinst)) {
			
			if (uinst->completed) {
			
				/* Load finished memory access */
				if (!uinst->forwarded &&
					(!cache_completed(uinst->dl1_access_id) ||
					!cache_completed(uinst->dtlb_access_id)))
				{
					uinst->when = now + 1;
					eventq_insert(CORE.eventq, uinst);
					uinst->in_eventq = TRUE;
					continue;
				}
			
				uinst->memcompleted = TRUE;
				phregs_write(phregs, uinst);
				uinst_free_if_not_queued(uinst);
			}
			else
			{
				/* Load finished calculating address */
				uinst->completed = TRUE;
			}
		}
		else /* Rest of instructions */
		{
			
			/* If instr was a branch, update branch predictor tables */
			if (UINST_IS_CTRL(uinst)) {
				assert(uinst->in_rob);
				bpred_update(THREAD.bpred, uinst);
			}
			
			/* If it is a misspredicted branch and user selected the
			 * recovery process to be performed in writeback, do so */
			if (uinst->misspred && mt_recover_kind == mt_recover_kind_writeback)
				mt_recover(mt, core, thread);
			
			/* Writeback */
			uinst->completed = TRUE;
			phregs_write(phregs, uinst);
			uinst_free_if_not_queued(uinst);
			ptrace_newstage(uinst->seq, "WB", 0);
		}
	}
}

void mt_writeback(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_writeback";
	FOREACH_CORE
		writeback_core(mt, core);
}

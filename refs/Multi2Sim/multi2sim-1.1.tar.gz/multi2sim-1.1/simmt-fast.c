#include <signal.h>
#include <mhandle.h>
#include "kernel/public.h"

struct kernel_t *ke;
int sigint = 0;

void handler(int signum)
{
	switch (signum) {
		case SIGUSR1:
			ke_dump_stats(ke, 1);
			break;
		case SIGUSR2:
			ke_dump_stats(ke, 2);
			break;
		case SIGINT:
			sigint = 1;
			signal(SIGINT, SIG_DFL);
			break;
	}
}


int double_is_nan(double val)
{
	dword temp = * (dword *) &val;
	return (temp & 0x7ff0000000000000ULL) == 0x7ff0000000000000ULL &&
		(temp & 0x000fffffffffffffULL) != 0x0000000000000000;
}


int float_is_nan(float val)
{
	word temp = * (word *) &val;
	return (temp & 0x7f800000) == 0x7f800000 &&
		(temp & 0x007fffff) != 0x00000000;
}


int double_is_inf(double val)
{
	dword temp = * (dword *) &val;
	return (temp & 0x7ff0000000000000ULL) == 0x7ff0000000000000ULL &&
		(temp & 0x000fffffffffffffULL) == 0x0000000000000000;
}


int float_is_inf(float val)
{
	word temp = * (word *) &val;
	return (temp & 0x7f800000) == 0x7f800000 &&
		(temp & 0x007fffff) == 0x00000000;
}


int main(int argc, char **argv, char **envp)
{
	int ctx, idx;

	/* command line */
	if (argc < 2) {
		fprintf(stderr,
			"syntax: %s [-debug <file>] [-ctxconfig <file>] [<exe> [<args>]]\n",
			*argv);
		exit(1);
	}
	
	/* create kernel */
	ke = ke_create();
	
	/* command line */
	for (idx = 1; idx < argc; idx++) {
		if (!strcmp(argv[idx], "-debug")) {
		
			/* debug file */
			if (idx >= argc - 1)
				fatal("'-debug' requires an argument");
			debug_open(argv[++idx]);
			
		} else if (!strcmp(argv[idx], "-ctxconfig")) {
			
			/* load programs from ctx configuration file */
			if (idx >= argc - 1)
				fatal("'-ctxconfig' requires an argument");
			ld_load_progs(ke, argv[++idx]);

		} else if (!strcmp(argv[idx], "-config")) {
			
			/* config file - argument is ignored */
			if (idx >= argc - 1)
				fatal("'-config' requires an argument");
			idx++;
			
		} else {
		
			/* option parameters finished;
			 * load a program from command line args */
			ctx = ke_new_ctx(ke);
			ld_add_args(ke, ctx, argc - idx, argv + idx);
			ld_load_prog(ke, ctx, argv[idx]);
			break;
		}
	}
	
	/* we should have some context loaded now */
	if (!ke_active_count(ke))
		fatal("no context loaded");
	
	/* signal handlers */
	signal(SIGUSR1, handler);
	signal(SIGUSR2, handler);
	signal(SIGINT, handler);
	
	/* run */
	while (ke_active_count(ke)) {
		FOREACH_RUNNING_CTX(ke)
			ke_execute_inst(ke, ctx);
		ke_new_cycle(ke);
	}
	/*{
		int ops[1000];
		int i;
		bzero(&ops, sizeof(ops));
		while (ke_active_count(ke) && !sigint) {
			FOREACH_RUNNING_CTX(ke) {
				struct md_instfld_t instfld;
				ke_execute_inst(ke, ctx);
				ke_instfld(ke, ctx, &instfld);
				ops[instfld.op]++;
				for (i = 0; i < 2; i++) {
					if (instfld.out[i] >= DFPR(0) && instfld.out[i] <= DFPR(31)) {
						struct regs_t *regs = ke_regs(ke, ctx);
						float f = FPRS(instfld.out[i] - DFPR(0));
						double d = FPRD(instfld.out[i] - DFPR(0));
						if (float_is_nan(f) || double_is_nan(d)) {
							sigint = 1;
							printf("**** NaN pc=0x%x, cycle=%lld ****\n", regs->regs_pc, (long long) ke_cycle(ke));
							md_dump_inst(stdout, &instfld);
						}
						if (float_is_inf(f) || double_is_inf(d)) {
							sigint = 1;
							printf("**** INF pc=0x%x, cycle=%lld ****\n", regs->regs_pc, (long long) ke_cycle(ke));
							md_dump_inst(stdout, &instfld);
						}
					}
				}
			}
			ke_new_cycle(ke);
		}

		for (i = 0; i < 1000; i++) {
			char *name;
			if (ops[i]) {
#define DEFINST(NAME, BITS, MASK, FORMAT, FUCLASS, FLAGS, O0, O1, I0, I1, I2) \
				if (OP_##NAME == i) { \
					name = #NAME; \
				} else
#include "kernel/machine.def"
#undef DEFINST
				{
					name = "";
				}
				printf("%-12s%d\n", name, ops[i]);
			}
		}
	}*/

	/* finalization */
	debug_close();
	ke_free(ke);
	mhandle_done();
	return 0;
}


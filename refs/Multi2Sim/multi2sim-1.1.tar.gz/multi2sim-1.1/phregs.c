#include <assert.h>
#include <string.h>
#include <list.h>
#include <stdio.h>
#include "mt.h"



/* Physical Register File */

static word phregs_size = 128;
static enum phregs_kind_enum {
	phregs_kind_shared = 0,
	phregs_kind_private
} phregs_kind = phregs_kind_private;


struct phreg_t {
	int pending_readers;
	int valid_remapping;
	int completed;
	int thread;
};


struct phregs_t {
	int size;
	struct phreg_t *phreg;
	int rat[MAX_THREADS][DCOUNT];
};




/* Private functions */

/* reclaim a free physical register;
 * the assigned register's status is changed */
static int phregs_reclaim(struct phregs_t *phregs, int thread)
{
	int phreg;
	
	/* find a register with T[phreg] = {0,1,1} */
	for (phreg = 0; phreg < phregs->size; phreg++)
		if (!phregs->phreg[phreg].pending_readers
		    && phregs->phreg[phreg].valid_remapping
		    && phregs->phreg[phreg].completed)
			break;
	
	/* no register found */
	if (phreg == phregs->size)
		fatal("phregs_reclaim: no physical register free");
	
	/* change T[phreg] to {0,0,0} */
	phregs->phreg[phreg].pending_readers = 0;
	phregs->phreg[phreg].valid_remapping = 0;
	phregs->phreg[phreg].completed = 0;
	phregs->phreg[phreg].thread = thread;
	
	/* return register */
	return phreg;
}


static int phregs_busy(struct phregs_t *phregs)
{
	int busy = 0;
	int i;
	
	for (i = 0; i < phregs->size; i++)
		if (phregs->phreg[i].pending_readers ||
		    !phregs->phreg[i].valid_remapping ||
		    !phregs->phreg[i].completed)
			busy++;
	return busy;
}


static int phregs_needs(struct uinst_t *uinst)
{
	int dep, loreg, count = 0;
	for (dep = 0; dep < 2; dep++) {
		loreg = uinst->instfld.out[dep];
		if (DVALID(loreg))
			count++;
	}
	return count;
}




/* Public functions */

void phregs_reg_options()
{
	static char *phregs_kind_map[] = { "shared", "private" };
	opt_reg_enum("-phregs_kind", "physical register file {shared|private}",
		(int *) &phregs_kind, phregs_kind_map, 2);
	opt_reg_uint32("-phregs_size", "physical register file size (if private, per thread)",
		&phregs_size);
}


static void phregs_init_thread(struct phregs_t *phregs, int thread)
{
	int dep, phreg;
	
	/* initial mapping */
	for (dep = 0; dep < DCOUNT; dep++) {
		
		/* get a free physical register and set T[phreg] to {0,0,1} */
		phreg = phregs_reclaim(phregs, thread);
		phregs->phreg[phreg].pending_readers = 0;
		phregs->phreg[phreg].valid_remapping = 0;
		phregs->phreg[phreg].completed = 1;
		
		/* entries in rat */
		phregs->rat[thread][dep] = phreg;
	}
}


void phregs_init(struct mt_t *mt)
{
	int core, thread;
	int minregs = DCOUNT + 4;
	
	if (phregs_kind == phregs_kind_private && phregs_size < minregs)
		fatal("phregs_size must be at least %d", minregs);
	if (phregs_kind == phregs_kind_shared && phregs_size < minregs * mt_threads)
		fatal("phregs_size must be at least %d * %d = %d",
			minregs, mt_threads, minregs * mt_threads);
	FOREACH_CORE FOREACH_THREAD {
		THREAD.phregs = phregs_create(phregs_size);
		phregs_init_thread(THREAD.phregs, thread);
	}
}


void phregs_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		phregs_free(THREAD.phregs);
}


int phregs_can_rename(struct mt_t *mt, int core, int thread, struct uinst_t *uinst)
{
	int needs, busy = 0;
	
	/* Calculate busy registers */
	if (phregs_kind == phregs_kind_shared) {
		FOREACH_THREAD
			busy += phregs_busy(THREAD.phregs);
	} else
		busy = phregs_busy(THREAD.phregs);
	
	/* Return TRUE if there are enough registers */
	assert(busy <= phregs_size);
	needs = phregs_needs(uinst);
	return busy + needs <= phregs_size;
}


struct phregs_t *phregs_create(int size)
{
	struct phregs_t *phregs;
	int phreg;
	
	/* create structure */
	phregs = calloc(1, sizeof(struct phregs_t));
	phregs->size = size;
	
	/* create table T, and set all registers as free (T[phreg]={0,1,1}) */
	phregs->phreg = calloc(size, sizeof(struct phreg_t));
	for (phreg = 0; phreg < size; phreg++) {
		phregs->phreg[phreg].pending_readers = 0;
		phregs->phreg[phreg].valid_remapping = 1;
		phregs->phreg[phreg].completed = 1;
	}
	
	/* return */
	return phregs;
}


void phregs_free(struct phregs_t *phregs)
{
	free(phregs->phreg);
	free(phregs);
}


void phregs_dump(struct phregs_t *phregs, int thread, FILE *f)
{
	int i;
	char *comma = "";
	fprintf(f, "Front RAT: {");
	for (i = 0; i < DCOUNT; i++) {
		fprintf(f, "%s%d-%d", comma, i, phregs->rat[thread][i]);
		comma = ",";
	}
	comma = "";
	fprintf(f, "valid_remapping: {");
	for (i = 0; i < phregs->size; i++) {
		fprintf(f, "%s%d", comma, phregs->phreg[i].valid_remapping);
		comma = ",";
	}
	fprintf(f, "}\n");
}


void phregs_rename(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int dep, loreg, phreg, ophreg;
	
	/* rename input registers */
	for (dep = 0; dep < 3; dep++) {
		loreg = uinst->instfld.in[dep];
		if (!DVALID(loreg)) {
			uinst->ph_in[dep] = -1;
			continue;
		}
		
		/* rename input register */
		phreg = phregs->rat[uinst->thread][loreg - DFIRST];
		uinst->ph_in[dep] = phreg;
		
		/* increase number of pending readers */
		phregs->phreg[phreg].pending_readers++;
	}
	
	/* rename output registers */
	for (dep = 0; dep < 2; dep++) {
		
		loreg = uinst->instfld.out[dep];
		if (!DVALID(loreg)) {
			uinst->ph_oout[dep] = -1;
			uinst->ph_out[dep] = -1;
			continue;
		}
		
		/* reclaim a free physical register */
		phreg = phregs_reclaim(phregs, uinst->thread);
		assert(phreg >= 0 && phreg < phregs->size);
		ophreg = phregs->rat[uinst->thread][loreg - DFIRST];
		
		/* allocate output registers */
		uinst->ph_oout[dep] = ophreg;
		uinst->ph_out[dep] = phreg;
		phregs->rat[uinst->thread][loreg - DFIRST] = phreg;
	}
}


void phregs_undo(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int dep, loreg, phreg, ophreg;
	for (dep = 0; dep < 2; dep++) {
	
		loreg = uinst->instfld.out[dep];
		phreg = uinst->ph_out[dep];
		ophreg = uinst->ph_oout[dep];
		if (!DVALID(loreg)) {
			assert(phreg == -1);
			assert(ophreg == -1);
			continue;
		}
		
		/* Undo renaming. Current triplet must be {0,0,1}. */
		assert(!phregs->phreg[phreg].pending_readers);
		assert(!phregs->phreg[phreg].valid_remapping);
		assert(phregs->phreg[phreg].completed);
		assert(phregs->phreg[phreg].thread == uinst->thread);
		phregs->phreg[phreg].valid_remapping = 1;
		phregs->rat[uinst->thread][loreg - DFIRST] = ophreg;
	}
}


void phregs_read(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int dep, phreg;
	
	/* rename input registers */
	for (dep = 0; dep < 3; dep++) {
		phreg = uinst->ph_in[dep];
		if (phreg < 0)
			continue;
		
		/* decrease number of pending readers */
		assert(phregs->phreg[phreg].pending_readers > 0);
		phregs->phreg[phreg].pending_readers--;
	}
}


void phregs_write(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int dep, phreg;
	
	for (dep = 0; dep < 2; dep++) {
		phreg = uinst->ph_out[dep];
		if (phreg < 0)
			continue;
		
		assert(phreg < phregs->size);
		assert(!phregs->phreg[phreg].completed);
		phregs->phreg[phreg].completed = 1;
	}
}


void phregs_retire(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int dep, loreg;
	int phreg, ophreg;
	
	assert(!uinst->specmode);
	for (dep = 0; dep < 2; dep++) {
		loreg = uinst->instfld.out[dep];
		phreg = uinst->ph_out[dep];
		ophreg = uinst->ph_oout[dep];
		if (!DVALID(loreg)) {
			assert(phreg == -1 && ophreg == -1);
			continue;
		}
		
		/* Update 'valid_remapping' of previous mapping. */
		assert(!phregs->phreg[ophreg].valid_remapping);
		phregs->phreg[ophreg].valid_remapping = 1;
	}
}


/* return true if input dependence 'idep' is resolved */
int phregs_idep_ready(struct phregs_t *phregs, struct uinst_t *uinst, int idep)
{
	int phreg;
	
	/* if there was no dependence, ready */
	assert(idep >= 0 && idep <= 2);
	phreg = uinst->ph_in[idep];
	if (phreg < 0)
		return TRUE;
	
	/* dependence found; phreg ready? */
	return phregs->phreg[phreg].completed;
}


/* return true if all input operands are ready */
int phregs_ready(struct phregs_t *phregs, struct uinst_t *uinst)
{
	int i;
	for (i = 0; i < 3; i++)
		if (!phregs_idep_ready(phregs, uinst, i))
			return FALSE;
	return TRUE;
}

#include <repos.h>
#include <string.h>
#include "kernel/machine.h"
#include "uinst.h"

#include "cache.h"

static struct repos_t *uinst_repos;


void uinst_init()
{
	uinst_repos = repos_create(sizeof(struct uinst_t), "uinst");
}


void uinst_done()
{
	repos_free(uinst_repos);
}


struct uinst_t *uinst_create()
{
	return repos_create_object(uinst_repos);
}


void uinst_free(struct uinst_t *uinst)
{
	repos_free_object(uinst_repos, uinst);
}


int uinst_exists(struct uinst_t *uinst)
{
	return repos_allocated_object(uinst_repos, uinst);
}


void uinst_free_if_not_queued(struct uinst_t *uinst)
{
	if (uinst->in_ifq || uinst->in_iq ||
		uinst->in_lq || uinst->in_sq ||
		uinst->in_rob || uinst->in_eventq)
		return;
	uinst_free(uinst);
}


void uinst_dump(struct uinst_t *uinst, FILE *f)
{
	int i;
	char queues[10];
	
	fprintf(f, "seq=%llu, in={", (long long) uinst->seq);
	for (i = 0; i < 3; i++) {
		if (uinst->ph_in[i] < 0) fprintf(f, "-");
		else fprintf(f, "%d", uinst->ph_in[i]);
		if (i < 2) fprintf(f, ",");
	}
	fprintf(f, "}, out={");
	for (i = 0; i < 2; i++) {
		if (uinst->ph_out[i] < 0) fprintf(f, "-");
		else fprintf(f, "%d", uinst->ph_out[i]);
		if (i < 1) fprintf(f, ",");
	}
	queues[0] = 0;
	if (uinst->in_ifq)
		strcat(queues, "f");
	if (uinst->in_rob)
		strcat(queues, "r");
	if (uinst->in_iq)
		strcat(queues, "i");
	if (uinst->in_lq)
		strcat(queues, "l");
	if (uinst->in_sq)
		strcat(queues, "s");
	if (uinst->in_eventq)
		strcat(queues, "e");
	fprintf(f, "} pc=0x%x spec=%s (rdy,iss,cpl)=(%s%s%s) m(rdy,iss,cpl)=(%s%s%s) when=%lld queues=%s ",
		uinst->regs_pc,
		uinst->specmode ? "t" : "f",
		uinst->ready ? "t" : "f",
		uinst->issued ? "t" : "f",
		uinst->completed ? "t" : "f",
		uinst->memready ? "t" : "f",
		uinst->memissued ? "t" : "f",
		uinst->memcompleted ? "t" : "f",
		(long long) uinst->when, queues);
	md_print_inst(f, uinst->instfld.inst, uinst->regs_pc);
}


void uinst_list_dump(struct list_t *uinst_list, FILE *f)
{
	struct uinst_t *uinst;
	int i;
	for (i = 0; i < list_count(uinst_list); i++) {
		uinst = list_get(uinst_list, i);
		fprintf(f, "%3d. ", i);
		uinst_dump(uinst, f);
		fprintf(f, "\n");
	}
}


void uinst_lnlist_dump(struct lnlist_t *uinst_list, FILE *f)
{
	struct uinst_t *uinst;
	
	lnlist_head(uinst_list);
	while (!lnlist_eol(uinst_list)) {
		uinst = lnlist_get(uinst_list);
		fprintf(f, "%3d. ", lnlist_current(uinst_list));
		uinst_dump(uinst, f);
		fprintf(f, "\n");
		lnlist_next(uinst_list);
	}
}

#include "mt.h"


#define MEM_ADDR_READY(uinst) (phregs_idep_ready(phregs, (uinst), 0))
#define STORE_DATA_READY(uinst) (phregs_idep_ready(phregs, (uinst), 1))


static void sq_refresh(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *sq = THREAD.sq;
	struct phregs_t *phregs = THREAD.phregs;
	struct uinst_t *store;
	
	/* Sweep the SQ and search ready stores */
	for (lnlist_head(sq); !lnlist_eol(sq); lnlist_next(sq)) {
		
		/* Get SQ element. If address computation is not completed or
		* instruction is already marked as memready, ignore it */
		store = lnlist_get(sq);
		assert(UINST_IS_STORE(store));
		if (!store->completed || store->memready)
			continue;
		
		/* Mark it as memready if data is ready */
		if (STORE_DATA_READY(store))
			store->memready = TRUE;
	}
}


static void lq_refresh_release_consistency(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *lq = THREAD.lq;
	struct lnlist_t *sq = THREAD.sq;
	struct uinst_t *load, *store;
	int idx;
	
	/* Sweep the LQ and search loads that are ready to perform memory access */
	for (lnlist_head(lq); !lnlist_eol(lq); lnlist_next(lq)) {
		
		/* Get LQ element. If address computation is not completed, ignore it */
		load = lnlist_get(lq);
		assert(UINST_IS_LOAD(load));
		if (!load->completed)
			continue;
		
		/* Sweep SQ. By default, 'load' will be memready and
		 * not speculavely bypassed. */
		load->memready = TRUE;
		load->bypassed = FALSE;
		lnlist_tail(sq);
		for (idx = lnlist_count(sq) - 1; idx >= 0; idx--) {
			
			/* Get SQ element. If it is a younger store, ignore it */
			lnlist_goto(sq, idx);
			store = lnlist_get(sq);
			if (store->seq > load->seq)
				continue;
			
			/* Load forwarding: a previous store has the same address,
			 * and has the data ready */
			if (store->completed && store->effaddr == load->effaddr) {
				load->forwarded = TRUE;
				break;
			}
			
			/* Load bypassing: if there is a previous store with an
			 * unresolved address, we can speculatively issue the load.
			 * However, we can already detect a possible misspeculation. */
			if (!store->completed && store->effaddr == load->effaddr) {
				load->bypassed = TRUE;
				break;
			}
		}
	}
}


static void lq_refresh_sequential_consistency(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *lq = THREAD.lq;
	struct lnlist_t *sq = THREAD.sq;
	struct uinst_t *load, *store;
	
	/* Sweep the LQ and search loads that are ready to perform memory access */
	for (lnlist_head(lq); !lnlist_eol(lq); lnlist_next(lq)) {
		
		/* Get LQ element.
		 * Loads already marked as 'memready' are ignored. */
		load = lnlist_get(lq);
		assert(UINST_IS_LOAD(load));
		if (load->memready)
			continue;
		
		/* Not completed loads prevent younger ones to be issued in
		 * sequential consistency. */
		if (!load->completed)
			break;
		
		/* Load can only be issued if all previous stores have accessed
		 * memory = if store in the head of SQ is younger */
		lnlist_head(sq);
		store = lnlist_get(sq);
		if (!store || store->seq > load->seq)
			load->memready = TRUE;
		else
			break;
	}
}


static void lq_refresh(struct mt_t *mt, int core, int thread)
{
	switch (mt_consistency) {
		case mt_consistency_release:
			lq_refresh_release_consistency(mt, core, thread);
			break;
		case mt_consistency_sequential:
			lq_refresh_sequential_consistency(mt, core, thread);
			break;
		case mt_consistency_enhanced:
			fatal("not supported yet");
			break;
	}
}


static void iq_refresh(struct mt_t *mt, int core, int thread)
{
	struct lnlist_t *iq = THREAD.iq;
	struct phregs_t *phregs = THREAD.phregs;
	struct uinst_t *uinst;
	
	/* find ready instructions */
	for (lnlist_head(iq); !lnlist_eol(iq); lnlist_next(iq)) {
		
		/* Get Instruction. If it is already marked as ready, ignore it */
		uinst = lnlist_get(iq);
		if (uinst->ready)
			continue;
		
		/* For loads/stores, we only need the address source register
		 * to compute effective address */
		if (UINST_IS_MEM(uinst) && MEM_ADDR_READY(uinst))
			uinst->ready = TRUE;
		else if (phregs_ready(phregs, uinst))
			uinst->ready = TRUE;
	}
}


/* Process IQs, LQs and SQs to update the ready/memready attributes of
 * instructions. Leave the queues pointers at the head of the queues */
void mt_refresh(struct mt_t *mt)
{
	int core, thread;
	mt->stage = "mt_refresh";
	
	FOREACH_CORE FOREACH_THREAD {
		iq_refresh(mt, core, thread);
		sq_refresh(mt, core, thread);
		lq_refresh(mt, core, thread);
		lnlist_head(THREAD.iq);
		lnlist_head(THREAD.sq);
		lnlist_head(THREAD.lq);
	}
}

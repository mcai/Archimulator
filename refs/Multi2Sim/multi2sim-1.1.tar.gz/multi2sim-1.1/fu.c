#include "mt.h"


/* Functional Units */

#define FU_RES_MAX	10
#define FU_NUM_CLASSES	12


struct fu_res_t {
	int	count;
	int	oplat;
	int	issuelat;
	char	*name;
};


static struct fu_res_t fu_res_pool[FU_NUM_CLASSES] = {
	{0, 0, 0, ""},
	{4, 2, 1, "IntALU"},
	{1, 3, 1, "IntMULT"},
	{1, 20, 19, "IntDIV"},
	{4, 4, 1, "FloatADD"},
	{2, 4, 1, "FloatCMP"},
	{2, 4, 1, "FloatCVT"},
	{1, 8, 1, "FloatMULT"},
	{1, 40, 20, "FloatDIV"},
	{1, 80, 40, "FloatSQRT"},
	{2, 1, 1, "RdPort"},
	{2, 1, 1, "WrPort"}
};


void fu_reg_options()
{
	opt_reg_uint32_list("-fu:intalu", "Integer Adder/Subtracter (count, oplat, issuelat)",
		(word *) &fu_res_pool[1], 3, NULL);
	opt_reg_uint32_list("-fu:intmult", "Integer Multiplier",
		(word *) &fu_res_pool[2], 3, NULL);
	opt_reg_uint32_list("-fu:intdiv", "Integer Divider",
		(word *) &fu_res_pool[3], 3, NULL);
	opt_reg_uint32_list("-fu:floatadd", "Floating Point Adder",
		(word *) &fu_res_pool[4], 3, NULL);
	opt_reg_uint32_list("-fu:floatcmp", "Floating Point Comparer",
		(word *) &fu_res_pool[5], 3, NULL);
	opt_reg_uint32_list("-fu:floatcvt", "Floating Point Converter",
		(word *) &fu_res_pool[6], 3, NULL);
	opt_reg_uint32_list("-fu:floatmult", "Floating Point Multiplier",
		(word *) &fu_res_pool[7], 3, NULL);
	opt_reg_uint32_list("-fu:floatdiv", "Floating Point Divider",
		(word *) &fu_res_pool[8], 3, NULL);
	opt_reg_uint32_list("-fu:floatsqrt", "Floating Point Square Root",
		(word *) &fu_res_pool[9], 3, NULL);
	opt_reg_uint32_list("-fu:rdport", "Read Port",
		(word *) &fu_res_pool[10], 3, NULL);
	opt_reg_uint32_list("-fu:wrport", "Write Port",
		(word *) &fu_res_pool[11], 3, NULL);
}


struct fu_t {
	int busy[NUM_FU_CLASSES][FU_RES_MAX];
	dword occupied, int_occupied, fp_occupied;
	dword idle, int_idle, fp_idle;
	double util, int_util, fp_util;
};


struct fu_t *fu_create()
{
	struct fu_t *fu = calloc(1, sizeof(struct fu_t));
	return fu;
}


void fu_free(struct fu_t *fu)
{
	free(fu);
}


/* reserve an fu; return fu latency or
 * 0 if it could not be reserved */
int fu_reserve(struct fu_t *fu, int class)
{
	int i;
	for (i = 0; i < fu_res_pool[class].count; i++) {
		if (!fu->busy[class][i]) {
			assert(fu_res_pool[class].issuelat > 0);
			assert(fu_res_pool[class].oplat > 0);
			fu->busy[class][i] = fu_res_pool[class].issuelat;
			return fu_res_pool[class].oplat;
		}
	}
	return 0;
}


void fu_release(struct fu_t *fu)
{
	int i, j;
	for (i = 1; i < NUM_FU_CLASSES; i++) {
		for (j = 0; j < fu_res_pool[i].count; j++) {
			if (fu->busy[i][j]) {
				fu->busy[i][j]--;
				if (i >= 1 && i <= 9)
					fu->occupied++;
				if (i >= 1 && i <= 3)
					fu->int_occupied++;
				if (i >= 4 && i <= 9)
					fu->fp_occupied++;
			} else {
				if (i >= 1 && i <= 9)
					fu->idle++;
				if (i >= 1 && i <= 3)
					fu->int_idle++;
				if (i >= 4 && i <= 9)
					fu->fp_idle++;
			}
		}
	}
}


void fu_release_all(struct fu_t *fu)
{
	int i, j;
	for (i = 1; i < NUM_FU_CLASSES; i++)
		for (j = 0; j < fu_res_pool[i].count; j++)
			fu->busy[i][j] = 0;
}

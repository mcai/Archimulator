#ifndef MT_H
#define MT_H

#include <assert.h>
#include <stdio.h>
#include <signal.h>
#include <bfd.h>
#include <list.h>
#include <lnlist.h>
#include <mhandle.h>

#include "kernel/public.h"
#include "cache.h"
#include "network.h"
#include "mm.h"
#include "uinst.h"


/* Extern Definitions */

extern char **environ;

struct mt_t;
struct cache_t;
struct bpred_t;

/* processor parameters */
extern enum mt_arch_enum {
	mt_arch_rob = 0,
	mt_arch_vb
} mt_arch;

extern word mt_cores;
extern word mt_threads;
extern word mt_quantum;
extern word mt_switch_penalty;

/* mt_recover_kind */
extern enum mt_recover_kind_enum {
	mt_recover_kind_writeback = 0,
	mt_recover_kind_retire
} mt_recover_kind;
extern word mt_recover_penalty;

/* mt_fetch_kind */
extern enum mt_fetch_kind_enum {
	mt_fetch_kind_timeslice = 0,
	mt_fetch_kind_switchonevent,
	mt_fetch_kind_multiple
} mt_fetch_kind;

/* Fetch stage */
extern enum mt_fetch_priority_enum {
	mt_fetch_priority_equal = 0,
	mt_fetch_priority_icount
} mt_fetch_priority;
extern word mt_fetch_width;

/* Decode stage */
extern enum mt_decode_kind_enum {
	mt_decode_kind_shared = 0,
	mt_decode_kind_timeslice,
} mt_decode_kind;
extern word mt_decode_width;

/* Issue stage */
extern enum mt_issue_kind_enum {
	mt_issue_kind_shared = 0,
	mt_issue_kind_timeslice,
} mt_issue_kind;
extern word mt_issue_width;

/* Retire stage */
extern enum mt_retire_kind_enum {
	mt_retire_kind_shared = 0,
	mt_retire_kind_timeslice
} mt_retire_kind;
extern word mt_retire_width;

/* Consistency model */
extern enum mt_consistency_enum {
	mt_consistency_release = 0,
	mt_consistency_sequential,
	mt_consistency_enhanced
} mt_consistency;




/* Functional Units */
 
struct fu_t;

void fu_reg_options();
struct fu_t *fu_create();
void fu_free(struct fu_t *fu);
int fu_reserve(struct fu_t *fu, int class);
void fu_release(struct fu_t *fu);
void fu_release_all(struct fu_t *fu);



/* Instruction Fetch Queue */

extern word ifq_size;
extern enum ifq_kind_enum {
	ifq_kind_private = 0,
	ifq_kind_shared
} ifq_kind;

void ifq_reg_options();
void ifq_init(struct mt_t *mt);
void ifq_done(struct mt_t *mt);
int ifq_full(struct mt_t *mt, int core, int thread);
void ifq_enqueue(struct lnlist_t *ifq, struct uinst_t *uinst);
struct uinst_t *ifq_dequeue(struct lnlist_t *ifq);




/* Reorder Buffer */

extern word rob_size;
extern enum rob_kind_enum {
	rob_kind_private = 0,
	rob_kind_shared
} rob_kind;

void rob_reg_options();
void rob_init(struct mt_t *mt);
void rob_done(struct mt_t *mt);
int rob_full(struct mt_t *mt, int core, int thread);
void rob_enqueue(struct lnlist_t *rob, struct uinst_t *uinst);
struct uinst_t *rob_dequeue(struct lnlist_t *rob);




/* Instruction Queue */

extern word iq_size;
extern enum iq_kind_enum {
	iq_kind_private = 0,
	iq_kind_shared
} iq_kind;

void iq_reg_options();
void iq_init(struct mt_t *mt);
void iq_done(struct mt_t *mt);
int iq_full(struct mt_t *mt, int core, int thread);
void iq_enqueue(struct lnlist_t *iq, struct uinst_t *uinst);
struct uinst_t *iq_dequeue(struct lnlist_t *iq);




/* Load Queue */

extern word lq_size;

void lq_reg_options();
void lq_init(struct mt_t *mt);
void lq_done(struct mt_t *mt);
void lq_enqueue(struct lnlist_t *lq, struct uinst_t *uinst);
struct uinst_t *lq_dequeue(struct lnlist_t *lq);




/* Store Queue */

extern word sq_size;

void sq_reg_options();
void sq_init(struct mt_t *mt);
void sq_done(struct mt_t *mt);
void sq_enqueue(struct lnlist_t *sq, struct uinst_t *uinst);
struct uinst_t *sq_dequeue(struct lnlist_t *sq);




/* Event Queue */

void eventq_init(struct mt_t *mt);
void eventq_done(struct mt_t *mt);
int eventq_longlat(struct mt_t *mt, int core, int thread);
void eventq_insert(struct lnlist_t *eventq, struct uinst_t *uinst);
struct uinst_t *eventq_extract(struct lnlist_t *eventq);



/* Physical Register File */

struct phregs_t;

void phregs_reg_options();
void phregs_init(struct mt_t *mt);
void phregs_done(struct mt_t *mt);
int phregs_can_rename(struct mt_t *mt, int core, int thread, struct uinst_t *uinst);

struct phregs_t *phregs_create(int size);
void phregs_free(struct phregs_t *phregs);
void phregs_rename(struct phregs_t *phregs, struct uinst_t *uinst);
void phregs_undo(struct phregs_t *phregs, struct uinst_t *uinst);
void phregs_read(struct phregs_t *phregs, struct uinst_t *uinst);
void phregs_write(struct phregs_t *phregs, struct uinst_t *uinst);
void phregs_retire(struct phregs_t *phregs, struct uinst_t *uinst);

int phregs_ready(struct phregs_t *phregs, struct uinst_t *uinst);
int phregs_idep_ready(struct phregs_t *phregs, struct uinst_t *uinst, int idep);




/* Branch Predictor */

struct bpred_t;

void bpred_reg_options();
void bpred_init(struct mt_t *mt);
void bpred_done(struct mt_t *mt);
struct bpred_t *bpred_get(struct mt_t *mt, int core, int thread);

struct bpred_t *bpred_create();
void bpred_free(struct bpred_t *bpred);
word bpred_lookup(struct bpred_t *bpred, struct uinst_t *uinst);
void bpred_update(struct bpred_t *bpred, struct uinst_t *uinst);




/* Kernel Contexts with Core-Thread Mapping */

struct ctxmap_t;

void ctxmap_init(struct mt_t *mt);
void ctxmap_done(struct mt_t *mt);
int ctxmap_count(struct mt_t *mt);
void ctxmap_ctx(struct mt_t *mt, int ctx, int *core, int *thread);
void ctxmap_unmap(struct mt_t *mt, int core, int thread);
void ctxmap_update(struct mt_t *mt);




/* Pipeline Trace */
void ptrace_init();
void ptrace_done();
void ptrace_reg_options();
void ptrace_newpc(int ctx, word pc, int specmode);
void ptrace_newinst(dword seq, int ctx, word inst, word pc, word addr);
void ptrace_newuop(dword seq, int ctx, char *desc, word pc, word addr);
void ptrace_endinst(dword seq);
void ptrace_newcycle(sdword cycle);
void ptrace_newstage(dword seq, char *pstage, word pevents);





/* Multi-Core Multi-Thread Processor */

/* fast access macros */
#define CORE			(mt->core[core])
#define THREAD			(mt->core[core].thread[thread])
#define COREI(I)		(mt->core[(I)])
#define THREADI(I)		(mt->core[core].thread[(I)])
#define FOREACH_CORE		for (core = 0; core < mt_cores; core++)
#define FOREACH_THREAD		for (thread = 0; thread < mt_threads; thread++)

#define MAX_CORES		16
#define MAX_THREADS		16


struct mt_t {

	struct	kernel_t *ke;		/* simulator kernel */
	dword	seq;			/* seq num assigned to last instr (with pre-incr) */
	char	*stage;			/* name of currently simulated stage */
	
	/* structures */
	struct	mm_t *mm;		/* memory management unit */
	struct	ctxmap_t *map;		/* kernel context with core-thread mappings */
	struct	cache_t *cache[6];	/* dl1, dl2, il1, il2, dtlb, itlb */
	struct	ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
	
	/* stats */
	dword	fastfwd_inst;
	dword	fastfwd_cycles;
	dword	fetched;
	dword	decoded;
	dword	issued;
	dword	retired;
	dword	branches;		/* num branches retired */
	dword	misspred;		/* num branches misspredicted */
	dword	cycles;
	double	time;
	
	/* Cores */
	struct	{
		
		/* Shared structures */
		struct lnlist_t *eventq;
		struct fu_t *fu;
		struct cache_t *cache[6];	/* per core caches */
		struct ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
	
		/* Stages */
		int	fetch_current;		/* for thread switch policy */
		sdword	fetch_switch;		/* for switchonevent */
		int	fetch_wait_pipe_empty;	/* wait until pipeline is empty to continue fetch */
		int	decode_current;
		int	issue_current;
		int	retire_current;
		
		/* threads */
		struct {
		
			int ctx;			/* mapped kernel context */
			int specmode;		/* true when some spec instruction was fetched */
			int misspred;		/* true when some instruction misspredicting NPC was fetched */
			
			/* private structures */
			struct lnlist_t *ifq;
			struct lnlist_t *rob;
			struct lnlist_t *iq;
			struct lnlist_t *lq;
			struct lnlist_t *sq;
			
			/* per thread caches */
			struct	cache_t *cache[6];
		
			/* architected status */
			struct	bpred_t *bpred;		/* branch predictor */
			struct	phregs_t *phregs;	/* physical register file */
			struct	ic_t *ic[2];		/* l1-l2 and l2-mm interconnect */
			
			/* node identifier for each interconnect;
			 * node[0]: id for l1-l2
			 * node[1]: id for l2-mm */
			int	node[2];		/* node identifier in each interconnect */
			
			/* fetch */
			word	fetch_pc, fetch_npc, fetch_nnpc;
			dword	il1_id, itlb_id;
			word	fetch_blk;		/* current block fetched */
			int	fetch_stall;
			
			/* number of pending main memory accesses; this counter is
			 * updated by cache.c and is useful to apply switch on event fetch */
			int current_mm_accesses;
			
			/* stats */
			dword	fetched;
			dword	decoded;
			dword	issued;
			dword	retired;
			dword	fpretired;
			
		} thread[MAX_THREADS];

	} core[MAX_CORES];
};


void mt_reg_options();
struct mt_t *mt_create();
void mt_free(struct mt_t *mt);
void mt_load_progs(struct mt_t *mt, int argc, char **argv, char *ctxfile);
void mt_start(struct mt_t *mt);
void mt_finish(struct mt_t *mt);
void mt_dump(struct mt_t *mt, FILE *f);

int mt_execute_inst(struct mt_t *mt, int ctx, struct md_instfld_t *instfld);
void mt_fast_forward(struct mt_t *mt, sdword n, int delay);

word mt_tlb_address(struct mt_t *mt, int ctx, word vaddr);
int mt_pipe_empty(struct mt_t *mt, int core);

void mt_fetch(struct mt_t *mt);
void mt_dispatch(struct mt_t *mt);
void mt_refresh(struct mt_t *mt);
void mt_issue(struct mt_t *mt);
void mt_writeback(struct mt_t *mt);
void mt_retire(struct mt_t *mt);
void mt_recover(struct mt_t *mt, int core, int thread);

#endif

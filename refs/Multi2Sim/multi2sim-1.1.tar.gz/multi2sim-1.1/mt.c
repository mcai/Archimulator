#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <mhandle.h>
#include <fcntl.h>
#include <config.h>
#include <list.h>
#include <time.h>
#include <sys/time.h>

#include "mt.h"


/* processor parameters */
enum mt_arch_enum mt_arch = mt_arch_rob;
word mt_cores = 1;
word mt_threads = 1;
word mt_quantum = 1000;
word mt_switch_penalty = 0;

enum mt_recover_kind_enum mt_recover_kind = mt_recover_kind_writeback;
word mt_recover_penalty = 0;

enum mt_fetch_kind_enum mt_fetch_kind = mt_fetch_kind_timeslice;
enum mt_fetch_priority_enum mt_fetch_priority = mt_fetch_priority_equal;
word mt_fetch_width = 4;

enum mt_decode_kind_enum mt_decode_kind = mt_decode_kind_shared;
word mt_decode_width = 4;

enum mt_issue_kind_enum mt_issue_kind = mt_issue_kind_timeslice;
word mt_issue_width = 4;

enum mt_retire_kind_enum mt_retire_kind = mt_retire_kind_shared;
word mt_retire_width = 4;

enum mt_consistency_enum mt_consistency = mt_consistency_release;




/* options & stats */
void mt_reg_options()
{
	static char *mt_arch_map[] = { "rob", "vb" };
	static char *mt_recover_kind_map[] = { "writeback", "retire" };
	static char *mt_fetch_kind_map[] = { "timeslice", "switchonevent", "multiple" };
	static char *mt_fetch_priority_map[] = { "equal", "icount" };
	static char *mt_decode_kind_map[] = { "shared", "timeslice" };
	static char *mt_issue_kind_map[] = { "shared", "timeslice" };
	static char *mt_retire_kind_map[] = { "shared", "timeslice" };
	
	opt_reg_enum("-mt_arch", "processor architecture {rob|vb}",
		(int *) &mt_arch, mt_arch_map, 2);
	opt_reg_uint32("-mt_cores", "number of processor cores", &mt_cores);
	opt_reg_uint32("-mt_threads", "number of threads per core", &mt_threads);
	
	opt_reg_enum("-mt_recover_kind", "when to recover {writeback|retire}",
		(int *) &mt_recover_kind, mt_recover_kind_map, 2);
	opt_reg_uint32("-mt_recover_penalty", "cycles to stall fetch after recover",
		&mt_recover_penalty);
	
	opt_reg_uint32("-mt_quantum", "time quantum in cycles for switch-on-event fetch", &mt_quantum);
	opt_reg_uint32("-mt_switch_penalty", "in switchonevent, thread switch "
		"penalty (0=wait_pipe_empty)", &mt_switch_penalty);
	opt_reg_enum("-mt_fetch_kind", "fetch policy {timeslice|switchonevent|multiple}",
		(int *) &mt_fetch_kind, mt_fetch_kind_map, 3);
	opt_reg_enum("-mt_fetch_priority", "apply thread fetch priorities {equal|icount}",
		(int *) &mt_fetch_priority, mt_fetch_priority_map, 2);
	opt_reg_uint32("-mt_fetch_width", "fetch width (in instr/cycle)", &mt_fetch_width);
	
	opt_reg_enum("-mt_decode_kind", "decode stage sharing {shared|timeslice}",
		(int *) &mt_decode_kind, mt_decode_kind_map, 3);
	opt_reg_uint32("-mt_decode_width", "decode width (for shared/timeslice decode)",
		&mt_decode_width);
	
	opt_reg_enum("-mt_issue_kind", "issue stage sharing {shared|timeslice}",
		(int *) &mt_issue_kind, mt_issue_kind_map, 2);
	opt_reg_uint32("-mt_issue_width", "issue width (for shared/timeslice issue)", &mt_issue_width);
	
	opt_reg_enum("-mt_retire_kind", "retire stage sharing {shared|timeslice}",
		(int *) &mt_retire_kind, mt_retire_kind_map, 2);
	opt_reg_uint32("-mt_retire_width", "retire depth (in instr/thread/cycle)", &mt_retire_width);
	
	/* other options */
	bpred_reg_options();
	phregs_reg_options();
	ifq_reg_options();
	rob_reg_options();
	iq_reg_options();
	lq_reg_options();
	sq_reg_options();
	fu_reg_options();
}


static void mt_thread_reg_stats(struct mt_t *mt, int core, int thread)
{
	char id[100], name[100], formula[100];
	struct stat_t *stat;
	
	/* thread string identifier */
	sprintf(id, "c%dt%d", core, thread);
	
	sprintf(name, "%s.fetched", id);
	stat_reg_uint64(name, "num inst fetched", &THREAD.fetched);
	
	sprintf(name, "%s.decoded", id);
	stat_reg_uint64(name, "num inst decoded", &THREAD.decoded);
	
	sprintf(name, "%s.issued", id);
	stat_reg_uint64(name, "num inst issued", &THREAD.issued);
	
	sprintf(name, "%s.retired", id);
	stat_reg_uint64(name, "num inst retired", &THREAD.retired);
	
	sprintf(name, "%s.ipc", id);
	sprintf(formula, "%s.retired / sim.cycles", id);
	stat = stat_reg_formula(name, "thread ipc", formula);
	stat_set_format(stat, "%.4f");
}


static void mt_core_reg_stats(struct mt_t *mt, int core)
{
	int thread;
	
	FOREACH_THREAD
		mt_thread_reg_stats(mt, core, thread);
}


static void mt_reg_stats(struct mt_t *mt)
{
	int core;
	struct stat_t *stat;
	
	/* stages and ipc */
	stat_reg_uint64("sim.cycles", "num cycles simulated", &mt->cycles);
	stat_reg_uint64("sim.fetched", "total inst fetched", &mt->fetched);
	stat_reg_uint64("sim.decoded", "total inst decoded", &mt->decoded);
	stat_reg_uint64("sim.issued", "total inst issued", &mt->issued);
	stat_reg_uint64("sim.retired", "total inst retired", &mt->retired);
	stat = stat_reg_formula("sim.ipc", "global ipc", "sim.retired / sim.cycles");
	stat_set_format(stat, "%.4f");
	
	/* branches */
	stat_reg_uint64("sim.branches", "num branches retired", &mt->branches);
	stat_reg_uint64("sim.misspred", "num branches misspredicted", &mt->misspred);
	stat = stat_reg_formula("sim.predacc", "branch prediction accuracy",
		"(sim.branches - sim.misspred) / sim.branches");
	stat_set_format(stat, "%.4f");
	
	/* simulation time */
	stat = stat_reg_double("sim.time", "simulation time in seconds", &mt->time);
	stat_set_format(stat, "%.1f");
	stat = stat_reg_formula("sim.cps", "cycles simulated per second", "sim.cycles / sim.time");
	stat_set_format(stat, "%.2e");
	stat = stat_reg_formula("sim.ips", "inst simulated per second", "sim.retired / sim.time");
	stat_set_format(stat, "%.2e");
	
	FOREACH_CORE
		mt_core_reg_stats(mt, core);
}


/* creation */
struct mt_t *mt_create()
{
	struct mt_t *mt;
	int core;
	
	/* create mt structure */
	mt = calloc(1, sizeof(struct mt_t));
	
	ctxmap_init(mt);
	phregs_init(mt);
	bpred_init(mt);
	cache_init(mt);
	ic_init(mt);
	
	ifq_init(mt);
	rob_init(mt);
	iq_init(mt);
	lq_init(mt);
	sq_init(mt);
	eventq_init(mt);
	
	mt->ke = ke_create();
	mt->mm = mm_create();
	FOREACH_CORE
		CORE.fu = fu_create();
	
	mt_reg_stats(mt);
	return mt;
}


/* destruction */
void mt_free(struct mt_t *mt)
{
	int core;
	
	FOREACH_CORE {
		fu_free(CORE.fu);
	}
	
	ifq_done(mt);
	rob_done(mt);
	iq_done(mt);
	lq_done(mt);
	sq_done(mt);
	eventq_done(mt);
	
	ctxmap_done(mt);
	bpred_done(mt);
	phregs_done(mt);
	cache_done(mt);
	ic_done(mt);
	
	mm_free(mt->mm);
	ke_free(mt->ke);
	free(mt);
}


/* load programs to different contexts from a configuration text file or
 * from arguments */
void mt_load_progs(struct mt_t *mt, int argc, char **argv, char *ctxfile)
{
	int ctx;
	
	/* create context from command line */
	if (argc > 1) {
		ctx = ke_new_ctx(mt->ke);
		ld_add_args(mt->ke, ctx, argc - 1, argv + 1);
		ld_load_prog(mt->ke, ctx, argv[1]);
	}
	
	/* if no context config file, already done */
	if (*ctxfile)
		ld_load_progs(mt->ke, ctxfile);
	ctxmap_update(mt);
	if (!ke_alive_count(mt->ke))
		fatal("no executable loaded");
}


void mt_start(struct mt_t *mt)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	mt->time = t.tv_sec + t.tv_usec / 1e6;
}


void mt_finish(struct mt_t *mt)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	mt->time = t.tv_sec + t.tv_usec / 1e6 - mt->time;
	mt->cycles = ke_cycle(mt->ke);
}


void mt_dump(struct mt_t *mt, FILE *f)
{
	int core, thread;
	
	printf("Cycle %lld\n", (long long) ke_cycle(mt->ke));
	FOREACH_CORE {
		fprintf(f, "Core %d:\n", core);
		
		/* Event Queue */
		fprintf(f, "eventq:\n");
		uinst_lnlist_dump(CORE.eventq, f);
		
		FOREACH_THREAD {
			fprintf(f, "Thread %d:\n", thread);
			
			fprintf(f, "rob:\n");
			uinst_lnlist_dump(THREAD.rob, f);
			
			if (mt_decode_kind != mt_decode_kind_shared) {
				fprintf(f, "ifq:\n");
				uinst_lnlist_dump(THREAD.ifq, f);
			}
			
			fprintf(f, "iq:\n");
			uinst_lnlist_dump(THREAD.iq, f);
			fprintf(f, "lq:\n");
			uinst_lnlist_dump(THREAD.lq, f);
			fprintf(f, "sq:\n");
			uinst_lnlist_dump(THREAD.sq, f);
			
			fprintf(f, "mapped context: %d\n", THREAD.ctx);
			if (ke_valid_ctx(mt->ke, THREAD.ctx))
				ke_dump_ctx(mt->ke, THREAD.ctx, f);
			
			fprintf(f, "\n");
		}
	}
}

/* run fast forward simulation during 'n' cycles;
 * if 'n' < 0, run whole simulation with fast forward;
 * if delay is true, start context ctx in cycle n/ctxnum*ctx */
void mt_fast_forward(struct mt_t *mt, sdword n, int delay)
{
	sdword i, delaytime;
	int ctx, core, thread;
	struct regs_t *regs;
	
	delaytime = n >= 0 ? n / ke_active_count(mt->ke)
		: 1000000;
	
	for (i = 0; i < n || n < 0; i++) {
		FOREACH_CTX(mt->ke) {
			if (!ke_running(mt->ke, ctx))
				continue;
			if (delay && ctx > i / delaytime)
				continue;
			ke_execute_inst(mt->ke, ctx);
			mt->fastfwd_inst++;
		}
		
		/* next cycle */
		mt->fastfwd_cycles++;
		ke_new_cycle(mt->ke);
		if (!ke_active_count(mt->ke))
			break;
	}
	
	/* kill all finished contexts */
	FOREACH_CORE FOREACH_THREAD {
		if (ke_finished(mt->ke, THREAD.ctx)) {
			ke_kill_ctx(mt->ke, THREAD.ctx);
			ctxmap_unmap(mt, core, thread);
		}
	}

	/* Cycle and context map */
	ke_reset_cycle(mt->ke);
	ctxmap_update(mt);
	
	/* Fetch PCs */
	FOREACH_CORE FOREACH_THREAD {
		ctx = THREAD.ctx;
		if (ctx < 0)
			continue;
		regs = ke_regs(mt->ke, ctx);
		THREAD.fetch_npc = regs->regs_npc;
		THREAD.fetch_nnpc = regs->regs_nnpc;
	}
}


/* return an address that combines the context and the virtual address page;
 * this address will be univocal for all generated
 * addresses and is a kind of hash function to index tlbs */
word mt_tlb_address(struct mt_t *mt, int ctx, word vaddr)
{
	assert(ctx >= 0 && ctx < mt_cores * mt_threads);
	return (vaddr >> MEM_LOGPAGESIZE) * mt_cores * mt_threads + ctx;
}


/* Return TRUE if there is no instruction in the main queues of a specific core */
int mt_pipe_empty(struct mt_t *mt, int core)
{
	int thread;
	if (lnlist_count(CORE.eventq))
		return FALSE;
	FOREACH_THREAD
		if (lnlist_count(THREAD.rob) ||
			lnlist_count(THREAD.iq) ||
			lnlist_count(THREAD.lq) ||
			lnlist_count(THREAD.sq) ||
			lnlist_count(THREAD.ifq))
			return FALSE;
	return TRUE;
}

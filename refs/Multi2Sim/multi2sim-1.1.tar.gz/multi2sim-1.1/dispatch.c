#include "mt.h"


static void dispatch_ifq(struct mt_t *mt, struct lnlist_t *ifq, int quant)
{
	int ctx, core, thread;
	struct uinst_t *uinst;
	struct phregs_t *phregs;
	struct lnlist_t *iq, *lq, *sq, *rob;
	
	for ( ; quant; quant--) {
	
		/* Are there still elements in the ifq? */
		if (!lnlist_count(ifq))
			break;
		
		/* Get entry from ifq */
		lnlist_head(ifq);
		uinst = lnlist_get(ifq);
		assert(!lnlist_error(ifq));
		assert(uinst_exists(uinst));
		ctx = uinst->ctx;
		core = uinst->core;
		thread = uinst->thread;
		
		/* Get structures */
		iq = THREAD.iq;
		lq = THREAD.lq;
		sq = THREAD.sq;
		rob = THREAD.rob;
		phregs = THREAD.phregs;
		
		/* If iq/lq/sq/rob full, done */
		if (rob_full(mt, core, thread))
			break;
		if (iq_full(mt, core, thread))
			break;
		if (lnlist_count(lq) >= lq_size && UINST_IS_LOAD(uinst))
			break;
		if (lnlist_count(sq) >= sq_size && UINST_IS_STORE(uinst))
			break;
		
		/* Are there enouth physical registers available? */
		if (!phregs_can_rename(mt, core, thread, uinst))
			break;
		
		/* Ok, can dequeue instruction from ifq */
		lnlist_remove(ifq);
		assert(!lnlist_error(ifq));
		uinst->in_ifq = FALSE;
		
		/* Rename */
		phregs_rename(phregs, uinst);
		
		/* Insert in ROB */
		lnlist_out(rob);
		lnlist_insert(rob, uinst);
		uinst->in_rob = TRUE;
		
		/* Insert in IQ */
		lnlist_out(iq);
		lnlist_insert(iq, uinst);
		uinst->in_iq = TRUE;
		
		/* Loads are inserted into the LQ */
		if (UINST_IS_LOAD(uinst)) {
			lnlist_out(lq);
			lnlist_insert(lq, uinst);
			uinst->in_lq = TRUE;
		}
		
		/* Stores are inserted into the SQ */
		if (UINST_IS_STORE(uinst)) {
			lnlist_out(sq);
			lnlist_insert(sq, uinst);
			uinst->in_sq = TRUE;
		}
		
		/* another instruction decoded */
		ptrace_newstage(uinst->seq, "DI", 0);
		mt->decoded++;
		THREAD.decoded++;
	}
}

static void dispatch_core(struct mt_t *mt, int core)
{
	int new, thread;
	int total, avail[MAX_THREADS], quant[MAX_THREADS];
	
	switch (mt_decode_kind) {

	case mt_decode_kind_timeslice:
	
		/* for timeslice decode, take 'decode_width' instr from one 'THREAD.ifq' */
		new = (CORE.decode_current + 1) % mt_threads;
		while (!lnlist_count(THREADI(new).ifq) && new != CORE.decode_current)
			new = (new + 1) % mt_threads;
		CORE.decode_current = new;
		dispatch_ifq(mt, THREADI(CORE.decode_current).ifq, mt_decode_width);
		break;
	
	case mt_decode_kind_shared:
		
		/* for replicated decode, take 'decode_width' instr from all 'THREAD.ifq's */
		total = 0;
		FOREACH_THREAD {
			avail[thread] = lnlist_count(THREAD.ifq);
			quant[thread] = 0;
			total += avail[thread];
		}
		
		/* assign quantums */
		total = MIN(total, mt_decode_width);
		while (total) {
			CORE.decode_current = (CORE.decode_current + 1) % mt_threads;
			if (avail[CORE.decode_current]) {
				avail[CORE.decode_current]--;
				quant[CORE.decode_current]++;
				total--;
			}
		};
		
		/* decode */
		FOREACH_THREAD
			dispatch_ifq(mt, THREAD.ifq, quant[thread]);
		break;
	}
}

void mt_dispatch(struct mt_t *mt)
{
	int core;
	
	mt->stage = "mt_decode";
	FOREACH_CORE
		dispatch_core(mt, core);
}

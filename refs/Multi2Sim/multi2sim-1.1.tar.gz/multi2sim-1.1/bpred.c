#include "mt.h"

/* BTB Entry */
struct btb_entry_t {
	word source;		/* tag */
	word dest;
	int counter;		/* LRU counter */
};


/* Branch Predictor Structure */
struct bpred_t {
	
	/* RAS */
	word *ras;
	int ras_idx;
	
	/* BTB - bidimensional array representing btb sets
	 * Each set has 'bpred_btb_assoc' entries of type btb_entry_t. */
	struct btb_entry_t **btb;
	
	/* choice - array of bimodal counters indexed by PC
	 *   0,1 - Use bimodal predictor.
	 *   2,3 - Use gshare predictor */
	char *choice;
	
	/* bimod - array of bimodal counters indexed by PC
	 *   0,1 - Branch not taken.
	 *   2,3 - Branch taken. */
	char *bimod;
	
	/* gshare - array of bimodal counters indexed by BHR^PC
	 *   0,1 - Branch not taken.
	 *   2,3 - Branch taken. */
	char *gshare;
	word gshare_bhr;
};


/* Parameters */
static enum bpred_kind_enum {
	bpred_kind_perfect = 0,
	bpred_kind_taken,
	bpred_kind_nottaken,
	bpred_kind_comb
} bpred_kind = bpred_kind_comb;


static char *bpred_btb = "256:4";
static word bpred_btb_sets;
static word bpred_btb_assoc;
static word bpred_bimod_size = 4096;
static word bpred_gshare_size = 4096;
static word bpred_choice_size = 4096;
static word bpred_ras_size = 256;


/* Push return address to the corresponding RAS */
static void bpred_ras_push(struct bpred_t *bpred, struct uinst_t *uinst)
{
	bpred->ras[bpred->ras_idx] = uinst->regs_pc + 8;
	bpred->ras_idx = (bpred->ras_idx + 1) % bpred_ras_size;
}


/* Get a return address from the corresponding RAS */
static word bpred_ras_pop(struct bpred_t *bpred, struct uinst_t *uinst)
{
	bpred->ras_idx = (bpred->ras_idx + bpred_ras_size - 1) % bpred_ras_size;
	return bpred->ras[bpred->ras_idx];
}


/* Lookup BTB. If it contains a valid address, return it.
 * Otherwise, return a destination address corresponding to a not taken branch. */
static word bpred_btb_lookup(struct bpred_t *bpred, struct uinst_t *uinst)
{
	word way, set;
	
	/* Search source address in BTB */
	set = (uinst->phys_pc >> 2) & (bpred_btb_sets - 1);
	for (way = 0; way < bpred_btb_assoc; way++)
		if (bpred->btb[set][way].source == uinst->phys_pc)
			return bpred->btb[set][way].dest;
	
	/* If not found, return address of next instruction */
	return uinst->pred_npc + 4;
}


/* Update BTB */
static void bpred_btb_update(struct bpred_t *bpred, struct uinst_t *uinst)
{
	int way, set;
	int found_way = -1;
	
	/* Search source address in BTB */
	set = (uinst->phys_pc >> 2) & (bpred_btb_sets - 1);
	for (way = 0; way < bpred_btb_assoc; way++) {
		if (bpred->btb[set][way].source == uinst->phys_pc)
			found_way = way;
	}
	
	/* If address was not found, evict LRU entry */
	if (found_way < 0) {
		for (way = 0; way < bpred_btb_assoc; way++) {
			bpred->btb[set][way].counter--;
			if (bpred->btb[set][way].counter < 0) {
				bpred->btb[set][way].counter = bpred_btb_assoc - 1;
				bpred->btb[set][way].source = uinst->phys_pc;
				bpred->btb[set][way].dest = uinst->regs_nnpc;
			}
		}
	}
	
	/* If address was found, update LRU counters */
	if (found_way >= 0) {
		for (way = 0; way < bpred_btb_assoc; way++)
			if (bpred->btb[set][way].counter > bpred->btb[set][found_way].counter)
				bpred->btb[set][way].counter--;
		bpred->btb[set][found_way].counter = bpred_btb_assoc - 1;
	}
}


void bpred_reg_options()
{
	static char *bpred_kind_map[] = { "perfect", "taken", "nottaken", "comb" };
	opt_reg_enum("-bpred", "branch predictor kind {perfect|taken|nottaken|comb}",
		(int *) &bpred_kind, bpred_kind_map, 4);
	opt_reg_string("-bpred:btb", "branch predictor btb configuration (<sets>:<assoc>)", &bpred_btb);
	opt_reg_uint32("-bpred:ras", "return address stack size", &bpred_ras_size);
	opt_reg_uint32("-bpred:bimod", "BHT size for bimodal component", &bpred_bimod_size);
	opt_reg_uint32("-bpred:gshare", "BHT for gshare component", &bpred_gshare_size);
	opt_reg_uint32("-bpred:choice", "BHT size for choice predictor", &bpred_choice_size);
}


void bpred_init(struct mt_t *mt)
{
	int core, thread;
	
	/* Integrity */
	if (bpred_bimod_size & (bpred_bimod_size - 1))
		fatal("bpred:bimod must be power of 2");
	if (bpred_gshare_size & (bpred_gshare_size - 1))
		fatal("bpred:gshare must be power of 2");
	if (bpred_choice_size & (bpred_choice_size - 1))
		fatal("bpred:choice must be power of 2");
	if (sscanf(bpred_btb, "%d:%d", &bpred_btb_sets, &bpred_btb_assoc) != 2)
		fatal("invalid bpred:btb format");
	if (bpred_btb_sets & (bpred_btb_sets - 1))
		fatal("number of btb sets must be power of 2");
	if (bpred_btb_assoc & (bpred_btb_assoc - 1))
		fatal("btb associativity must be power of 2");
	
	/* Initialization */
	FOREACH_CORE FOREACH_THREAD
		THREAD.bpred = bpred_create();
}


void bpred_done(struct mt_t *mt)
{
	int core, thread;
	FOREACH_CORE FOREACH_THREAD
		bpred_free(THREAD.bpred);
}


struct bpred_t *bpred_create()
{
	struct bpred_t *bpred;
	int i, j;
	
	/* Create bpred */
	bpred = calloc(1, sizeof(struct bpred_t));
	bpred->ras = calloc(bpred_ras_size, sizeof(word));
	bpred->bimod = calloc(bpred_bimod_size, sizeof(char));
	bpred->gshare = calloc(bpred_gshare_size, sizeof(char));
	bpred->choice = calloc(bpred_choice_size, sizeof(char));
	
	/* BTB */
	bpred->btb = calloc(bpred_btb_sets, sizeof(struct btb_entry_t *));
	for (i = 0; i < bpred_btb_sets; i++) {
		bpred->btb[i] = calloc(bpred_btb_assoc, sizeof(struct btb_entry_t));
		for (j = 0; j < bpred_btb_assoc; j++)
			bpred->btb[i][j].counter = j;	/* Assign LRU counters */
	}
	
	/* Initialize tables */
	for (i = 0; i < bpred_bimod_size; i++)
		bpred->bimod[i] = 2;
	for (i = 0; i < bpred_gshare_size; i++)
		bpred->gshare[i] = 2;
	for (i = 0; i < bpred_choice_size; i++)
		bpred->choice[i] = 2;
	return bpred;
}


void bpred_free(struct bpred_t *bpred)
{
	int i;
	
	/* Bree BTB */
	for (i = 0; i < bpred_btb_sets; i++)
		free(bpred->btb[i]);
	free(bpred->btb);
	
	/* Bree bpred */
	free(bpred->ras);
	free(bpred->bimod);
	free(bpred->gshare);
	free(bpred->choice);
	free(bpred);
}


word bpred_lookup(struct bpred_t *bpred, struct uinst_t *uinst)
{
	/* If our predictor kind is 'perfect', return the correct address */
	if (bpred_kind == bpred_kind_perfect)
		return uinst->regs_nnpc;
	
	/* If instruction is not a branch, return always npc+4 */
	if (!(uinst->instfld.flags & F_CTRL))
		return uinst->pred_npc + 4;
	
	/* If instruction is not speculative, we can think of using the RAS.
	 * It it is a call, push to RAS; if it is a return, pop from RAS. */
	if (!uinst->specmode) {
		if (uinst->instfld.flags & F_CALL)
			bpred_ras_push(bpred, uinst);
		if (uinst->instfld.flags & F_RET)
			return bpred_ras_pop(bpred, uinst);
	}
	
	
	/* Actions depending on predictor kind */
	switch (bpred_kind) {
	
		case bpred_kind_nottaken:
			return uinst->pred_npc + 4;
	
		case bpred_kind_taken:
			return bpred_btb_lookup(bpred, uinst);
	
		case bpred_kind_comb:
		{
			int taken;

			uinst->bimod_idx = (uinst->regs_pc >> 2) & (bpred_bimod_size - 1);
			uinst->bimod_taken = bpred->bimod[uinst->bimod_idx] > 1;
			
			uinst->gshare_idx = (uinst->regs_pc >> 2) ^ bpred->gshare_bhr;
			uinst->gshare_idx &= bpred_gshare_size - 1;
			uinst->gshare_taken = bpred->gshare[uinst->gshare_idx] > 1;
			bpred->gshare_bhr = (bpred->gshare_bhr << 1) |
				(uinst->gshare_taken ? 1 : 0);

			uinst->choice_idx = (uinst->regs_pc >> 2) & (bpred_choice_size - 1);
			uinst->choice_value = bpred->choice[uinst->choice_idx];

			taken = uinst->choice_value < 2 ? uinst->bimod_taken :
				uinst->gshare_taken;
			
			return taken ? bpred_btb_lookup(bpred, uinst)
				: uinst->pred_npc + 4;
		}
		
		default:
			panic("unknown predictor");
			return 0;
	}
}


void bpred_update(struct bpred_t *bpred, struct uinst_t *uinst)
{
	/* Update BTB except if instr is a RET */
	assert(uinst->instfld.flags & F_CTRL);
	if (!(uinst->instfld.flags & F_RET))
		bpred_btb_update(bpred, uinst);
	
	/* Update bimodal predictor only if inst is neither CALL nor RET */
	if (bpred_kind == bpred_kind_comb &&
		!(uinst->instfld.flags & F_CALL) &&
		!(uinst->instfld.flags & F_RET))
	{

		int taken = uinst->regs_nnpc != uinst->regs_pc + 8;

		/* Update bimodal predictor */
		bpred->bimod[uinst->bimod_idx] = taken ?
			MIN(bpred->bimod[uinst->bimod_idx] + 1, 3) :
			MAX(bpred->bimod[uinst->bimod_idx] - 1, 0);

		/* Update gshare predictor */
		bpred->gshare[uinst->gshare_idx] = taken ?
			MIN(bpred->gshare[uinst->gshare_idx] + 1, 3) :
			MAX(bpred->gshare[uinst->gshare_idx] - 1, 0);

		/* Update choice predictor */
		if (uinst->bimod_taken != uinst->gshare_taken) {
			bpred->choice[uinst->choice_idx] =
				uinst->bimod_taken == taken ?
				MAX(bpred->choice[uinst->choice_idx] - 1, 0) :
				MIN(bpred->choice[uinst->choice_idx] + 1, 3);
		}
	}
}

#ifndef MM_H
#define MM_H

#include "kernel/misc.h"

struct mm_t;

/* creation & destruction */
struct mm_t *mm_create();
void mm_free(struct mm_t *mm);

/* translate virtual address + context id to a physical address;
 * if the virtual page is not allocated, create it */
void mm_translate(struct mm_t *mm, int ctx, word vtl_addr, word *phaddr);

/* translate a physical address to a virtual address and a context id;
 * if physical address does not exist, return 0 */
int mm_rtranslate(struct mm_t *mm, word phaddr, int *ctx, word *vtladdr);


#endif

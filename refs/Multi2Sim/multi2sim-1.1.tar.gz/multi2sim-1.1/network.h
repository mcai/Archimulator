#ifndef IC_H
#define IC_H

struct mt_t;
struct ic_t;

extern enum ic_topo_enum {
	ic_topo_bus = 0
} ic_topo;



/* ESIM Function 'esim_ic_transfer'.
 * Used to start an interconnect send/broadcast. The parameters descriptions is:
 *   source       id of source node
 *   dest         id of destination node, -1 for broadcast
 *   size         data size; transfer will be partitioned into packets that
 *                fit the links width
 *   recv_event   event to be scheduled when all data arrive to its destination;
 *                the corresponding event data will be the same esim_ic_transfer_t
 *                struct; for bcasts, the event will be called n times, replacing
 *                the 'dest' field by 0..n-1 in each case
 *   recv_data    data that could be needed when processing recv_event
 */
extern struct repos_t *esim_ic_transfer_repos;
extern int IC_EV_TRANSFER_START;
extern int IC_EV_TRANSFER_END;
struct esim_ic_transfer_t {

	/* debug */
	int repos_id;

	/* params */
	struct ic_t *ic;
	int source;
	int dest;
	int size;
	int recv_event;
	void *recv_data;
	
	/* return */
	int return_event;
	void *return_data;
};


/* Interconnect kind
 * l1_l2: interconnect between level 1 and level2 caches
 * l2_mm: interconnect between level 2 and main memory caches */
enum ic_kind_enum {
	ic_kind_l1_l2 = 0,
	ic_kind_l2_mm
};


void ic_reg_options();
void ic_init(struct mt_t *mt);
void ic_done(struct mt_t *mt);

struct ic_t *ic_get(struct mt_t *mt, int core, int thread, enum ic_kind_enum kind);

int ic_node_count(struct ic_t *ic);
void *ic_node_data(struct ic_t *ic, int id);

#endif

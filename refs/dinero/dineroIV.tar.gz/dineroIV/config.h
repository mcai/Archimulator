/* config.h.  Generated automatically by configure.  */
/*
 * config.h.in.  Generated initially from configure.in by autoheader,
 * but now maintained manually.
 * $Header: /home/edler/dinero/d4/RCS/config.h.in,v 1.2 1997/10/19 05:24:49 edler Exp $
 */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* type for random, if not defined in stdlib.h */
/* #undef D4_RANDOM_DEF */
